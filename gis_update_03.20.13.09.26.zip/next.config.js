const path = require('path');

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Kunci root workspace ke direktori aplikasi saat di-build di cloud hosting (DomaiNesia/cPanel)
  // Mencegah Next.js salah memilih /home/walhisum sebagai root karena adanya package-lock.json di home
  outputFileTracingRoot: path.resolve(__dirname),
  allowedDevOrigins: ['*.run.app', 'localhost:3000', 'localhost:40001', '127.0.0.1:40001', '*.walhisumut.or.id'],
  serverExternalPackages: ['@mapbox/shp-write', 'mysql2', 'bcryptjs'],
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'walhisumut.or.id',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
    ],
  },
  transpilePackages: ['motion'],
  async headers() {
    return [
      {
        source: '/(widget|embed)(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'ALLOWALL',
          },
          {
            key: 'Content-Security-Policy',
            value: 'frame-ancestors *',
          },
          {
            key: 'Access-Control-Allow-Origin',
            value: '*',
          },
        ],
      },
    ];
  },
  webpack: (config, { dev }) => {
    // Pastikan alias '@' selalu merujuk tepat ke direktori proyek lokal
    config.resolve = config.resolve || {};
    config.resolve.alias = {
      ...(config.resolve.alias || {}),
      '@': path.resolve(__dirname),
    };

    if (dev) {
      // Disable persistent filesystem pack caching in development to avoid ENOENT errors on pack files
      config.cache = false;
    }
    return config;
  },
};

module.exports = nextConfig;


