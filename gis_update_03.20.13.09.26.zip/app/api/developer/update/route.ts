import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getUserById } from '@/lib/db';
import { getAppVersion, extractVersionFromFileName, deleteVersionHistoryItem } from '@/lib/version';
import {
  inspectUpdateZip,
  applyUpdateFromZip,
  rollbackToBackup,
  listAvailableBackups,
} from '@/lib/selfUpdate';
import { checkGitHubUpdates, downloadGitHubUpdateZip } from '@/lib/githubUpdater';

export const dynamic = 'force-dynamic';

// Helper verifikasi hak akses developer
async function verifyDeveloperAccess() {
  const cookieStore = await cookies();
  const userId = cookieStore.get('wkr_user_id')?.value;
  const authToken = cookieStore.get('wkr_auth_token')?.value;

  if (!userId || !authToken) {
    return { authorized: false, error: 'Sesi login tidak ditemukan' };
  }

  const user = await getUserById(userId);
  if (!user) {
    return { authorized: false, error: 'Pengguna tidak ditemukan' };
  }

  const isDev = Boolean(user.isDeveloper || user.username === 'super');
  if (!isDev) {
    return { authorized: false, error: 'Akses ditolak: Hanya akun Developer yang diizinkan' };
  }

  return { authorized: true, user };
}

/**
 * GET: Mengambil status versi saat ini, riwayat update, daftar backup, atau cek update GitHub
 */
export async function GET(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const checkGithub = searchParams.get('check_github') === 'true' || searchParams.get('github') === '1';

  // 1. Jika meminta pemeriksaan pembaruan GitHub https://github.com/hasyir87/Peta-Informasi-Update
  if (checkGithub) {
    try {
      const githubResult = await checkGitHubUpdates();
      return NextResponse.json(githubResult);
    } catch (err: any) {
      return NextResponse.json(
        {
          success: false,
          hasUpdate: false,
          error: err.message || 'Gagal memeriksa pembaruan GitHub',
        },
        { status: 500 }
      );
    }
  }

  // 2. Data versi dan cadangan lokal
  const versionData = getAppVersion();
  const backups = listAvailableBackups();

  return NextResponse.json({
    success: true,
    version: versionData.version,
    versionName: versionData.versionName,
    releaseDate: versionData.releaseDate,
    lastUpdated: versionData.lastUpdated,
    notes: versionData.notes,
    history: versionData.history || [],
    backups,
  });
}

/**
 * POST: Menangani unggah ZIP pembaruan, download & install otomatis dari GitHub, inspeksi, atau rollback
 */
export async function POST(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  const contentType = req.headers.get('content-type') || '';

  // 1. Permintaan JSON: Rollback atau GitHub Auto-Download & Install
  if (contentType.includes('application/json')) {
    try {
      const body = await req.json();

      // Aksi Rollback
      if (body.action === 'rollback') {
        const { backupFile, targetVersion } = body;
        if (!backupFile) {
          return NextResponse.json(
            { success: false, error: 'Nama berkas cadangan (backupFile) wajib dicantumkan.' },
            { status: 400 }
          );
        }

        const rollbackResult = await rollbackToBackup(backupFile, targetVersion);
        const updatedVersion = getAppVersion();

        return NextResponse.json({
          success: true,
          message: rollbackResult.message,
          restoredFilesCount: rollbackResult.restoredFiles.length,
          version: updatedVersion.version,
          versionName: updatedVersion.versionName,
        });
      }

      // Aksi Download & Install Otomatis dari GitHub
      if (body.action === 'github_install' || body.action === 'github_update') {
        const { downloadUrl, fileName, notes } = body;
        if (!downloadUrl) {
          return NextResponse.json(
            { success: false, error: 'URL unduhan berkas pembaruan GitHub wajib diisi.' },
            { status: 400 }
          );
        }

        // 1. Download buffer ZIP dari GitHub
        const zipBuffer = await downloadGitHubUpdateZip(downloadUrl);
        const explicitVersion = fileName ? extractVersionFromFileName(fileName) : undefined;
        const customNote = notes || `Update otomatis dari GitHub (${fileName || 'gis_update'})`;

        // 2. Terapkan pembaruan langsung secara mandiri
        const updateResult = await applyUpdateFromZip(zipBuffer, customNote, explicitVersion);

        return NextResponse.json({
          success: true,
          ...updateResult,
        });
      }

      return NextResponse.json({ success: false, error: 'Aksi JSON tidak dikenali' }, { status: 400 });
    } catch (err: any) {
      return NextResponse.json(
        {
          success: false,
          error: err.message || 'Gagal memproses pembaruan',
        },
        { status: 500 }
      );
    }
  }

  // 2. Upload Berkas ZIP via FormData (Inspect atau Apply)
  if (contentType.includes('multipart/form-data')) {
    try {
      const formData = await req.formData();
      const file = formData.get('file') as File | null;
      const action = (formData.get('action') as string) || 'apply';
      const notes = (formData.get('notes') as string) || '';

      if (!file) {
        return NextResponse.json(
          { success: false, error: 'Tidak ada berkas ZIP yang diunggah.' },
          { status: 400 }
        );
      }

      const buffer = Buffer.from(await file.arrayBuffer());
      const explicitVersion = file.name ? extractVersionFromFileName(file.name) : undefined;

      // Jika aksi hanya inspeksi sebelum diterapkan
      if (action === 'inspect') {
        const inspection = await inspectUpdateZip(buffer, explicitVersion);
        return NextResponse.json({
          success: inspection.isValid,
          ...inspection,
        });
      }

      // Terapkan pembaruan langsung secara mandiri
      const updateResult = await applyUpdateFromZip(buffer, notes, explicitVersion);

      return NextResponse.json({
        success: true,
        ...updateResult,
      });
    } catch (err: any) {
      return NextResponse.json(
        {
          success: false,
          error: err.message || 'Gagal menerapkan pembaruan mandiri',
        },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ success: false, error: 'Format permintaan tidak didukung' }, { status: 400 });
}

/**
 * DELETE: Menghapus item riwayat versi & berkas cadangan zip terkait
 */
export async function DELETE(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const version = searchParams.get('version') || '';
    const backupFile = searchParams.get('backupFile') || searchParams.get('file') || '';

    if (!version && !backupFile) {
      return NextResponse.json(
        { success: false, error: 'Parameter version atau backupFile wajib disertakan.' },
        { status: 400 }
      );
    }

    const updatedData = deleteVersionHistoryItem(version || backupFile, backupFile);

    return NextResponse.json({
      success: true,
      message: `Riwayat versi ${version || backupFile} dan berkas cadangan terkait berhasil dihapus.`,
      history: updatedData.history,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal menghapus riwayat versi' },
      { status: 500 }
    );
  }
}
