'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import AdminNavbar from '@/components/AdminNavbar';
import CircularLoading from '@/components/CircularLoading';
import {
  Terminal,
  Shield,
  Key,
  Users,
  Database,
  Package,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  X,
  Lock,
  RefreshCw,
  Server,
  Download,
  Copy,
  Check,
  Rocket,
  ShieldAlert,
  ShieldCheck,
  HardDrive,
  UserCheck,
  ChevronRight,
  Sparkles,
  Eye,
  EyeOff,
  UploadCloud,
  History,
  Undo2,
  Archive,
  FileText,
  ArrowRight,
  FolderArchive,
  RotateCcw,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react';
import { User } from '@/lib/types';

export default function DeveloperConsolePage() {
  const router = useRouter();

  // Auth & Permissions state
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isDeveloper, setIsDeveloper] = useState<boolean | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Tabs: 'updates' | 'backup-db' | 'accounts' | 'database' | 'deploy'
  const [activeTab, setActiveTab] = useState<'updates' | 'backup-db' | 'accounts' | 'database' | 'deploy'>('updates');

  // Database Backup State
  const [dbBackups, setDbBackups] = useState<any[]>([]);
  const [dbStats, setDbStats] = useState<any | null>(null);
  const [loadingDbBackups, setLoadingDbBackups] = useState<boolean>(false);
  const [isCreatingDbBackup, setIsCreatingDbBackup] = useState<boolean>(false);
  const [dbBackupNotes, setDbBackupNotes] = useState<string>('');
  const [lastCreatedBackup, setLastCreatedBackup] = useState<any | null>(null);
  const [restoreDbModalOpen, setRestoreDbModalOpen] = useState<boolean>(false);
  const [selectedDbBackupForRestore, setSelectedDbBackupForRestore] = useState<any | null>(null);
  const [isRestoringDb, setIsRestoringDb] = useState<boolean>(false);
  const [deleteDbBackupModalOpen, setDeleteDbBackupModalOpen] = useState<boolean>(false);
  const [selectedDbBackupForDelete, setSelectedDbBackupForDelete] = useState<any | null>(null);
  const [isDeletingDbBackup, setIsDeletingDbBackup] = useState<boolean>(false);

  // Version & Self-Update State
  const [appVersion, setAppVersion] = useState<any>(null);
  const [updateHistory, setUpdateHistory] = useState<any[]>([]);
  const [backupsList, setBackupsList] = useState<any[]>([]);
  const [loadingVersion, setLoadingVersion] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isInspecting, setIsInspecting] = useState<boolean>(false);
  const [inspectionData, setInspectionData] = useState<any>(null);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [updateProgressMsg, setUpdateProgressMsg] = useState<string>('');
  const [updateSuccessResult, setUpdateSuccessResult] = useState<any>(null);
  const [updateNotes, setUpdateNotes] = useState<string>('');
  const [rollbackModalOpen, setRollbackModalOpen] = useState<boolean>(false);
  const [selectedBackupForRollback, setSelectedBackupForRollback] = useState<any>(null);
  const [isRollingBack, setIsRollingBack] = useState<boolean>(false);

  // GitHub Auto-Update State
  const [githubCheckResult, setGithubCheckResult] = useState<any>(null);
  const [checkingGithub, setCheckingGithub] = useState<boolean>(false);
  const [isInstallingGithubUpdate, setIsInstallingGithubUpdate] = useState<boolean>(false);
  const [githubInstallProgress, setGithubInstallProgress] = useState<string>('');

  // Developer Accounts State
  const [devUsers, setDevUsers] = useState<User[]>([]);
  const [loadingUsers, setLoadingUsers] = useState<boolean>(false);
  const [userModalOpen, setUserModalOpen] = useState<boolean>(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showUserPassword, setShowUserPassword] = useState<boolean>(false);
  const [showDbPassword, setShowDbPassword] = useState<boolean>(false);
  const [userForm, setUserForm] = useState({
    fullName: '',
    username: '',
    email: '',
    password: '',
  });
  const [userFormSubmitting, setUserFormSubmitting] = useState<boolean>(false);

  // Database Tab State
  const [dbStatus, setDbStatus] = useState<any>(null);
  const [dbSetupLoading, setDbSetupLoading] = useState(false);
  const [dbSetupMessage, setDbSetupMessage] = useState<{ success: boolean; text: string } | null>(null);
  const [dbForm, setDbForm] = useState({
    host: '',
    port: '3306',
    user: '',
    password: '',
    database: '',
  });

  // UI Feedback
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // 1. Authenticate and check Developer privileges
  useEffect(() => {
    let ignore = false;
    fetch('/api/auth')
      .then((res) => res.json())
      .then((data) => {
        if (ignore) return;
        if (!data.authenticated) {
          router.push('/login');
          return;
        }
        setCurrentUser(data.user);
        const hasDevAccess = Boolean(data.isDeveloper || data.user.isDeveloper || data.user.username === 'super');
        setIsDeveloper(hasDevAccess);
        setAuthLoading(false);

        if (hasDevAccess) {
          // Fetch initial developer users
          fetch('/api/developer/users')
            .then((r) => r.json())
            .then((uData) => {
              if (ignore) return;
              if (uData.success && Array.isArray(uData.data)) {
                setDevUsers(uData.data);
              }
            })
            .catch(() => {});

          // Fetch initial database status
          fetch('/api/database/status')
            .then((r) => r.json())
            .then((dbData) => {
              if (ignore) return;
              setDbStatus(dbData);
              if (dbData?.config) {
                setDbForm({
                  host: dbData.config.host || '',
                  port: String(dbData.config.port || 3306),
                  user: dbData.config.user || '',
                  password: '',
                  database: dbData.config.database || '',
                });
              }
            })
            .catch(() => {});

          // Fetch initial app version & update status
          fetch('/api/developer/update')
            .then((r) => r.json())
            .then((vData) => {
              if (ignore) return;
              if (vData.success) {
                setAppVersion({
                  version: vData.version,
                  versionName: vData.versionName,
                  releaseDate: vData.releaseDate,
                  lastUpdated: vData.lastUpdated,
                  notes: vData.notes,
                });
                setUpdateHistory(vData.history || []);
                setBackupsList(vData.backups || []);
              }
            })
            .catch(() => {});

          // Check for GitHub updates in background
          fetch('/api/developer/update?check_github=true')
            .then((r) => r.json())
            .then((gData) => {
              if (ignore) return;
              setGithubCheckResult(gData);
            })
            .catch(() => {});

          // Fetch initial database backups & stats
          fetch('/api/developer/database/backup')
            .then((r) => r.json())
            .then((bData) => {
              if (ignore) return;
              if (bData.success) {
                setDbBackups(bData.backups || []);
                setDbStats(bData.stats || null);
              }
            })
            .catch(() => {});
        }
      })
      .catch(() => {
        if (!ignore) router.push('/login');
      });

    return () => {
      ignore = true;
    };
  }, [router]);

  // Database Backup Handlers
  const fetchDbBackups = async () => {
    setLoadingDbBackups(true);
    try {
      const res = await fetch('/api/developer/database/backup');
      const data = await res.json();
      if (data.success) {
        setDbBackups(data.backups || []);
        setDbStats(data.stats || null);
      } else {
        showNotification('error', data.error || 'Gagal memuat daftar backup database');
      }
    } catch (err: any) {
      showNotification('error', `Gagal memuat backup database: ${err.message}`);
    } finally {
      setLoadingDbBackups(false);
    }
  };

  const handleCreateDbBackup = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsCreatingDbBackup(true);
    try {
      const res = await fetch('/api/developer/database/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes: dbBackupNotes.trim() || undefined }),
      });
      const data = await res.json();
      if (data.success) {
        showNotification('success', data.message || 'Cadangan database berhasil dibuat');
        setLastCreatedBackup(data.backup);
        setDbBackupNotes('');
        await fetchDbBackups();
      } else {
        showNotification('error', data.error || 'Gagal membuat backup database');
      }
    } catch (err: any) {
      showNotification('error', `Terjadi kesalahan: ${err.message}`);
    } finally {
      setIsCreatingDbBackup(false);
    }
  };

  const handleExecuteRestoreDb = async () => {
    if (!selectedDbBackupForRestore) return;
    setIsRestoringDb(true);
    try {
      const res = await fetch('/api/developer/database/backup', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: selectedDbBackupForRestore.fileName }),
      });
      const data = await res.json();
      if (data.success) {
        showNotification('success', data.message || 'Database berhasil dipulihkan');
        setRestoreDbModalOpen(false);
        setSelectedDbBackupForRestore(null);
        await fetchDbBackups();
      } else {
        showNotification('error', data.error || 'Gagal memulihkan database');
      }
    } catch (err: any) {
      showNotification('error', `Gagal memulihkan database: ${err.message}`);
    } finally {
      setIsRestoringDb(false);
    }
  };

  const handleExecuteDeleteDbBackup = async () => {
    if (!selectedDbBackupForDelete) return;
    setIsDeletingDbBackup(true);
    try {
      const res = await fetch(`/api/developer/database/backup?fileName=${encodeURIComponent(selectedDbBackupForDelete.fileName)}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success) {
        showNotification('success', data.message || 'Berkas cadangan berhasil dihapus');
        setDeleteDbBackupModalOpen(false);
        setSelectedDbBackupForDelete(null);
        await fetchDbBackups();
      } else {
        showNotification('error', data.error || 'Gagal menghapus berkas cadangan');
      }
    } catch (err: any) {
      showNotification('error', `Gagal menghapus berkas cadangan: ${err.message}`);
    } finally {
      setIsDeletingDbBackup(false);
    }
  };

  // Fetch Version Data & Backups
  const fetchVersionData = async () => {
    setLoadingVersion(true);
    try {
      const res = await fetch('/api/developer/update');
      const data = await res.json();
      if (data.success) {
        setAppVersion({
          version: data.version,
          versionName: data.versionName,
          releaseDate: data.releaseDate,
          lastUpdated: data.lastUpdated,
          notes: data.notes,
        });
        setUpdateHistory(data.history || []);
        setBackupsList(data.backups || []);
      }
    } catch (err: any) {
      console.error('Failed to fetch version:', err);
    } finally {
      setLoadingVersion(false);
    }
  };

  // Check GitHub for latest updates
  const checkGithubUpdates = async (silent = false) => {
    setCheckingGithub(true);
    try {
      const res = await fetch('/api/developer/update?check_github=true');
      const data = await res.json();
      setGithubCheckResult(data);
      if (!silent) {
        if (data.hasUpdate) {
          showNotification('success', `Pembaruan baru ditemukan di GitHub: ${data.latestUpdate?.name}`);
        } else if (data.success) {
          showNotification('success', 'Versi aplikasi Anda sudah yang paling baru.');
        } else {
          showNotification('error', data.error || 'Gagal memeriksa pembaruan di GitHub');
        }
      }
    } catch (err: any) {
      if (!silent) {
        showNotification('error', `Gagal memeriksa GitHub: ${err.message}`);
      }
    } finally {
      setCheckingGithub(false);
    }
  };

  // Install update automatically from GitHub
  const handleInstallGithubUpdate = async (fileItem?: any) => {
    const target = fileItem || githubCheckResult?.latestUpdate;
    if (!target || !target.downloadUrl) return;

    setIsInstallingGithubUpdate(true);
    setGithubInstallProgress('1/3: Mengunduh berkas zip pembaruan dari GitHub...');
    setUpdateSuccessResult(null);

    try {
      setTimeout(() => {
        setGithubInstallProgress('2/3: Membuat arsip cadangan & mengekstrak file pembaruan...');
      }, 1400);

      const res = await fetch('/api/developer/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'github_install',
          downloadUrl: target.downloadUrl,
          fileName: target.name,
          notes: `Pembaruan otomatis dari GitHub (${target.name})`,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setUpdateSuccessResult(data);
        showNotification('success', data.message || 'Pembaruan dari GitHub berhasil diterapkan!');
        await fetchVersionData();
        await checkGithubUpdates(true);
      } else {
        showNotification('error', data.error || 'Gagal menerapkan pembaruan dari GitHub');
      }
    } catch (err: any) {
      showNotification('error', `Terjadi kesalahan saat menerapkan pembaruan: ${err.message}`);
    } finally {
      setIsInstallingGithubUpdate(false);
      setGithubInstallProgress('');
    }
  };

  // Inspect uploaded ZIP
  const handleFileSelected = async (file: File) => {
    if (!file.name.endsWith('.zip')) {
      showNotification('error', 'Format berkas tidak didukung. Harap pilih file berekstensi .zip');
      return;
    }
    setSelectedFile(file);
    setInspectionData(null);
    setUpdateSuccessResult(null);
    setIsInspecting(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('action', 'inspect');
      const res = await fetch('/api/developer/update', {
        method: 'POST',
        body: fd,
      });
      const data = await res.json();
      if (data.success) {
        setInspectionData(data);
        if (data.notes) setUpdateNotes(data.notes);
      } else {
        showNotification('error', data.error || 'Berkas ZIP tidak valid');
        setSelectedFile(null);
      }
    } catch (err: any) {
      showNotification('error', `Gagal memeriksa berkas ZIP: ${err.message}`);
      setSelectedFile(null);
    } finally {
      setIsInspecting(false);
    }
  };

  // Apply Update from ZIP
  const handleApplyUpdate = async () => {
    if (!selectedFile) return;
    setIsUpdating(true);
    setUpdateProgressMsg('1/3: Membuat arsip cadangan (backup) otomatis...');
    setUpdateSuccessResult(null);

    try {
      const fd = new FormData();
      fd.append('file', selectedFile);
      fd.append('action', 'apply');
      fd.append('notes', updateNotes);

      setTimeout(() => {
        setUpdateProgressMsg('2/3: Mengekstrak berkas & mengeksekusi migrasi database...');
      }, 1200);

      const res = await fetch('/api/developer/update', {
        method: 'POST',
        body: fd,
      });
      const data = await res.json();

      if (data.success) {
        setUpdateSuccessResult(data);
        showNotification('success', data.message || 'Pembaruan mandiri berhasil diterapkan!');
        setSelectedFile(null);
        setInspectionData(null);
        fetchVersionData();
      } else {
        showNotification('error', data.error || 'Pembaruan gagal. Sistem di-rollback ke versi sebelumnya.');
      }
    } catch (err: any) {
      showNotification('error', `Terjadi kesalahan saat menerapkan update: ${err.message}`);
    } finally {
      setIsUpdating(false);
      setUpdateProgressMsg('');
    }
  };

  // Execute Rollback
  const handleExecuteRollback = async () => {
    if (!selectedBackupForRollback) return;
    setIsRollingBack(true);
    try {
      const res = await fetch('/api/developer/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'rollback',
          backupFile: selectedBackupForRollback.fileName,
          targetVersion: selectedBackupForRollback.versionLabel,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showNotification('success', data.message || 'Aplikasi berhasil dikembalikan ke versi sebelumnya!');
        setRollbackModalOpen(false);
        setSelectedBackupForRollback(null);
        fetchVersionData();
      } else {
        showNotification('error', data.error || 'Gagal melakukan rollback.');
      }
    } catch (err: any) {
      showNotification('error', `Terjadi kesalahan rollback: ${err.message}`);
    } finally {
      setIsRollingBack(false);
    }
  };

  // Delete Version History Item
  const handleDeleteVersionHistory = async (item: any) => {
    if (!confirm(`Apakah Anda yakin ingin menghapus catatan riwayat versi ${item.version} beserta berkas cadangannya?`)) {
      return;
    }
    try {
      const res = await fetch(
        `/api/developer/update?version=${encodeURIComponent(item.version)}&backupFile=${encodeURIComponent(item.backupFile || '')}`,
        { method: 'DELETE' }
      );
      const data = await res.json();
      if (data.success) {
        showNotification('success', data.message || 'Riwayat versi berhasil dihapus');
        fetchVersionData();
      } else {
        showNotification('error', data.error || 'Gagal menghapus riwayat versi');
      }
    } catch (err: any) {
      showNotification('error', `Terjadi kesalahan saat menghapus: ${err.message}`);
    }
  };

  // 2. Fetch Developer Users (for refresh & actions)
  const fetchDevUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await fetch('/api/developer/users');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setDevUsers(data.data);
      } else {
        showNotification('error', data.error || 'Gagal memuat daftar developer');
      }
    } catch (err: any) {
      showNotification('error', err.message);
    } finally {
      setLoadingUsers(false);
    }
  };

  // 3. Fetch Database Status (for refresh & actions)
  const fetchDbStatus = async () => {
    try {
      const res = await fetch('/api/database/status');
      const data = await res.json();
      setDbStatus(data);
      if (data.config) {
        setDbForm({
          host: data.config.host || '',
          port: String(data.config.port || 3306),
          user: data.config.user || '',
          password: '',
          database: data.config.database || '',
        });
      }
    } catch {}
  };

  // Open Modal Create
  const handleOpenCreateModal = () => {
    setEditingUser(null);
    setUserForm({
      fullName: '',
      username: '',
      email: '',
      password: '',
    });
    setUserModalOpen(true);
  };

  // Open Modal Edit
  const handleOpenEditModal = (u: User) => {
    setEditingUser(u);
    setUserForm({
      fullName: u.fullName || '',
      username: u.username || '',
      email: u.email || '',
      password: '', // blank unless updating
    });
    setUserModalOpen(true);
  };

  // Submit User Form (Create / Edit)
  const handleSubmitUserForm = async (e: React.FormEvent) => {
    e.preventDefault();
    setUserFormSubmitting(true);
    try {
      if (userForm.password && userForm.password.trim().length > 0) {
        if (userForm.password.length < 8) {
          throw new Error('Kata sandi minimal 8 karakter');
        }
        if (!/[A-Z]/.test(userForm.password)) {
          throw new Error('Kata sandi wajib mengandung kombinasi huruf besar (A-Z)');
        }
        if (!/[a-z]/.test(userForm.password)) {
          throw new Error('Kata sandi wajib mengandung kombinasi huruf kecil (a-z)');
        }
      }

      if (editingUser) {
        // UPDATE
        const res = await fetch(`/api/developer/users/${editingUser.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(userForm),
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Gagal memperbarui akun developer');
        }
        showNotification('success', 'Akun developer berhasil diperbarui');
      } else {
        // CREATE
        if (!userForm.password) {
          throw new Error('Password wajib diisi untuk akun developer baru');
        }
        const res = await fetch('/api/developer/users', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(userForm),
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Gagal membuat akun developer');
        }
        showNotification('success', 'Akun developer baru berhasil didaftarkan');
      }
      setUserModalOpen(false);
      fetchDevUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    } finally {
      setUserFormSubmitting(false);
    }
  };

  // Delete User
  const handleDeleteUser = async (u: User) => {
    if (u.username.toLowerCase() === 'super') {
      alert('Akun developer root "super" dilindungi sistem dan tidak dapat dihapus.');
      return;
    }

    if (!confirm(`Apakah Anda yakin ingin menghapus akun developer "${u.fullName}" (${u.username})?`)) {
      return;
    }

    try {
      const res = await fetch(`/api/developer/users/${u.id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Gagal menghapus akun developer');
      }
      showNotification('success', 'Akun developer berhasil dihapus');
      fetchDevUsers();
    } catch (err: any) {
      showNotification('error', err.message);
    }
  };

  // Database Save & Test
  const handleTestAndSaveDb = async (e: React.FormEvent) => {
    e.preventDefault();
    setDbSetupLoading(true);
    setDbSetupMessage(null);
    try {
      const res = await fetch('/api/database/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: dbForm.host,
          port: Number(dbForm.port) || 3306,
          user: dbForm.user,
          password: dbForm.password,
          database: dbForm.database,
        }),
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.message || 'Koneksi gagal');
      }
      setDbSetupMessage({ success: true, text: 'Koneksi database berhasil diuji dan disimpan!' });
      fetchDbStatus();
    } catch (err: any) {
      setDbSetupMessage({ success: false, text: err.message });
    } finally {
      setDbSetupLoading(false);
    }
  };

  // Run Database Schema Setup
  const handleRunDatabaseSetup = async () => {
    if (!confirm(`Jalankan inisialisasi tabel dan struktur skema ke database "${dbForm.database || 'tujuan'}"?`)) {
      return;
    }
    setDbSetupLoading(true);
    setDbSetupMessage(null);
    try {
      const res = await fetch('/api/database/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: dbForm.host,
          port: Number(dbForm.port) || 3306,
          user: dbForm.user,
          password: dbForm.password,
          database: dbForm.database,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Gagal setup database');
      }
      setDbSetupMessage({ success: true, text: 'Inisialisasi schema & seed tabel berhasil dieksekusi!' });
      fetchDbStatus();
    } catch (err: any) {
      setDbSetupMessage({ success: false, text: err.message });
    } finally {
      setDbSetupLoading(false);
    }
  };

  // Loading state
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">
        <CircularLoading
          progress={75}
        />
      </div>
    );
  }

  // Access Denied State (Not Developer)
  if (!isDeveloper) {
    return (
      <div className="min-h-screen bg-slate-50">
        <AdminNavbar userFullName={currentUser?.fullName || 'User'} />
        <main className="max-w-3xl mx-auto px-4 py-16 text-center">
          <div className="bg-white p-8 sm:p-10 rounded-2xl border border-rose-200 shadow-sm space-y-4">
            <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <h1 className="text-xl font-bold text-slate-900">Akses Ditolak: Khusus Developer</h1>
            <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              Halaman Konsol Developer, manajemen akun developer, konfigurasi database MySQL, dan paket deploy produksi hanya dapat diakses oleh akun pengembang berotoritas Root (Developer).
            </p>
            <div className="pt-4 flex items-center justify-center gap-3">
              <Link
                href="/admin"
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition-colors"
              >
                Kembali ke Dashboard
              </Link>
              <Link
                href="/login"
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
              >
                Login Sebagai Developer
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <AdminNavbar userFullName={currentUser?.fullName || 'Super Developer'} />

      {/* Hero Developer Header */}
      <div className="bg-slate-900 border-b border-emerald-500/20 px-4 sm:px-6 lg:px-8 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="p-2 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-400 shadow-xs">
                <Terminal className="w-5 h-5" />
              </div>
              <h1 className="text-lg sm:text-xl font-black text-white tracking-tight">
                Konsol Developer & Root Control
              </h1>
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center space-x-1.5">
                  <Sparkles className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>Versi: {appVersion?.version || 'v05.09.2026'}</span>
                </span>
                <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                  ({appVersion?.versionName || '05 September 2026'})
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase font-mono bg-slate-800 text-slate-300 border border-slate-700">
                  Self-Update Mandiri
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl">
              Panel kendali pengembang: pembaruan aplikasi mandiri tanpa terminal, sistem rollback cadangan otomatis, manajemen akun root, koneksi database MySQL, dan paket deployment produksi.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <div className="px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Akun: <strong className="text-emerald-300 font-bold">{currentUser?.username || 'super'}</strong></span>
            </div>
            <button
              onClick={() => {
                fetchDevUsers();
                fetchVersionData();
                fetchDbStatus();
              }}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700"
              title="Refresh Data & Versi"
            >
              <RefreshCw className={`w-4 h-4 ${loadingVersion ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 w-full">
          <div
            className={`p-3.5 rounded-xl border text-xs flex items-center justify-between shadow-lg ${
              notification.type === 'success'
                ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
            }`}
          >
            <div className="flex items-center space-x-2">
              {notification.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span className="font-semibold">{notification.message}</span>
            </div>
            <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Console Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full flex-1 space-y-6">
        {/* Navigation Tabs Bar */}
        <div className="flex items-center space-x-2 border-b border-slate-800 overflow-x-auto pb-px">
          <button
            id="tab-dev-updates-btn"
            onClick={() => setActiveTab('updates')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all cursor-pointer shrink-0 ${
              activeTab === 'updates'
                ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500 border-x border-slate-800'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            <UploadCloud className="w-4 h-4" />
            <span>Pembaruan</span>
          </button>

          <button
            id="tab-dev-backup-db-btn"
            onClick={() => {
              setActiveTab('backup-db');
              fetchDbBackups();
            }}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all cursor-pointer shrink-0 ${
              activeTab === 'backup-db'
                ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500 border-x border-slate-800'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Backup Database</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
              {dbBackups.length} Berkas
            </span>
          </button>

          <button
            id="tab-dev-accounts-btn"
            onClick={() => setActiveTab('accounts')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all cursor-pointer shrink-0 ${
              activeTab === 'accounts'
                ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500 border-x border-slate-800'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Daftar Akun Developer</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
              {devUsers.length}
            </span>
          </button>

          <button
            id="tab-dev-database-btn"
            onClick={() => setActiveTab('database')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all cursor-pointer shrink-0 ${
              activeTab === 'database'
                ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500 border-x border-slate-800'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Database MySQL</span>
            <span
              className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                dbStatus?.mysqlConfigured
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-amber-950 text-amber-400 border border-amber-800'
              }`}
            >
              {dbStatus?.mysqlConfigured ? 'Connected' : 'Setup'}
            </span>
          </button>

          <button
            id="tab-dev-deploy-btn"
            onClick={() => setActiveTab('deploy')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all cursor-pointer shrink-0 ${
              activeTab === 'deploy'
                ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500 border-x border-slate-800'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Paket Deploy Produksi</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
              Build Siap
            </span>
          </button>
        </div>

        {/* TAB 0: SELF-UPDATE & VERSIONING */}
        {activeTab === 'updates' && (
          <div className="space-y-6">
            {/* Card 1: Version & Status Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-900/90 border border-emerald-500/30 p-5 rounded-2xl shadow-sm space-y-2 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-emerald-400 pointer-events-none">
                  <Sparkles className="w-24 h-24" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
                  <Package className="w-4 h-4" />
                  <span>Versi Aplikasi Saat Ini</span>
                </span>
                <div className="text-2xl sm:text-3xl font-black font-mono text-white tracking-tight">
                  {appVersion?.version || 'v05.09.2026'}
                </div>
                <p className="text-xs text-slate-300 font-medium">
                  {appVersion?.versionName || '05 September 2026'}
                </p>
                <div className="pt-2 text-[11px] text-slate-400 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Penamaan versi: <strong>jam.dd.mm.yy</strong></span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Server className="w-4 h-4 text-emerald-400" />
                  <span>Pembaruan Otomatis GitHub</span>
                </span>
                <div className="text-base font-bold text-white flex items-center space-x-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>Peta-Informasi-Update</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Sistem otomatis memeriksa repository GitHub untuk mendeteksi berkas update <code className="text-emerald-300 font-mono">gis_update_jam.dd.mm.yy</code> secara langsung.
                </p>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Undo2 className="w-4 h-4 text-amber-400" />
                  <span>Proteksi Cadangan & Rollback</span>
                </span>
                <div className="text-base font-bold text-white flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>Auto-Backup & 1-Click Rollback</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Sebelum berkas diperbarui, sistem otomatis mencadangkan file lama. Jika terjadi error, sistem langsung kembali ke versi sebelumnya.
                </p>
              </div>
            </div>

            {/* Card 2: GitHub Online Auto-Update Section */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <Sparkles className="w-5 h-5 text-amber-400" />
                    <span>Pembaruan Otomatis via GitHub Repository</span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    Memeriksa ketersediaan berkas update di repository <a href="https://github.com/hasyir87/Peta-Informasi-Update/tree/main" target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:underline inline-flex items-center space-x-1 font-mono"><span>https://github.com/hasyir87/Peta-Informasi-Update</span><ExternalLink className="w-3 h-3" /></a>
                  </p>
                </div>

                <button
                  onClick={() => checkGithubUpdates(false)}
                  disabled={checkingGithub || isInstallingGithubUpdate}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center space-x-2 transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${checkingGithub ? 'animate-spin' : ''}`} />
                  <span>{checkingGithub ? 'Memeriksa...' : 'Periksa Pembaruan GitHub'}</span>
                </button>
              </div>

              {/* GitHub Update Result / Notification Banner */}
              {githubCheckResult && (
                <div className="space-y-4">
                  {githubCheckResult.hasUpdate && githubCheckResult.latestUpdate ? (
                    <div className="bg-gradient-to-r from-emerald-950/90 via-slate-900 to-emerald-950/90 border-2 border-emerald-500/60 rounded-xl p-5 space-y-4 shadow-lg relative overflow-hidden">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start space-x-3">
                          <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/40 text-emerald-400 shrink-0 mt-0.5">
                            <Sparkles className="w-6 h-6 animate-pulse" />
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <span className="text-xs font-black uppercase tracking-wider text-emerald-400 bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-800">
                                Pemberitahuan Developer
                              </span>
                              <span className="text-xs font-mono text-slate-400">
                                GitHub Update Ditemukan!
                              </span>
                            </div>
                            <h3 className="text-base font-extrabold text-white">
                              Berkas Pembaruan Baru Tersedia: <code className="text-emerald-300 font-mono">{githubCheckResult.latestUpdate.name}</code>
                            </h3>
                            <p className="text-xs text-slate-300">
                              Versi Baru: <strong className="text-emerald-400 font-mono">{githubCheckResult.latestUpdate.version}</strong> ({githubCheckResult.latestUpdate.versionFriendly})
                            </p>
                          </div>
                        </div>

                        <a
                          href={githubCheckResult.latestUpdate.htmlUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium flex items-center space-x-1 shrink-0"
                        >
                          <span>Lihat di GitHub</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>

                      {/* Install Button & Progress */}
                      <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-emerald-800/40">
                        <div className="text-xs text-slate-400">
                          {isInstallingGithubUpdate ? (
                            <span className="text-amber-300 font-medium flex items-center space-x-2">
                              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                              <span>{githubInstallProgress || 'Proses pengunduhan & instalasi sedang berjalan...'}</span>
                            </span>
                          ) : (
                            <span>Klik tombol di sebelah kanan untuk mengunduh dan memasang pembaruan secara otomatis.</span>
                          )}
                        </div>

                        <button
                          onClick={() => handleInstallGithubUpdate(githubCheckResult.latestUpdate)}
                          disabled={isInstallingGithubUpdate}
                          className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black uppercase tracking-wider flex items-center justify-center space-x-2 shadow-md transition-all cursor-pointer disabled:opacity-50 shrink-0"
                        >
                          {isInstallingGithubUpdate ? (
                            <>
                              <RefreshCw className="w-4 h-4 animate-spin" />
                              <span>Sedang Menginstal...</span>
                            </>
                          ) : (
                            <>
                              <Download className="w-4 h-4" />
                              <span>Download & Install Pembaruan Mandiri</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-3">
                      <div className="flex items-center space-x-3">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                        <div className="space-y-0.5">
                          <p className="text-xs font-bold text-slate-200">
                            Aplikasi Anda sudah dalam versi terbaru ({githubCheckResult.currentVersion})
                          </p>
                          <p className="text-[11px] text-slate-400">
                            Tidak ditemukan berkas <code className="text-emerald-300 font-mono">gis_update_jam.dd.mm.yy.zip</code> baru di GitHub main branch.
                          </p>
                        </div>
                      </div>

                      <a
                        href="https://github.com/hasyir87/Peta-Informasi-Update/tree/main"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 font-medium shrink-0"
                      >
                        <span>Buka Repo GitHub</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  )}

                  {/* Remote files list if any */}
                  {githubCheckResult.remoteFiles && githubCheckResult.remoteFiles.length > 0 && (
                    <div className="space-y-2 pt-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                        Daftar Berkas Update Ditemukan di GitHub ({githubCheckResult.remoteFiles.length}):
                      </span>
                      <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto pr-1">
                        {githubCheckResult.remoteFiles.map((fileItem: any, idx: number) => (
                          <div
                            key={idx}
                            className="bg-slate-950/80 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between text-xs"
                          >
                            <div className="flex items-center space-x-2 overflow-hidden">
                              <Archive className="w-4 h-4 text-emerald-400 shrink-0" />
                              <span className="font-mono text-slate-200 truncate">{fileItem.name}</span>
                              <span className="text-[10px] text-slate-400 shrink-0">({fileItem.versionFriendly})</span>
                            </div>

                            <button
                              onClick={() => handleInstallGithubUpdate(fileItem)}
                              disabled={isInstallingGithubUpdate}
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-emerald-700 text-slate-200 hover:text-white text-[10px] font-bold transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                            >
                              Install Versi Ini
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Card 2: Upload ZIP & Apply Update */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <UploadCloud className="w-5 h-5 text-emerald-400" />
                    <span>Unggah Berkas ZIP Pembaruan Terbaru</span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    Masukkan file zip pembaruan (seperti <code className="text-emerald-300 font-mono">update-perubahan-peta-walhisumut.zip</code>). Aplikasi akan memperbarui diri secara otomatis.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="text-[11px] font-mono px-2 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    Format: .zip
                  </span>
                </div>
              </div>

              {/* Upload Dropzone */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    handleFileSelected(e.dataTransfer.files[0]);
                  }
                }}
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
                  selectedFile
                    ? 'border-emerald-500 bg-emerald-950/20'
                    : 'border-slate-700 hover:border-emerald-500/60 bg-slate-950/50'
                }`}
              >
                <input
                  type="file"
                  id="zip-update-input"
                  accept=".zip"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleFileSelected(e.target.files[0]);
                    }
                  }}
                />

                {!selectedFile ? (
                  <div className="space-y-4 cursor-pointer" onClick={() => document.getElementById('zip-update-input')?.click()}>
                    <div className="w-14 h-14 mx-auto rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                      <UploadCloud className="w-7 h-7" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-white">
                        Tarik dan lepas file ZIP pembaruan ke sini, atau klik untuk memilih
                      </p>
                      <p className="text-xs text-slate-400 max-w-md mx-auto">
                        Sistem akan menginspeksi file, membuat backup otomatis, mengekstrak perubahan, dan memperbarui versi aplikasi tanpa terminal.
                      </p>
                    </div>
                    <button
                      type="button"
                      className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                    >
                      Pilih Berkas ZIP
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-center space-x-3 text-emerald-400">
                      <Archive className="w-8 h-8" />
                      <div className="text-left">
                        <div className="text-sm font-bold text-white flex items-center space-x-2">
                          <span>{selectedFile.name}</span>
                          <span className="text-xs font-mono text-slate-400">
                            ({Math.round(selectedFile.size / 1024)} KB)
                          </span>
                        </div>
                        <p className="text-xs text-emerald-300">
                          {isInspecting ? 'Sedang menganalisis struktur paket ZIP...' : 'Berkas ZIP siap diproses.'}
                        </p>
                      </div>
                    </div>

                    {isInspecting && (
                      <div className="flex items-center justify-center space-x-2 text-xs text-slate-400">
                        <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                        <span>Membaca daftar berkas dan dependensi migrasi...</span>
                      </div>
                    )}

                    {inspectionData && (
                      <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-4 max-w-2xl mx-auto text-left space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                          <div className="flex items-center space-x-2">
                            <Sparkles className="w-4 h-4 text-emerald-400" />
                            <span className="text-xs font-bold text-slate-200">
                              Target Versi Baru:
                            </span>
                            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                              {inspectionData.targetVersion} ({inspectionData.targetVersionName})
                            </span>
                          </div>
                          <span className="text-xs text-slate-400 font-mono">
                            {inspectionData.files.length} Berkas Diperbarui
                          </span>
                        </div>

                        {/* SQL Migration Detected Notice */}
                        {inspectionData.sqlFiles?.length > 0 && (
                          <div className="p-2.5 rounded-lg bg-blue-950/50 border border-blue-800/40 text-blue-200 text-xs flex items-center space-x-2">
                            <Database className="w-4 h-4 text-blue-400 shrink-0" />
                            <span>
                              <strong>Migrasi Database Otomatis:</strong> Ditemukan file SQL ({inspectionData.sqlFiles.join(', ')}). Query akan dieksekusi secara otomatis saat update diterapkan.
                            </span>
                          </div>
                        )}

                        {/* Custom Notes */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                            Catatan Pembaruan (Opsional):
                          </label>
                          <input
                            type="text"
                            value={updateNotes}
                            onChange={(e) => setUpdateNotes(e.target.value)}
                            placeholder="Misal: Pembaruan fitur peta dan widget wordpress"
                            className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-hidden focus:border-emerald-500"
                          />
                        </div>

                        {/* File preview preview */}
                        <div className="space-y-1">
                          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                            Pratinjau Berkas yang Akan Ditimpa ({inspectionData.files.length}):
                          </label>
                          <div className="max-h-24 overflow-y-auto bg-slate-900/60 p-2 rounded-lg text-[10px] font-mono text-slate-400 space-y-0.5 border border-slate-800">
                            {inspectionData.files.slice(0, 10).map((f: string, idx: number) => (
                              <div key={idx} className="flex items-center space-x-1">
                                <FileText className="w-3 h-3 text-emerald-400 shrink-0" />
                                <span className="truncate">{f}</span>
                              </div>
                            ))}
                            {inspectionData.files.length > 10 && (
                              <div className="text-slate-500 pt-1">
                                ...dan {inspectionData.files.length - 10} berkas lainnya.
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Update CTA */}
                        <div className="pt-2 flex flex-wrap items-center justify-end gap-3">
                          <button
                            type="button"
                            disabled={isUpdating}
                            onClick={() => {
                              setSelectedFile(null);
                              setInspectionData(null);
                            }}
                            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
                          >
                            Batal
                          </button>
                          <button
                            type="button"
                            disabled={isUpdating}
                            onClick={handleApplyUpdate}
                            className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                          >
                            {isUpdating ? (
                              <>
                                <RefreshCw className="w-4 h-4 animate-spin" />
                                <span>Sedang Memperbarui...</span>
                              </>
                            ) : (
                              <>
                                <Rocket className="w-4 h-4" />
                                <span>Terapkan Pembaruan Sekarang (Update Mandiri)</span>
                              </>
                            )}
                          </button>
                        </div>

                        {isUpdating && updateProgressMsg && (
                          <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-2 animate-pulse">
                            <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
                            <span>{updateProgressMsg}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Success Result Box */}
              {updateSuccessResult && (
                <div className="p-5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-200 space-y-3">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        Pembaruan Berhasil Diterapkan Secara Mandiri!
                      </h4>
                      <p className="text-xs text-emerald-300">
                        {updateSuccessResult.message}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                    <div className="bg-emerald-900/40 p-2.5 rounded-lg border border-emerald-800/40">
                      <span className="text-slate-400 block text-[10px] uppercase font-mono">Versi Aplikasi:</span>
                      <strong className="text-white font-mono">{updateSuccessResult.previousVersion}</strong>
                      <span className="mx-2 text-emerald-400">➔</span>
                      <strong className="text-emerald-300 font-mono">{updateSuccessResult.newVersion}</strong>
                    </div>
                    <div className="bg-emerald-900/40 p-2.5 rounded-lg border border-emerald-800/40">
                      <span className="text-slate-400 block text-[10px] uppercase font-mono">Cadangan Tersimpan:</span>
                      <strong className="text-white font-mono truncate block">{updateSuccessResult.backupFile}</strong>
                    </div>
                  </div>

                  {updateSuccessResult.executedSql?.length > 0 && (
                    <div className="text-xs text-slate-300 bg-emerald-900/30 p-2.5 rounded-lg border border-emerald-800/30 space-y-1">
                      <span className="font-bold text-white block">Migrasi Database yang Dijalankan:</span>
                      <ul className="list-disc list-inside text-[11px] text-emerald-200">
                        {updateSuccessResult.executedSql.map((sql: string, idx: number) => (
                          <li key={idx} className="truncate">{sql}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Card 3: Version History & Rollback System */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <History className="w-5 h-5 text-emerald-400" />
                    <span>Riwayat Versi & Kembalikan ke Versi Sebelumnya (Rollback)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Jika terdapat kendala pada pembaruan terbaru, Anda dapat mengembalikan sistem ke versi sebelumnya hanya dengan satu klik tanpa perlu terminal.
                  </p>
                </div>

                <button
                  onClick={fetchVersionData}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition-colors flex items-center space-x-1.5 self-start cursor-pointer border border-slate-700"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingVersion ? 'animate-spin' : ''}`} />
                  <span>Segarkan Riwayat</span>
                </button>
              </div>

              {/* History Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/60 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Versi & Tanggal</th>
                      <th className="py-3 px-4">Keterangan Pembaruan</th>
                      <th className="py-3 px-4">Berkas Cadangan (Backup)</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Aksi Rollback & Hapus</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    {updateHistory.slice(0, 3).map((item: any, idx: number) => {
                      const hasBackup = Boolean(item.backupFile);
                      const isCurrent = idx === 0;

                      return (
                        <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3.5 px-4 font-mono">
                            <div className="flex items-center space-x-2">
                              <span className="font-bold text-white">{item.version}</span>
                              {isCurrent && (
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase">
                                  Aktif
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-400 block">{item.date}</span>
                          </td>

                          <td className="py-3.5 px-4 max-w-md">
                            <p className="text-slate-200 leading-snug">{item.notes}</p>
                            {item.filesCount > 0 && (
                              <span className="text-[10px] text-slate-400 font-mono">
                                ({item.filesCount} file diperbarui)
                              </span>
                            )}
                          </td>

                          <td className="py-3.5 px-4 font-mono text-[11px] text-slate-400">
                            {item.backupFile ? (
                              <div className="flex items-center space-x-1 text-slate-300">
                                <FolderArchive className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                <span className="truncate max-w-xs">{item.backupFile}</span>
                              </div>
                            ) : (
                              <span className="text-slate-600">-</span>
                            )}
                          </td>

                          <td className="py-3.5 px-4">
                            {item.status === 'rollback' ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30">
                                Rollback
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                                Sukses
                              </span>
                            )}
                          </td>

                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end space-x-2">
                              {hasBackup && !isCurrent ? (
                                <button
                                  onClick={() => {
                                    setSelectedBackupForRollback({
                                      fileName: item.backupFile,
                                      versionLabel: item.version,
                                      date: item.date,
                                    });
                                    setRollbackModalOpen(true);
                                  }}
                                  className="inline-flex items-center space-x-1 px-3 py-1 rounded-lg bg-amber-950/80 hover:bg-amber-900 border border-amber-500/40 text-amber-300 text-xs font-bold transition-colors cursor-pointer"
                                >
                                  <Undo2 className="w-3.5 h-3.5" />
                                  <span>Rollback</span>
                                </button>
                              ) : isCurrent ? (
                                <span className="text-[11px] text-emerald-400 font-mono font-bold">Versi Aktif</span>
                              ) : (
                                <span className="text-[11px] text-slate-600 font-mono">Tanpa Backup</span>
                              )}

                              <button
                                onClick={() => handleDeleteVersionHistory(item)}
                                title="Hapus catatan riwayat versi & berkas cadangan ini"
                                className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-red-950/70 hover:bg-red-900 border border-red-500/40 text-red-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Hapus</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}

                    {updateHistory.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-500 text-xs">
                          Belum ada catatan pembaruan mandiri.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB: DATABASE BACKUP */}
        {activeTab === 'backup-db' && (
          <div className="space-y-6">
            {/* Overview Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-900/90 border border-emerald-500/30 p-5 rounded-2xl shadow-sm space-y-2 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-emerald-400 pointer-events-none">
                  <Database className="w-24 h-24" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
                  <Server className="w-4 h-4" />
                  <span>Mode & Koneksi Basis Data</span>
                </span>
                <div className="text-xl sm:text-2xl font-bold font-mono text-white tracking-tight flex items-center space-x-2">
                  <span>{dbStats?.available ? 'MySQL Server' : 'Active Memory Sync'}</span>
                  <span className={`w-2.5 h-2.5 rounded-full ${dbStats?.available ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
                </div>
                <p className="text-xs text-slate-300 font-mono">
                  Database: <strong className="text-emerald-400">{dbStats?.databaseName || 'walhisum_gis'}</strong>
                </p>
                <div className="pt-2 text-[11px] text-slate-400 flex items-center space-x-2">
                  <span className="text-slate-400">Host:</span>
                  <span className="font-mono text-slate-300">{dbStats?.host || 'localhost'}</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <HardDrive className="w-4 h-4 text-emerald-400" />
                  <span>Total Rekord Data Terkini</span>
                </span>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Data Peta (WKR)</span>
                    <span className="text-lg font-mono font-black text-white">{dbStats?.counts?.maps ?? '—'}</span>
                  </div>
                  <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Kategori</span>
                    <span className="text-lg font-mono font-black text-white">{dbStats?.counts?.categories ?? '—'}</span>
                  </div>
                  <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Pengguna</span>
                    <span className="text-lg font-mono font-black text-white">{dbStats?.counts?.users ?? '—'}</span>
                  </div>
                  <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Pengaturan</span>
                    <span className="text-lg font-mono font-black text-white">{dbStats?.counts?.settings ?? '—'}</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Archive className="w-4 h-4 text-emerald-400" />
                  <span>Arsip Cadangan Tersimpan</span>
                </span>
                <div className="text-2xl font-black font-mono text-white flex items-center space-x-2">
                  <span>{dbBackups.length}</span>
                  <span className="text-xs text-slate-400 font-sans font-normal">Berkas .SQL Siap Pakai</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Cadangan mencakup struktur DDL, seluruh koordinat GeoJSON spasial polygon, kategori, dan hak akses pengguna secara utuh.
                </p>
                <div className="pt-2 text-[11px] text-emerald-400 flex items-center space-x-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Kompatibel phpMyAdmin & MySQL CLI</span>
                </div>
              </div>
            </div>

            {/* Form: Buat Backup Database Baru */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <Database className="w-5 h-5 text-emerald-400" />
                    <span>Buat Cadangan Database Baru (.SQL)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Mengekspor seluruh tabel dan data spasial GIS WALHI Sumut ke dalam satu berkas SQL terenkapsulasi siap unduh.
                  </p>
                </div>
              </div>

              <form onSubmit={handleCreateDbBackup} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 font-mono">
                    Catatan Cadangan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={dbBackupNotes}
                    onChange={(e) => setDbBackupNotes(e.target.value)}
                    placeholder="Contoh: Cadangan rutin sebelum pemutakhiran data batas kawasan WKR Deli Serdang..."
                    className="w-full px-4 py-2.5 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 font-sans"
                  />
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
                  <div className="text-xs text-slate-400 flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Format berkas: <strong>.SQL (UTF-8 MySQL 5.7+ / 8.0+ / MariaDB)</strong></span>
                  </div>

                  <button
                    type="submit"
                    disabled={isCreatingDbBackup}
                    className="inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-lg shadow-emerald-950/50 disabled:opacity-50"
                  >
                    {isCreatingDbBackup ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Sedang Membuat Backup SQL...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>Cadangkan Database Sekarang (.SQL)</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* Alert Feedback Saat Berhasil Dibuat */}
              {lastCreatedBackup && (
                <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                      <span className="text-xs font-bold text-white">
                        Cadangan Database Baru Berhasil Dibuat & Disimpan!
                      </span>
                    </div>
                    <button
                      onClick={() => setLastCreatedBackup(null)}
                      className="text-slate-400 hover:text-white text-xs"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-mono block">Nama File:</span>
                      <strong className="text-white font-mono text-[11px] truncate block">{lastCreatedBackup.fileName}</strong>
                    </div>
                    <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-mono block">Ukuran & Total Rekord:</span>
                      <strong className="text-emerald-300 font-mono text-[11px]">{lastCreatedBackup.formattedSize} ({lastCreatedBackup.records?.total || 0} baris data)</strong>
                    </div>
                    <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800 flex items-center justify-center">
                      <a
                        href={`/api/developer/database/backup?download=${encodeURIComponent(lastCreatedBackup.fileName)}`}
                        className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-xs"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Unduh File .SQL Ini</span>
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Card: Daftar Arsip Cadangan Database */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <Archive className="w-5 h-5 text-emerald-400" />
                    <span>Daftar Berkas Cadangan Database ({dbBackups.length})</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Seluruh file dump SQL tersimpan aman di server dan dapat diunduh kapan saja atau dipulihkan langsung.
                  </p>
                </div>

                <button
                  onClick={fetchDbBackups}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition-colors flex items-center space-x-1.5 self-start cursor-pointer border border-slate-700"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingDbBackups ? 'animate-spin' : ''}`} />
                  <span>Segarkan Daftar</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/60 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Nama Berkas .SQL</th>
                      <th className="py-3 px-4">Waktu Pembuatan</th>
                      <th className="py-3 px-4">Ukuran</th>
                      <th className="py-3 px-4">Rincian Data</th>
                      <th className="py-3 px-4">Sumber</th>
                      <th className="py-3 px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {dbBackups.map((b) => (
                      <tr key={b.fileName} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center space-x-2">
                            <FileText className="w-4 h-4 text-emerald-400 shrink-0" />
                            <div>
                              <span className="font-mono font-bold text-white block text-xs">{b.fileName}</span>
                              {b.notes && (
                                <span className="text-[11px] text-slate-400 block italic">{b.notes}</span>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-slate-300 whitespace-nowrap">
                          {b.formattedDate}
                        </td>
                        <td className="py-3 px-4 font-mono text-emerald-400 whitespace-nowrap">
                          {b.formattedSize}
                        </td>
                        <td className="py-3 px-4 text-slate-300 text-[11px] whitespace-nowrap">
                          {b.records ? (
                            <span className="font-mono">
                              {b.records.maps || 0} Peta • {b.records.categories || 0} Kat • {b.records.users || 0} User
                            </span>
                          ) : (
                            <span className="text-slate-500">—</span>
                          )}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                            {b.sourceLabel || b.source}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end space-x-2">
                            <a
                              href={`/api/developer/database/backup?download=${encodeURIComponent(b.fileName)}`}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-950 text-emerald-400 hover:bg-emerald-900 border border-emerald-800 text-[11px] font-bold transition-colors inline-flex items-center space-x-1"
                              title="Unduh Berkas .SQL ke Komputer"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Unduh</span>
                            </a>
                            <button
                              onClick={() => {
                                setSelectedDbBackupForRestore(b);
                                setRestoreDbModalOpen(true);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-amber-950 text-amber-400 hover:bg-amber-900 border border-amber-800 text-[11px] font-bold transition-colors inline-flex items-center space-x-1 cursor-pointer"
                              title="Pulihkan Database dari berkas ini"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>Pulihkan</span>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedDbBackupForDelete(b);
                                setDeleteDbBackupModalOpen(true);
                              }}
                              className="p-1.5 rounded-lg bg-rose-950 text-rose-400 hover:bg-rose-900 border border-rose-800 transition-colors cursor-pointer"
                              title="Hapus Berkas Cadangan"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {dbBackups.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                          Belum ada berkas cadangan database. Klik tombol &quot;Cadangkan Database Sekarang&quot; di atas untuk membuat backup pertama.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Petunjuk Tambahan: Impor cPanel / phpMyAdmin */}
            <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl space-y-2 text-xs text-slate-400">
              <h4 className="font-bold text-slate-200 flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Petunjuk Penggunaan Berkas Cadangan .SQL</span>
              </h4>
              <p className="leading-relaxed">
                Berkas .SQL yang diunduh adalah dump database standar industri MySQL/MariaDB. Berkas ini dapat langsung diimpor melalui:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                <li><strong>phpMyAdmin (cPanel):</strong> Buka database target, klik tab <strong>Import</strong>, pilih berkas .sql, lalu klik <strong>Go</strong>.</li>
                <li><strong>Terminal / SSH:</strong> Jalankan perintah <code className="text-emerald-300 bg-slate-950 px-1.5 py-0.5 rounded font-mono">mysql -u username -p database_name &lt; backup_file.sql</code></li>
                <li><strong>Tombol &quot;Pulihkan&quot; di atas:</strong> Sistem akan otomatis mengeksekusi dump SQL tersebut ke database aktif saat ini tanpa perlu restart server.</li>
              </ul>
            </div>
          </div>
        )}

        {/* TAB 1: ACCOUNTS */}
        {activeTab === 'accounts' && (
          <div className="space-y-6">
            {/* Info notice */}
            <div className="bg-slate-900/90 border border-emerald-500/20 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1.5">
                  <Shield className="w-4 h-4" />
                  <span>Isolasi Akun Khusus Pengembang (Root)</span>
                </h3>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  Semua akun di bawah ini memiliki hak akses developer penuh. Akun-akun ini <strong className="text-emerald-300">diisolasi dan TIDAK AKAN PERNAH muncul di menu &quot;Daftar Pengguna&quot;</strong> biasa agar kerahasiaan dan integritas akun developer tetap terjaga.
                </p>
              </div>
              <button
                id="btn-add-developer-user"
                onClick={handleOpenCreateModal}
                className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shrink-0 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Akun Developer</span>
              </button>
            </div>

            {/* Table of Developer Accounts */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-sm">
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Key className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                    Daftar Akun Developer Terdaftar ({devUsers.length})
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Default root: <code className="text-emerald-300 bg-slate-950 px-1.5 py-0.5 rounded">username: super</code> | <code className="text-emerald-300 bg-slate-950 px-1.5 py-0.5 rounded">password: super123</code>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                      <th className="px-5 py-3.5">Nama & Identitas</th>
                      <th className="px-5 py-3.5">Username</th>
                      <th className="px-5 py-3.5">Email</th>
                      <th className="px-5 py-3.5">Status & Otoritas</th>
                      <th className="px-5 py-3.5 text-right">Tindakan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {loadingUsers ? (
                      <tr>
                        <td colSpan={5} className="px-5 py-8 text-center text-slate-400">
                          <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-emerald-400" />
                          Memuat daftar akun developer...
                        </td>
                      </tr>
                    ) : devUsers.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-5 py-8 text-center text-slate-400">
                          Tidak ada akun developer terdaftar.
                        </td>
                      </tr>
                    ) : (
                      devUsers.map((u) => {
                        const isSuper = u.username.toLowerCase() === 'super';
                        return (
                          <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                            <td className="px-5 py-4">
                              <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-xs">
                                  {u.fullName?.charAt(0)?.toUpperCase() || 'D'}
                                </div>
                                <div>
                                  <div className="font-bold font-sans text-white flex items-center space-x-1.5">
                                    <span>{u.fullName}</span>
                                    {isSuper && (
                                      <span className="px-1.5 py-0.2 rounded text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                        DEFAULT ROOT
                                      </span>
                                    )}
                                  </div>
                                  <span className="text-[10px] text-slate-400 font-sans">
                                    Terdaftar: {u.createdAt ? new Date(u.createdAt).toLocaleDateString('id-ID') : '-'}
                                  </span>
                                </div>
                              </div>
                            </td>
                            <td className="px-5 py-4 font-bold text-emerald-300">
                              @{u.username}
                            </td>
                            <td className="px-5 py-4 text-slate-300 font-sans">
                              {u.email}
                            </td>
                            <td className="px-5 py-4">
                              <div className="flex items-center space-x-1.5">
                                <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-950 text-emerald-400 border border-emerald-700/50">
                                  <Check className="w-3 h-3" />
                                  <span>Developer</span>
                                </span>
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-blue-950 text-blue-400 border border-blue-800/50">
                                  Admin
                                </span>
                              </div>
                            </td>
                            <td className="px-5 py-4 text-right">
                              <div className="flex items-center justify-end space-x-2">
                                <button
                                  id={`btn-edit-dev-${u.id}`}
                                  onClick={() => handleOpenEditModal(u)}
                                  className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer transition-colors border border-slate-700"
                                >
                                  <Edit2 className="w-3.5 h-3.5 text-emerald-400" />
                                  <span className="font-sans">Edit</span>
                                </button>
                                {!isSuper ? (
                                  <button
                                    id={`btn-delete-dev-${u.id}`}
                                    onClick={() => handleDeleteUser(u)}
                                    className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-rose-950/60 hover:bg-rose-900 text-rose-300 text-xs font-semibold cursor-pointer transition-colors border border-rose-800/50"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span className="font-sans">Hapus</span>
                                  </button>
                                ) : (
                                  <span
                                    className="px-2 py-1 rounded text-[10px] text-slate-500 font-sans cursor-not-allowed"
                                    title="Akun super dilindungi dari penghapusan"
                                  >
                                    Protected
                                  </span>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: DATABASE MYSQL */}
        {activeTab === 'database' && (
          <div className="space-y-6">
            <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <Database className="w-4 h-4 text-emerald-400" />
                    <span>Konfigurasi & Konektivitas Database MySQL Eksternal</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Sesuaikan kredensial server basis data MySQL hosting Anda. Kredensial ini disimpan aman di sisi server runtime dan file .env.
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span
                    className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold ${
                      dbStatus?.mysqlConfigured
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-700'
                        : 'bg-amber-950 text-amber-400 border border-amber-700'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${dbStatus?.mysqlConfigured ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
                    <span>{dbStatus?.mysqlConfigured ? 'Terkoneksi' : 'Belum Terhubung'}</span>
                  </span>
                </div>
              </div>

              {dbSetupMessage && (
                <div
                  className={`p-4 rounded-xl border text-xs flex items-center space-x-2 ${
                    dbSetupMessage.success
                      ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300'
                      : 'bg-rose-950/70 border-rose-500/50 text-rose-300'
                  }`}
                >
                  {dbSetupMessage.success ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  )}
                  <span>{dbSetupMessage.text}</span>
                </div>
              )}

              {/* Form Database */}
              <form onSubmit={handleTestAndSaveDb} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Host / Server MySQL
                    </label>
                    <input
                      type="text"
                      value={dbForm.host}
                      onChange={(e) => setDbForm({ ...dbForm, host: e.target.value })}
                      placeholder="contoh: localhost atau ip_server"
                      className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Port
                    </label>
                    <input
                      type="text"
                      value={dbForm.port}
                      onChange={(e) => setDbForm({ ...dbForm, port: e.target.value })}
                      placeholder="3306"
                      className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Nama Database
                    </label>
                    <input
                      type="text"
                      value={dbForm.database}
                      onChange={(e) => setDbForm({ ...dbForm, database: e.target.value })}
                      placeholder="nama_db"
                      className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-emerald-400 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Username DB
                    </label>
                    <input
                      type="text"
                      value={dbForm.user}
                      onChange={(e) => setDbForm({ ...dbForm, user: e.target.value })}
                      placeholder="user_db"
                      className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Password DB
                    </label>
                    <div className="relative">
                      <input
                        id="dev-db-password-input"
                        type={showDbPassword ? 'text' : 'password'}
                        value={dbForm.password}
                        onChange={(e) => setDbForm({ ...dbForm, password: e.target.value })}
                        placeholder="••••••••"
                        className="w-full pl-3 pr-9 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                      <button
                        id="toggle-dev-db-password-btn"
                        type="button"
                        onClick={() => setShowDbPassword(!showDbPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer p-0.5"
                        title={showDbPassword ? 'Sembunyikan password' : 'Lihat password'}
                      >
                        {showDbPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="pt-3 flex flex-wrap items-center gap-3">
                  <button
                    type="submit"
                    disabled={dbSetupLoading}
                    className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{dbSetupLoading ? 'Menguji Koneksi...' : 'Uji & Simpan Koneksi'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleRunDatabaseSetup}
                    disabled={dbSetupLoading}
                    className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Inisialisasi Skema & Seed Otomatis</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* TAB 3: PAKET DEPLOY PRODUKSI */}
        {activeTab === 'deploy' && (
          <div className="space-y-6">
            <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-lg bg-emerald-950 border border-emerald-500/30 text-emerald-400">
                  <Rocket className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                    Paket Kompilasi Produksi Siap Pakai (.ZIP & .TAR.GZ)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Aplikasi telah selesai dikompilasi ke folder produksi (.next/standalone). Unduh paket lengkap untuk diekstrak langsung ke cPanel / Cloud Hosting tanpa perlu menjalankan npm run build di server.
                  </p>
                </div>
              </div>

              {/* Highlight Card: Paket Update Perubahan Terbaru & SQL Migrasi */}
              <div className="p-5 rounded-xl border-2 border-emerald-500 bg-emerald-950/40 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">
                      Pembaruan Terkini: Jumlah KK, Proses & Sinkronisasi Deskripsi
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 font-mono">
                    Termasuk File SQL Migrasi
                  </span>
                </div>
                <h4 className="text-base font-bold text-white">Paket Update Perubahan (.ZIP) & Berkas SQL Migrasi</h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Paket ZIP ini berisi berkas kode sumber yang diperbarui (tabel admin kolom <strong>Jumlah KK</strong> &amp; <strong>Proses</strong>, formulir tambah/edit peta, sinkronisasi deskripsi peta ke halaman utama), panduan penerapan (<code>PANDUAN_UPDATE.md</code>), serta berkas SQL pembaruan database <code>update_database_2026_09_04.sql</code>.
                </p>
                <div className="flex flex-wrap gap-3 pt-1">
                  <a
                    href="/api/export?type=update_zip"
                    download="update-perubahan-peta-walhisumut.zip"
                    className="inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-md"
                  >
                    <Download className="w-4 h-4" />
                    <span>Unduh Paket Update .ZIP</span>
                  </a>
                  <a
                    href="/update_database_2026_09_04.sql"
                    download="update_database_2026_09_04.sql"
                    className="inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer border border-amber-500/30"
                  >
                    <Database className="w-4 h-4 text-amber-400" />
                    <span>Unduh File SQL Migrasi Saja (.SQL)</span>
                  </a>
                  <a
                    href="/PANDUAN_UPDATE.md"
                    target="_blank"
                    className="inline-flex items-center justify-center space-x-2 px-3 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium transition-colors cursor-pointer border border-slate-700"
                  >
                    <span>Lihat Panduan Update (MD)</span>
                  </a>
                </div>
              </div>

              {/* Download cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 rounded-xl border border-emerald-500/30 bg-emerald-950/20 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">
                      Format Standar cPanel
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 font-mono">
                      Rekomendasi (Siap Pakai)
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">Paket Lengkap .ZIP (~27 MB)</h4>
                  <p className="text-xs text-slate-300">
                    Sangat cocok untuk diekstrak langsung melalui menu <strong>File Manager</strong> di cPanel / DomaiNesia dengan 1x klik. <em>Hasil build (.next) sudah terkompilasi, tidak perlu npm run build di server.</em>
                  </p>
                  <a
                    href="/api/export?type=deploy_zip"
                    download="deploy-peta-walhisumut.zip"
                    className="inline-flex items-center justify-center space-x-2 w-full px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Unduh Paket .ZIP Produksi</span>
                  </a>
                </div>

                <div className="p-5 rounded-xl border border-slate-700 bg-slate-950/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
                      Format Linux Kompresi
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 font-mono">
                      SSH / Terminal
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">Paket .TAR.GZ (~27 MB)</h4>
                  <p className="text-xs text-slate-300">
                    Ideal jika Anda mengunggah melalui SSH / SCP dan mengekstrak menggunakan perintah <code className="text-emerald-300 bg-slate-900 px-1 py-0.5 rounded font-mono">tar -xzf</code>.
                  </p>
                  <a
                    href="/api/export?type=deploy_tar"
                    download="deploy-peta-walhisumut.tar.gz"
                    className="inline-flex items-center justify-center space-x-2 w-full px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs border border-slate-700"
                  >
                    <Download className="w-4 h-4" />
                    <span>Unduh Paket .TAR.GZ</span>
                  </a>
                </div>
              </div>

              {/* PANDUAN DEPLOY LANGKAH DEMI LANGKAH */}
              <div className="p-5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-4">
                <div className="flex items-center space-x-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-white">
                    Panduan Lengkap Instalasi & Solusi Error 403 / 503 di cPanel (Port 40001)
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                      <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-[11px]">1</span>
                      <span>Upload & Ekstrak</span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      Upload file <code className="text-emerald-300 font-mono">deploy-peta-walhisumut.zip</code> ke folder root domain (misal: <code className="text-slate-200 font-mono">peta.walhisumut.or.id/</code>) di cPanel File Manager lalu <strong>Extract</strong>.
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                      <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-[11px]">2</span>
                      <span>Atur .env & .htaccess</span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      Buat / sesuaikan file <code className="text-emerald-300 font-mono">.env</code> dengan <code className="text-slate-200 font-mono">PORT=40001</code> dan salin aturan <code className="text-emerald-300 font-mono">.htaccess</code> proxy port 40001 di bawah.
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                      <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-[11px]">3</span>
                      <span>Install & Jalankan</span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      Jalankan <code className="text-emerald-300 font-mono">npm install --omit=dev</code> lalu start via PM2 atau tombol <strong>Restart</strong> pada menu Setup Node.js App.
                    </p>
                  </div>
                </div>

                {/* Penjelasan Error 403 & 503 */}
                <div className="p-4 rounded-lg bg-amber-950/20 border border-amber-500/30 text-xs space-y-2">
                  <div className="font-bold text-amber-300 flex items-center space-x-1.5">
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                    <span>Mengapa Terjadi Error 403 / 503?</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    <li><strong className="text-amber-200">Error 403 (Forbidden):</strong> Terjadi jika tanpa <code className="font-mono text-emerald-300">.htaccess</code> karena Apache menganggap folder web statis tanpa index.html.</li>
                    <li><strong className="text-amber-200">Error 503 (Service Unavailable):</strong> Terjadi jika <code className="font-mono text-emerald-300">.htaccess</code> sudah aktif namun proses Node.js di port 40001 belum menyala atau mengalami crash.</li>
                    <li><strong className="text-emerald-300">Solusi:</strong> Gunakan file <code className="font-mono text-emerald-300">.htaccess</code> di bawah, pastikan <code className="font-mono text-emerald-300">PORT=40001</code> di <code className="font-mono text-emerald-300">.env</code>, lalu jalankan server.js dengan PM2.</li>
                  </ul>
                </div>
              </div>

              {/* Quick Config Snippets */}
              <div className="space-y-4 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Konfigurasi Kunci Server (.htaccess & .env):
                </h4>

                {/* Snippet .htaccess Port 40001 */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-emerald-400 font-bold">.htaccess (Reverse Proxy Port 40001 - DomaiNesia / cPanel)</span>
                    <button
                      onClick={() => {
                        const snippet = `DirectoryIndex disabled\nRewriteEngine On\n\n# Pengecualian SSL Let's Encrypt\nRewriteCond %{REQUEST_URI} ^/\\.well-known/acme-challenge/ [NC]\nRewriteRule ^ - [L]\n\n# Sajikan file statis fisik saja jika ada\nRewriteCond %{REQUEST_FILENAME} -f\nRewriteRule ^ - [L]\n\n# Proxy semua request ke server Node.js port 40001\nRewriteRule ^$ http://127.0.0.1:40001/ [P,L]\nRewriteRule ^(.*)$ http://127.0.0.1:40001/$1 [P,L]\n\n# Header Proxy HTTPS\n<IfModule mod_headers.c>\n    RequestHeader set X-Forwarded-Proto "https" env=HTTPS\n    RequestHeader set X-Forwarded-Port "443" env=HTTPS\n</IfModule>`;
                        if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
                          navigator.clipboard.writeText(snippet).catch(() => {});
                        }
                        setCopiedSnippet('htaccess');
                        setTimeout(() => setCopiedSnippet(null), 2000);
                      }}
                      className="text-xs text-slate-400 hover:text-white flex items-center space-x-1 cursor-pointer"
                    >
                      {copiedSnippet === 'htaccess' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedSnippet === 'htaccess' ? 'Disalin' : 'Salin'}</span>
                    </button>
                  </div>
                  <pre className="text-[11px] font-mono text-slate-300 overflow-x-auto p-2.5 bg-slate-900 rounded-lg">
{`DirectoryIndex disabled
RewriteEngine On

# Pengecualian SSL Let's Encrypt
RewriteCond %{REQUEST_URI} ^/\\.well-known/acme-challenge/ [NC]
RewriteRule ^ - [L]

# Sajikan file statis fisik saja jika ada (misal gambar/css/js)
RewriteCond %{REQUEST_FILENAME} -f
RewriteRule ^ - [L]

# Proxy semua request ke server Node.js port 40001
RewriteRule ^$ http://127.0.0.1:40001/ [P,L]
RewriteRule ^(.*)$ http://127.0.0.1:40001/$1 [P,L]

# Header Proxy HTTPS
<IfModule mod_headers.c>
    RequestHeader set X-Forwarded-Proto "https" env=HTTPS
    RequestHeader set X-Forwarded-Port "443" env=HTTPS
</IfModule>`}
                  </pre>
                </div>

                {/* Snippet Perintah SSH / PM2 */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-emerald-400 font-bold">Perintah Terminal / SSH (Menyalakan Server)</span>
                    <button
                      onClick={() => {
                        const snippet = `cd ~/peta.walhisumut.or.id\nnpm install --omit=dev\nnpx pm2 start server.js --name "peta-walhisumut" -- --port 40001\nnpx pm2 save\ncurl -I http://127.0.0.1:40001`;
                        if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
                          navigator.clipboard.writeText(snippet).catch(() => {});
                        }
                        setCopiedSnippet('pm2');
                        setTimeout(() => setCopiedSnippet(null), 2000);
                      }}
                      className="text-xs text-slate-400 hover:text-white flex items-center space-x-1 cursor-pointer"
                    >
                      {copiedSnippet === 'pm2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedSnippet === 'pm2' ? 'Disalin' : 'Salin'}</span>
                    </button>
                  </div>
                  <pre className="text-[11px] font-mono text-slate-300 overflow-x-auto p-2.5 bg-slate-900 rounded-lg">
{`# 1. Masuk ke folder root aplikasi
cd ~/peta.walhisumut.or.id

# 2. Pasang library runtime
npm install --omit=dev

# 3. Jalankan aplikasi dengan PM2 di port 40001
npx pm2 start server.js --name "peta-walhisumut" -- --port 40001
npx pm2 save

# 4. Tes koneksi internal port
curl -I http://127.0.0.1:40001`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modal: Tambah / Edit Developer */}
      {userModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  {editingUser ? 'Edit Akun Developer' : 'Tambah Akun Developer Baru'}
                </h3>
              </div>
              <button
                onClick={() => setUserModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitUserForm} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  value={userForm.fullName}
                  onChange={(e) => setUserForm({ ...userForm, fullName: e.target.value })}
                  placeholder="Contoh: Super Developer"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  required
                  value={userForm.username}
                  onChange={(e) => setUserForm({ ...userForm, username: e.target.value.toLowerCase().trim() })}
                  placeholder="contoh: dev_lead"
                  className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-emerald-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  placeholder="developer@walhisumut.or.id"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  {editingUser ? 'Password Baru (Kosongkan bila tidak diubah)' : 'Password'}
                </label>
                <div className="relative">
                  <input
                    id="dev-user-password-input"
                    type={showUserPassword ? 'text' : 'password'}
                    required={!editingUser}
                    value={userForm.password}
                    onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                    placeholder={editingUser ? '•••••••• (kosongkan jika tidak diubah)' : 'Minimal 8 karakter (huruf besar & kecil)'}
                    className="w-full pl-3 pr-9 py-2 text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <button
                    id="toggle-dev-user-password-btn"
                    type="button"
                    onClick={() => setShowUserPassword(!showUserPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer p-0.5"
                    title={showUserPassword ? 'Sembunyikan password' : 'Lihat password'}
                  >
                    {showUserPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                {userForm.password.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2 text-[10px]">
                    <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded ${userForm.password.length >= 8 ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-700 font-bold' : 'bg-slate-900 text-slate-500'}`}>
                      <Check className={`w-3 h-3 ${userForm.password.length >= 8 ? 'text-emerald-400 stroke-[3]' : 'text-slate-600'}`} />
                      <span>Min. 8 Karakter</span>
                    </span>
                    <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded ${/[A-Z]/.test(userForm.password) ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-700 font-bold' : 'bg-slate-900 text-slate-500'}`}>
                      <Check className={`w-3 h-3 ${/[A-Z]/.test(userForm.password) ? 'text-emerald-400 stroke-[3]' : 'text-slate-600'}`} />
                      <span>Huruf Besar (A-Z)</span>
                    </span>
                    <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded ${/[a-z]/.test(userForm.password) ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-700 font-bold' : 'bg-slate-900 text-slate-500'}`}>
                      <Check className={`w-3 h-3 ${/[a-z]/.test(userForm.password) ? 'text-emerald-400 stroke-[3]' : 'text-slate-600'}`} />
                      <span>Huruf Kecil (a-z)</span>
                    </span>
                  </div>
                )}
              </div>

              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/40 text-[11px] text-emerald-300 space-y-1">
                <div className="font-bold flex items-center space-x-1">
                  <Shield className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Hak Akses Terjamin:</span>
                </div>
                <p className="text-slate-400">
                  Akun ini akan otomatis mendapatkan hak akses root (developer + admin) dan tidak akan terlihat di halaman Daftar Pengguna umum.
                </p>
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setUserModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={userFormSubmitting}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider cursor-pointer shadow-xs disabled:opacity-50"
                >
                  {userFormSubmitting ? 'Menyimpan...' : editingUser ? 'Simpan Perubahan' : 'Buat Akun Developer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Rollback Confirmation Modal */}
      {rollbackModalOpen && selectedBackupForRollback && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-amber-400">
              <div className="p-2.5 rounded-xl bg-amber-950/80 border border-amber-500/40">
                <Undo2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Konfirmasi Rollback Versi
                </h3>
                <p className="text-xs text-amber-400 font-mono">
                  Mengembalikan ke: {selectedBackupForRollback.versionLabel}
                </p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300 bg-slate-950/80 p-4 rounded-xl border border-slate-800">
              <p className="leading-relaxed">
                Anda akan mengembalikan seluruh berkas aplikasi ke kondisi cadangan versi <strong className="text-white font-mono">{selectedBackupForRollback.versionLabel}</strong> ({selectedBackupForRollback.date}).
              </p>
              <div className="pt-1 text-[11px] text-slate-400 font-mono">
                Arsip Cadangan: <span className="text-amber-300">{selectedBackupForRollback.fileName}</span>
              </div>
              <p className="text-[11px] text-emerald-400 pt-1">
                ✓ Proses berjalan otomatis tanpa perlu terminal atau restart manual.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end space-x-3">
              <button
                type="button"
                disabled={isRollingBack}
                onClick={() => {
                  setRollbackModalOpen(false);
                  setSelectedBackupForRollback(null);
                }}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isRollingBack}
                onClick={handleExecuteRollback}
                className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isRollingBack ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Memulihkan Versi...</span>
                  </>
                ) : (
                  <>
                    <Undo2 className="w-4 h-4" />
                    <span>Ya, Kembalikan Versi Ini</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Restore Database Confirmation Modal */}
      {restoreDbModalOpen && selectedDbBackupForRestore && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-amber-400">
              <div className="p-2.5 rounded-xl bg-amber-950/80 border border-amber-500/40">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Konfirmasi Pemulihan Database (.SQL)
                </h3>
                <p className="text-xs text-amber-400 font-mono truncate max-w-xs">
                  {selectedDbBackupForRestore.fileName}
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 bg-slate-950/80 p-4 rounded-xl border border-slate-800">
              <div className="flex items-start space-x-2 text-amber-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Peringatan Penting:</strong> Pemulihan database akan menimpa data saat ini dengan salinan cadangan tanggal <strong className="text-white font-mono">{selectedDbBackupForRestore.formattedDate}</strong>.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400">
                <div>Ukuran: <span className="text-white">{selectedDbBackupForRestore.formattedSize}</span></div>
                <div>Sumber: <span className="text-white">{selectedDbBackupForRestore.sourceLabel || selectedDbBackupForRestore.source}</span></div>
              </div>
              <p className="text-[11px] text-emerald-400 pt-1">
                ✓ Eksekusi SQL dump diproses langsung tanpa perlu restart server.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end space-x-3">
              <button
                type="button"
                disabled={isRestoringDb}
                onClick={() => {
                  setRestoreDbModalOpen(false);
                  setSelectedDbBackupForRestore(null);
                }}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isRestoringDb}
                onClick={handleExecuteRestoreDb}
                className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isRestoringDb ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Memulihkan Database...</span>
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-4 h-4" />
                    <span>Ya, Pulihkan Database Sekarang</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Database Backup Confirmation Modal */}
      {deleteDbBackupModalOpen && selectedDbBackupForDelete && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/40">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Hapus Berkas Cadangan SQL
                </h3>
                <p className="text-xs text-rose-400 font-mono truncate max-w-xs">
                  {selectedDbBackupForDelete.fileName}
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-300 bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2">
              <p>
                Apakah Anda yakin ingin menghapus berkas cadangan SQL ini secara permanen dari server? Tindakan ini tidak dapat dibatalkan.
              </p>
              <div className="text-[11px] font-mono text-slate-400">
                Ukuran: <span className="text-white">{selectedDbBackupForDelete.formattedSize}</span> • Tanggal: <span className="text-white">{selectedDbBackupForDelete.formattedDate}</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end space-x-3">
              <button
                type="button"
                disabled={isDeletingDbBackup}
                onClick={() => {
                  setDeleteDbBackupModalOpen(false);
                  setSelectedDbBackupForDelete(null);
                }}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isDeletingDbBackup}
                onClick={handleExecuteDeleteDbBackup}
                className="inline-flex items-center space-x-2 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isDeletingDbBackup ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Ya, Hapus Berkas</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
