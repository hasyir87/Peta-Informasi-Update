import type { Metadata } from 'next';
import './globals.css'; // Global styles
import { getSettingsAsync } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  let settings;
  try {
    settings = await getSettingsAsync();
  } catch {
    settings = null;
  }

  const allowIndexing = settings ? settings.searchEngineIndexingEnabled !== false : true;
  const tabTitle = settings?.browserTabTitle || settings?.title || 'Peta Interaktif Wilayah Kelola Rakyat - WALHI Sumatera Utara';
  const description = settings?.description || 'Peta Interaktif Kelompok WALHI Sumatera Utara berbasis Leaflet.js dan GeoJSON.';
  const defaultLogo = '/walhi-logo.svg';
  const defaultFavicon = '/favicon.ico';
  const favicon = settings?.faviconUrl || defaultFavicon;
  const logo = settings?.logoUrl || defaultLogo;

  const otherVerification: Record<string, string> = {};
  if (settings?.bingVerificationCode) {
    otherVerification['msvalidate.01'] = settings.bingVerificationCode;
  }

  return {
    title: tabTitle,
    description,
    robots: {
      index: allowIndexing,
      follow: allowIndexing,
      googleBot: {
        index: allowIndexing,
        follow: allowIndexing,
      },
    },
    verification: {
      google: settings?.googleVerificationCode || undefined,
      other: Object.keys(otherVerification).length > 0 ? otherVerification : undefined,
    },
    icons: {
      icon: favicon,
      shortcut: favicon,
      apple: favicon,
    },
    openGraph: {
      title: tabTitle,
      description,
      type: 'website',
      images: [logo],
    },
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  let settings;
  try {
    settings = await getSettingsAsync();
  } catch {
    settings = null;
  }

  const allowIndexing = settings ? settings.searchEngineIndexingEnabled !== false : true;
  const googleVerificationCode = settings?.googleVerificationCode || '';
  const bingVerificationCode = settings?.bingVerificationCode || '';
  const gaEnabled = Boolean(settings?.googleAnalyticsEnabled && settings?.googleAnalyticsId);
  const gaId = (settings?.googleAnalyticsId || '').trim();
  const defaultFavicon = '/favicon.ico';
  const favicon = settings?.faviconUrl || defaultFavicon;

  return (
    <html lang="id">
      <head>
        <link
          rel="icon"
          href={favicon}
          sizes="any"
        />
        <link
          rel="apple-touch-icon"
          href={favicon}
        />

        {/* Search Engine Robots Meta */}
        <meta
          name="robots"
          content={allowIndexing ? 'index, follow' : 'noindex, nofollow'}
        />

        {/* Google Search Console Site Verification */}
        {googleVerificationCode && (
          <meta name="google-site-verification" content={googleVerificationCode} />
        )}

        {/* Bing Webmaster Tools Site Verification */}
        {bingVerificationCode && (
          <meta name="msvalidate.01" content={bingVerificationCode} />
        )}

        {/* Google Analytics (gtag.js) */}
        {gaEnabled && gaId && (
          <>
            <script
              async
              src={`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(gaId)}`}
            />
            <script
              id="google-analytics-init"
              dangerouslySetInnerHTML={{
                __html: `
                  window.dataLayer = window.dataLayer || [];
                  function gtag(){dataLayer.push(arguments);}
                  gtag('js', new Date());
                  gtag('config', '${gaId.replace(/'/g, "\\'")}');
                `,
              }}
            />
          </>
        )}
      </head>
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
