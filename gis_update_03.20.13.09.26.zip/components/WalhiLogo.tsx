'use client';

import React from 'react';
import Image from 'next/image';

interface WalhiLogoProps {
  className?: string;
  width?: number;
  height?: number;
  showText?: boolean;
  animated?: boolean;
}

export default function WalhiLogo({
  className = '',
  width = 180,
  height = 110,
  showText = true,
  animated = false,
}: WalhiLogoProps) {
  return (
    <div
      className={`inline-flex flex-col items-center justify-center select-none ${
        animated ? 'animate-pulse transition-opacity duration-700 ease-in-out' : ''
      } ${className}`}
    >
      <div className="relative" style={{ width: `${width}px`, height: `${height}px` }}>
        <Image
          src="/walhi-logo.svg"
          alt="WALHI Sumatera Utara Logo"
          fill
          priority
          sizes="(max-width: 768px) 100vw, 300px"
          className="object-contain drop-shadow-xs"
        />
      </div>
    </div>
  );
}
