'use client';

import React from 'react';
import Image from 'next/image';

interface CircularLoadingProps {
  progress?: number;
  fullscreen?: boolean;
  size?: number;
  text?: string;
}

export default function CircularLoading({
  progress = 0,
  fullscreen = true,
}: CircularLoadingProps) {
  const clampedProgress = Math.min(100, Math.max(0, Math.round(progress)));

  const content = (
    <div className="flex flex-col items-center justify-center select-none text-center px-4 max-w-sm w-full animate-in fade-in duration-300">
      {/* WALHI Official Vector Logo with transparent background and subtle pulse */}
      <div className="relative w-48 sm:w-56 h-32 sm:h-36 mb-5 animate-pulse transition-opacity duration-1000 ease-in-out">
        <Image
          src="/walhi-logo.svg"
          alt="WALHI Sumatera Utara"
          fill
          priority
          sizes="260px"
          className="object-contain"
        />
      </div>

      {/* Progress Bar Container Underneath Logo (Clean, without text or percentage) */}
      <div className="w-full max-w-[200px] sm:max-w-[240px]">
        {/* Progress Bar Track */}
        <div className="w-full h-1.5 sm:h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200/80 shadow-inner">
          <div
            className="h-full bg-linear-to-r from-emerald-500 via-emerald-600 to-teal-500 rounded-full transition-all duration-200 ease-out shadow-xs"
            style={{ width: `${clampedProgress}%` }}
          />
        </div>
      </div>
    </div>
  );

  if (!fullscreen) {
    return content;
  }

  return (
    <div className="fixed inset-0 z-[100000] flex flex-col items-center justify-center bg-white/95 backdrop-blur-md pointer-events-auto select-none">
      {content}
    </div>
  );
}
