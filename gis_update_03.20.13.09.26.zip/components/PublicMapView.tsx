'use client';

import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  SUMUT_BOUNDS,
  SUMUT_KABUPATEN_LIST,
  SUMUT_REGIONAL_LABELS,
  SUMATERA_UTARA_GEOJSON,
  getSumutOuterBlankingGeoJSON,
  getEffectiveBoundaryGeoJSON,
  MEDAN_CITY_CENTER,
  isCoordinatesInsideSumut,
} from '@/lib/sumut-geojson';
import { Category, MapRecord, SiteSetting } from '@/lib/types';
import { trackGISClientEvent } from '@/lib/analytics-client';
import CircularLoading from '@/components/CircularLoading';
import {
  Layers,
  Filter,
  Search,
  MapPin,
  Database,
  Download,
  X,
  SlidersHorizontal,
  ChevronRight,
  Home,
  Building2,
  RotateCcw,
  Maximize2,
} from 'lucide-react';

interface PublicMapViewProps {
  initialMaps: MapRecord[];
  initialCategories: Category[];
  initialSettings: SiteSetting;
  hideHeader?: boolean;
}

export default function PublicMapView({
  initialMaps,
  initialCategories,
  initialSettings,
  hideHeader = false,
}: PublicMapViewProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const wkrLayerGroupRef = useRef<any>(null);
  const boundaryLayerRef = useRef<any>(null);
  const outerBlankLayerRef = useRef<any>(null);
  const sumutLabelsLayerRef = useRef<any>(null);
  const LRef = useRef<any>(null);

  // States
  const [maps, setMaps] = useState<MapRecord[]>(initialMaps);
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [settings, setSettings] = useState<SiteSetting>(initialSettings);
  const [selectedMap, setSelectedMap] = useState<MapRecord | null>(null);

  // Layer Toggles
  const [showWKRLayer, setShowWKRLayer] = useState(true);
  const [showSumutLabels, setShowSumutLabels] = useState(initialSettings.showSumutLabels ?? true);
  const [showOuterMask, setShowOuterMask] = useState(initialSettings.maskOutsideSumut ?? true);
  const [showBoundaryLayer, setShowBoundaryLayer] = useState(initialSettings.showBoundaryLayer ?? true);
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    initialCategories.map((c) => c.id)
  );
  const [selectedSubcategories, setSelectedSubcategories] = useState<string[]>(
    initialCategories.flatMap((c) => c.subcategories?.map((s) => s.id) || [])
  );

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchDropdownOpen, setIsSearchDropdownOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const [selectedKabupaten, setSelectedKabupaten] = useState<string>('all');
  const [basemap, setBasemap] = useState<'osm' | 'satellite' | 'topo'>('osm');

  // Loading animation state with percentage matching database
  const [loadingProgress, setLoadingProgress] = useState<number>(0);
  const [isLoadingActive, setIsLoadingActive] = useState<boolean>(true);
  const [totalDatabaseRecords, setTotalDatabaseRecords] = useState<number>(initialMaps?.length || 0);

  // Sync document title and favicon dynamically if provided
  useEffect(() => {
    if (settings?.browserTabTitle) {
      document.title = settings.browserTabTitle;
    }
  }, [settings?.browserTabTitle]);

  // Client-side fetch on mount for real-time live database synchronization with progress
  useEffect(() => {
    let progressTimer: any;
    let isMounted = true;

    // Smooth progress counter from 0 to 90%
    progressTimer = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev < 90) return prev + Math.floor(Math.random() * 10) + 5;
        return prev;
      });
    }, 100);

    const loadRealtimeData = async () => {
      try {
        const [mapsRes, catRes, setRes] = await Promise.all([
          fetch('/api/maps').then((r) => r.json()).catch(() => ({ data: [] })),
          fetch('/api/categories').then((r) => r.json()).catch(() => ({ data: [] })),
          fetch('/api/settings').then((r) => r.json()).catch(() => ({ data: null })),
        ]);

        if (!isMounted) return;

        if (mapsRes.data && Array.isArray(mapsRes.data)) {
          setMaps(mapsRes.data);
          setTotalDatabaseRecords(mapsRes.data.length);
        }
        if (catRes.data && Array.isArray(catRes.data)) {
          setCategories(catRes.data);
          setSelectedCategories((prev) => {
            const allCatIds = catRes.data.map((c: any) => c.id);
            return Array.from(new Set([...prev, ...allCatIds]));
          });
          setSelectedSubcategories((prev) => {
            const allSubIds = catRes.data.flatMap((c: any) => c.subcategories?.map((s: any) => s.id) || []);
            return Array.from(new Set([...prev, ...allSubIds]));
          });
        }
        if (setRes.data) {
          setSettings(setRes.data);
        }

        // Stop timer and set progress to 100%
        if (progressTimer) clearInterval(progressTimer);
        setLoadingProgress(100);
        setTimeout(() => {
          if (isMounted) {
            setIsLoadingActive(false);
          }
        }, 300);
      } catch (err) {
        console.warn('Realtime database sync warning:', err);
        if (progressTimer) clearInterval(progressTimer);
        setLoadingProgress(100);
        setTimeout(() => {
          if (isMounted) setIsLoadingActive(false);
        }, 300);
      }
    };

    loadRealtimeData();

    return () => {
      isMounted = false;
      if (progressTimer) clearInterval(progressTimer);
    };
  }, []);

  // UI state
  const [isLegendOpen, setIsLegendOpen] = useState(false);
  const [isBasemapOpen, setIsBasemapOpen] = useState(false);
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);
  const [isSqlModalOpen, setIsSqlModalOpen] = useState(false);
  const [activeSqlTab, setActiveSqlTab] = useState<'zip' | 'shp' | 'geojson' | 'kml' | 'kmz' | 'postgis' | 'mysql'>('zip');
  const [sqlContent, setSqlContent] = useState<string>('');
  const mapControlsRef = useRef<HTMLDivElement>(null);
  const isClient = React.useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );

  // Close Layer / Basemap / Search popovers when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (
        mapControlsRef.current &&
        !mapControlsRef.current.contains(event.target as Node)
      ) {
        setIsBasemapOpen(false);
        setIsLegendOpen(false);
      }
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setIsSearchDropdownOpen(false);
      }
    };

    document.addEventListener('pointerdown', handleClickOutside);
    return () => {
      document.removeEventListener('pointerdown', handleClickOutside);
    };
  }, []);

  // Draggable Legend coordinates
  const [legendPos, setLegendPos] = useState({ x: 20, y: 80 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef({ startX: 0, startY: 0, initialX: 0, initialY: 0 });

  // Zoom directly to map record fitting polygon boundaries (Zoom langsung ke lokasi tanpa menampilkan modal deskripsi)
  const zoomToMapRecord = useCallback((record: MapRecord, openDetail = false) => {
    if (!mapInstanceRef.current || !LRef.current) return;
    const map = mapInstanceRef.current;
    const L = LRef.current;

    let zoomed = false;

    // 1. Try to compute bounds from geometry (Polygon or MultiPolygon)
    if (record.geometry) {
      try {
        let geoData = record.geometry;
        if (typeof geoData === 'string') {
          try {
            geoData = JSON.parse(geoData);
          } catch {}
        }
        const geoLayer = L.geoJSON(geoData as any);
        const bounds = geoLayer.getBounds();
        if (bounds && bounds.isValid()) {
          map.fitBounds(bounds, {
            padding: [45, 45],
            maxZoom: 16,
            animate: true,
          });
          zoomed = true;
        }
      } catch (err) {
        console.warn('zoomToMapRecord fitBounds warning:', err);
      }
    }

    // 2. Fallback to center coordinates if geometry bounds was unavailable
    if (
      !zoomed &&
      typeof record.latitude === 'number' &&
      typeof record.longitude === 'number' &&
      !isNaN(record.latitude) &&
      !isNaN(record.longitude)
    ) {
      map.setView([record.latitude, record.longitude], 15, { animate: true });
      zoomed = true;
    }

    if (openDetail) {
      setSelectedMap(record);
    } else {
      setSelectedMap(null); // Jangan tampilkan modal deskripsi saat dipilih dari hasil search
    }
  }, []);

  // Filtered maps
  // User Request #5: search strictly by group name (m.name) only
  const filteredMaps = useMemo(() => {
    return maps.filter((m) => {
      if (m.status && m.status.toLowerCase() === 'inactive') return false;
      if (selectedCategories.length > 0 && m.categoryId && !selectedCategories.includes(m.categoryId)) {
        return false;
      }
      if (selectedSubcategories.length > 0 && m.subcategoryId && !selectedSubcategories.includes(m.subcategoryId)) {
        return false;
      }
      if (selectedKabupaten !== 'all' && m.kabupaten && m.kabupaten !== selectedKabupaten) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return m.name.toLowerCase().includes(q);
      }
      return true;
    });
  }, [maps, selectedCategories, selectedSubcategories, selectedKabupaten, searchQuery]);

  // Autocomplete matching groups strictly by name
  const matchingSearchGroups = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim();
    return maps.filter((m) => {
      if (m.status && m.status.toLowerCase() === 'inactive') return false;
      return m.name.toLowerCase().includes(q);
    });
  }, [maps, searchQuery]);

  // Total stats based on currently displayed active layers
  const totalStats = useMemo(() => {
    const activeDisplayed = showWKRLayer ? filteredMaps : [];
    const totalAreaHa = activeDisplayed.reduce((acc, curr) => acc + (curr.areaHa || 0), 0);
    return {
      count: activeDisplayed.length,
      areaHa: totalAreaHa.toLocaleString('id-ID', { maximumFractionDigits: 1 }),
      categoriesCount: new Set(activeDisplayed.map((m) => m.categoryId)).size,
    };
  }, [filteredMaps, showWKRLayer]);

  // Function to render WKR Polygons with custom styling, popups & click events
  // User Request #6: Robust Polygon and MultiPolygon rendering with L.geoJSON in dedicated wkrPane
  const renderWKRPolygons = useCallback((L: any, map: any, group: any, records: MapRecord[]) => {
    group.clearLayers();

    records.forEach((record) => {
      const catColor = record.categoryColor || '#10b981';
      let geom = record.geometry;

      if (typeof geom === 'string') {
        try {
          geom = JSON.parse(geom);
        } catch {
          geom = null as any;
        }
      }

      const tooltipContent = `
        <div style="font-family: inherit; width: 100%; max-width: 280px; min-width: 180px; word-break: break-word; overflow-wrap: break-word; box-sizing: border-box;">
          <div style="display: inline-block; padding: 2px 7px; border-radius: 4px; font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; background-color: ${catColor}20; color: ${catColor}; border: 1px solid ${catColor}40; margin-bottom: 5px;">
            ${record.categoryName || 'WKR'} ${record.subcategoryName ? '• ' + record.subcategoryName : ''}
          </div>
          <div style="font-weight: 800; font-size: 13px; color: #0f172a; line-height: 1.35; margin-bottom: 6px; word-break: break-word;">
            ${record.name}
          </div>
          <div style="font-size: 11px; color: #475569; line-height: 1.5; border-top: 1px solid #f1f5f9; padding-top: 5px; display: flex; flex-direction: column; gap: 3px;">
            <div style="word-break: break-word;">📍 <strong>Lokasi:</strong> ${record.desa ? 'Desa ' + record.desa + ', ' : ''}${record.kecamatan ? 'Kec. ' + record.kecamatan + ', ' : ''}${record.kabupaten || 'Sumut'}</div>
            <div>📐 <strong>Luas:</strong> ${record.areaHa ? record.areaHa.toLocaleString('id-ID') + ' Ha' : '-'}</div>
            ${record.kkCount || record.jumlahKk ? `<div>👥 <strong>Jumlah KK:</strong> ${(record.kkCount || record.jumlahKk)?.toLocaleString('id-ID')} KK</div>` : ''}
            ${record.proses ? `<div style="word-break: break-word;">⚡ <strong>Proses:</strong> ${record.proses}</div>` : ''}
            ${record.komoditi ? `<div style="word-break: break-word;">🌱 <strong>Komoditi:</strong> ${record.komoditi}</div>` : ''}
          </div>
        </div>
      `;

      let hasRendered = false;

      // Render polygon/multipolygon via Leaflet geoJSON for complete format support
      if (geom && geom.coordinates && Array.isArray(geom.coordinates) && geom.coordinates.length > 0) {
        try {
          const geoLayer = L.geoJSON(geom as any, {
            pane: 'wkrPane',
            style: () => ({
              color: catColor,
              fillColor: catColor,
              fillOpacity: 0.55,
              weight: 2.5,
              className: 'cursor-pointer transition-all hover:fill-opacity-80',
            }),
            pointToLayer: (_feature: any, latlng: any) => {
              const customIcon = L.divIcon({
                className: 'custom-point-marker',
                html: `<div style="background-color: ${catColor}; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
                iconSize: [16, 16],
                iconAnchor: [8, 8],
              });
              return L.marker(latlng, { icon: customIcon, pane: 'wkrPane' });
            },
            onEachFeature: (_feature: any, layer: any) => {
              layer.bindTooltip(tooltipContent, { sticky: true, opacity: 0.95 });
              layer.on('click', () => {
                setSelectedMap(record);
                trackGISClientEvent('view_map', {
                  mapId: record.id,
                  mapName: record.name,
                  categoryId: record.categoryId,
                  categoryName: record.categoryName,
                });
              });
            },
          });

          group.addLayer(geoLayer);
          hasRendered = true;
        } catch (err) {
          console.warn('L.geoJSON render error for record:', record.id, err);
        }
      }

      // Point fallback if no polygon geometry was rendered but lat/lng are provided
      if (
        !hasRendered &&
        typeof record.latitude === 'number' &&
        typeof record.longitude === 'number' &&
        !isNaN(record.latitude) &&
        !isNaN(record.longitude)
      ) {
        const customIcon = L.divIcon({
          className: 'custom-point-marker',
          html: `<div style="background-color: ${catColor}; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
          iconSize: [16, 16],
          iconAnchor: [8, 8],
        });

        const marker = L.marker([record.latitude, record.longitude], {
          icon: customIcon,
          pane: 'wkrPane',
        });
        marker.bindTooltip(tooltipContent, { sticky: true, opacity: 0.95 });
        marker.on('click', () => {
          setSelectedMap(record);
          trackGISClientEvent('view_map', {
            mapId: record.id,
            mapName: record.name,
            categoryId: record.categoryId,
            categoryName: record.categoryName,
          });
        });
        group.addLayer(marker);
      }
    });
  }, []);

  // Render Sumatera Utara Regional & Peripheral Border Labels (strictly within Sumut)
  const renderSumutLabels = useCallback((L: any, map: any, group: any) => {
    if (!group || !map) return;
    group.clearLayers();
    const currentZoom = map.getZoom();

    SUMUT_REGIONAL_LABELS.forEach((place) => {
      const minZoom = place.minZoom ?? 8;
      if (currentZoom < minZoom) return;

      const isKota = place.category === 'kota';
      const isPerbatasan = place.category === 'perbatasan';
      const isPesisir = place.category === 'pesisir';

      let dotColor = 'bg-emerald-600 ring-1 ring-white';
      let textColor = 'text-slate-800 font-semibold';

      if (isKota) {
        dotColor = 'bg-amber-600 ring-1.5 ring-white';
        textColor = 'text-amber-950 font-extrabold';
      } else if (isPerbatasan) {
        dotColor = 'bg-emerald-700 ring-1.5 ring-white';
        textColor = 'text-emerald-950 font-bold';
      } else if (isPesisir) {
        dotColor = 'bg-teal-600 ring-1.5 ring-white';
        textColor = 'text-teal-950 font-bold';
      }

      const html = `
        <div class="inline-flex items-center gap-1 -translate-x-1/2 -translate-y-1/2 pointer-events-none select-none">
          <span class="w-1.5 h-1.5 rounded-full ${dotColor} shrink-0 drop-shadow-xs"></span>
          <span class="text-[10px] sm:text-[11px] ${textColor} bg-transparent whitespace-nowrap tracking-tight leading-none [text-shadow:_0_1px_2px_rgba(255,255,255,0.95),_0_-1px_2px_rgba(255,255,255,0.95),_1px_0_2px_rgba(255,255,255,0.95),_-1px_0_2px_rgba(255,255,255,0.95)]">
            ${place.name}
          </span>
        </div>
      `;

      const icon = L.divIcon({
        className: 'sumut-territory-label',
        html,
        iconSize: [0, 0],
        iconAnchor: [0, 0],
      });

      const marker = L.marker([place.lat, place.lng], {
        icon,
        pane: 'labelsPane',
        interactive: false,
      });
      group.addLayer(marker);
    });
  }, []);

  // Helper to fit North Sumatra bounds strictly and edge-to-edge according to device screen dimensions
  const fitToDeviceSumutBounds = useCallback((mapParam?: any, animate = false) => {
    const map = mapParam || mapInstanceRef.current;
    const L = LRef.current;
    if (!map || typeof window === 'undefined') return;

    if (L && L.latLng && L.latLngBounds) {
      // Coordinate bounds covering all of Sumatera Utara (mainland, Nias, Batu islands, Samosir, border points)
      const sumutSouthWest = L.latLng(-0.65, 96.8);
      const sumutNorthEast = L.latLng(4.35, 100.45);
      const sumutBounds = L.latLngBounds(sumutSouthWest, sumutNorthEast);

      try {
        map.fitBounds(sumutBounds, {
          padding: [2, 2], // Fit seamlessly up to the edge of the viewport frame
          animate,
        });
        return;
      } catch {
        // Fallback below
      }
    }
    try {
      map.setView(SUMUT_BOUNDS.center, SUMUT_BOUNDS.zoom, { animate });
    } catch {
      // Ignore
    }
  }, []);

  // Reset Map View to default full North Sumatra (Home) adapted to device
  const handleResetToHome = useCallback(() => {
    setSelectedMap(null);
    setSelectedKabupaten('all');
    fitToDeviceSumutBounds(mapInstanceRef.current, true);
  }, [fitToDeviceSumutBounds]);

  // Leaflet map initialization
  useEffect(() => {
    if (!isClient || !mapContainerRef.current) return;

    let isMounted = true;
    const containerEl = mapContainerRef.current;
    let localMap: any = null;
    let resizeObserver: any = null;

    const handleResize = () => {
      if (isMounted && mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    };
    window.addEventListener('resize', handleResize);

    const initMap = async () => {
      const LModule = await import('leaflet');
      const L = (LModule as any).default || LModule;
      if (!L || !L.Icon) return;
      LRef.current = L;

      // Fix default Leaflet icon paths
      delete (L.Icon.Default.prototype as any)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
      });

      if (!containerEl || !isMounted) return;

      // Ensure container has fresh state
      if ((containerEl as any)._leaflet_id) {
        (containerEl as any)._leaflet_id = null;
      }

      // Initialize map strictly bounded to North Sumatra
      const sumutSouthWest = L.latLng(-2.0, 94.5);
      const sumutNorthEast = L.latLng(6.0, 102.5);
      const sumutMaxBounds = L.latLngBounds(sumutSouthWest, sumutNorthEast);

      const centerLat = typeof settings.mapCenterLat === 'number' && !isNaN(settings.mapCenterLat) ? settings.mapCenterLat : SUMUT_BOUNDS.center[0];
      const centerLng = typeof settings.mapCenterLng === 'number' && !isNaN(settings.mapCenterLng) ? settings.mapCenterLng : SUMUT_BOUNDS.center[1];

      const map = L.map(containerEl, {
        center: [centerLat, centerLng],
        zoom: typeof settings.mapZoom === 'number' && !isNaN(settings.mapZoom) ? settings.mapZoom : 8,
        minZoom: 5,
        maxZoom: 18,
        zoomSnap: 0.1,
        zoomDelta: 0.5,
        maxBounds: sumutMaxBounds,
        maxBoundsViscosity: 0.8,
        zoomControl: false,
        fadeAnimation: false,
      });

      localMap = map;
      mapInstanceRef.current = map;

      // Attribution (User Request #3: hapus credit walhi sumut pada Peta)
      if (map.attributionControl) {
        map.attributionControl.setPrefix(
          '<a href="https://leafletjs.com" title="A JS library for interactive maps" style="color: #475569; text-decoration: none; font-weight: 500;">Leaflet</a>'
        );
      }

      // Automatically adjust and fit North Sumatra bounds tailored to device screen
      fitToDeviceSumutBounds(map, false);

      // Invalidate size slightly after mount to guarantee full viewport utilization
      setTimeout(() => {
        if (isMounted && map) {
          map.invalidateSize();
          fitToDeviceSumutBounds(map, false);
        }
      }, 150);

      if (typeof ResizeObserver !== 'undefined') {
        resizeObserver = new ResizeObserver(() => {
          if (isMounted && map) {
            map.invalidateSize();
          }
        });
        resizeObserver.observe(containerEl);
      }

      // Close popovers on map click
      map.on('click', () => {
        setIsBasemapOpen(false);
        setIsLegendOpen(false);
      });

      // Basemap layers
      const tileLayers: Record<string, any> = {
        osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors',
          maxZoom: 19,
        }),
        satellite: L.tileLayer(
          'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
          {
            attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the User Community',
            maxZoom: 18,
          }
        ),
        topo: L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
          attribution: 'Map data: &copy; OpenStreetMap contributors, SRTM | Map style: &copy; OpenTopoMap',
          maxZoom: 17,
        }),
      };

      tileLayers[basemap].addTo(map);
      (map as any)._activeTileLayer = tileLayers[basemap];
      (map as any)._allTiles = tileLayers;

      // Custom panes for layered rendering
      if (!map.getPane('maskPane')) {
        const maskPane = map.createPane('maskPane');
        maskPane.style.zIndex = '350';
      }

      if (!map.getPane('wkrPane')) {
        const wkrPane = map.createPane('wkrPane');
        wkrPane.style.zIndex = '450';
      }

      if (!map.getPane('labelsPane')) {
        const labelsPane = map.createPane('labelsPane');
        labelsPane.style.zIndex = '550';
        labelsPane.style.pointerEvents = 'none';
      }

      // Outer Blanking Mask (Masking non-Sumut regions)
      const customBoundary = settings?.sumutBoundaryGeoJSON || initialSettings?.sumutBoundaryGeoJSON;
      const effectiveBoundary = getEffectiveBoundaryGeoJSON(customBoundary);
      const outerBlankingGeo = getSumutOuterBlankingGeoJSON(customBoundary);

      const outerBlankLayer = L.geoJSON(outerBlankingGeo as any, {
        pane: 'maskPane',
        style: {
          fillColor: '#ffffff',
          fillOpacity: 1.0,
          weight: 0,
          color: 'transparent',
          interactive: false,
        },
      });
      if (showOuterMask && (settings?.maskOutsideSumut ?? true)) {
        outerBlankLayer.addTo(map);
      }
      outerBlankLayerRef.current = outerBlankLayer;

      // Province Boundary Line (Garis biasa warna hitam tipis)
      const boundaryLayer = L.geoJSON(effectiveBoundary as any, {
        style: {
          color: '#000000',
          weight: 1,
          fill: false,
          interactive: false,
        },
      });
      if (showBoundaryLayer) {
        boundaryLayer.addTo(map);
      }
      boundaryLayerRef.current = boundaryLayer;

      // Sumatera Utara Regional & Peripheral Labels Layer (Never obscured by mask or boundaries)
      const sumutLabelsGroup = L.featureGroup();
      if (showSumutLabels) {
        sumutLabelsGroup.addTo(map);
      }
      sumutLabelsLayerRef.current = sumutLabelsGroup;
      renderSumutLabels(L, map, sumutLabelsGroup);

      // Listen to zoom changes to update label density smoothly
      map.on('zoomend', () => {
        if (!isMounted || !mapInstanceRef.current || !sumutLabelsLayerRef.current) return;
        renderSumutLabels(L, mapInstanceRef.current, sumutLabelsLayerRef.current);
      });

      // WKR Group Layer
      const wkrGroup = L.featureGroup();
      if (showWKRLayer) {
        wkrGroup.addTo(map);
      }
      wkrLayerGroupRef.current = wkrGroup;

      // Render WKR Polygons
      renderWKRPolygons(L, map, wkrGroup, filteredMaps);
    };

    initMap();

    return () => {
      isMounted = false;
      window.removeEventListener('resize', handleResize);
      if (resizeObserver) {
        resizeObserver.disconnect();
        resizeObserver = null;
      }
      if (localMap) {
        try {
          localMap.stop();
          localMap.closePopup();
          localMap.off();
          if (wkrLayerGroupRef.current) {
            wkrLayerGroupRef.current.clearLayers();
          }
          if (sumutLabelsLayerRef.current) {
            sumutLabelsLayerRef.current.clearLayers();
          }
          if (outerBlankLayerRef.current && localMap.hasLayer(outerBlankLayerRef.current)) {
            localMap.removeLayer(outerBlankLayerRef.current);
          }
          if (boundaryLayerRef.current && localMap.hasLayer(boundaryLayerRef.current)) {
            localMap.removeLayer(boundaryLayerRef.current);
          }
          localMap.remove();
        } catch {
          // Ignore Leaflet unmount cleanup exceptions
        }
        localMap = null;
        mapInstanceRef.current = null;
      }
      if (containerEl) {
        (containerEl as any)._leaflet_id = null;
      }
    };
    // Initialize map ONCE on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isClient]);

  // Switch basemap layer dynamically
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;
    if (map._activeTileLayer) {
      map.removeLayer(map._activeTileLayer);
    }
    if (map._allTiles && map._allTiles[basemap]) {
      map._allTiles[basemap].addTo(map);
      map._activeTileLayer = map._allTiles[basemap];
    }
  }, [basemap]);

  // Toggle WKR Layer
  useEffect(() => {
    if (!mapInstanceRef.current || !wkrLayerGroupRef.current) return;
    const map = mapInstanceRef.current;
    const group = wkrLayerGroupRef.current;
    if (showWKRLayer) {
      if (!map.hasLayer(group)) group.addTo(map);
    } else {
      if (map.hasLayer(group)) map.removeLayer(group);
    }
  }, [showWKRLayer]);

  // Toggle Sumut Territorial & Border Labels Layer
  useEffect(() => {
    if (!mapInstanceRef.current || !sumutLabelsLayerRef.current) return;
    const map = mapInstanceRef.current;
    const group = sumutLabelsLayerRef.current;
    if (showSumutLabels) {
      if (!map.hasLayer(group)) group.addTo(map);
      if (LRef.current) {
        renderSumutLabels(LRef.current, map, group);
      }
    } else {
      if (map.hasLayer(group)) map.removeLayer(group);
    }
  }, [showSumutLabels, renderSumutLabels]);

  // Toggle Outer Blanking Layer
  useEffect(() => {
    if (!mapInstanceRef.current || !outerBlankLayerRef.current) return;
    const map = mapInstanceRef.current;
    const layer = outerBlankLayerRef.current;
    if (showOuterMask) {
      if (!map.hasLayer(layer)) layer.addTo(map);
    } else {
      if (map.hasLayer(layer)) map.removeLayer(layer);
    }
  }, [showOuterMask]);

  // Toggle Province Boundary Layer
  useEffect(() => {
    if (!mapInstanceRef.current || !boundaryLayerRef.current) return;
    const map = mapInstanceRef.current;
    const layer = boundaryLayerRef.current;
    if (showBoundaryLayer) {
      if (!map.hasLayer(layer)) layer.addTo(map);
    } else {
      if (map.hasLayer(layer)) map.removeLayer(layer);
    }
  }, [showBoundaryLayer]);

  // Re-render polygons when filtered maps change
  useEffect(() => {
    if (!mapInstanceRef.current || !wkrLayerGroupRef.current || !LRef.current) return;
    renderWKRPolygons(LRef.current, mapInstanceRef.current, wkrLayerGroupRef.current, filteredMaps);
  }, [filteredMaps, renderWKRPolygons]);

  // Zoom to specific Kabupaten
  const handleSelectKabupaten = (kabName: string) => {
    setSelectedKabupaten(kabName);
    if (kabName === 'all') {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.setView(SUMUT_BOUNDS.center, SUMUT_BOUNDS.zoom);
      }
      return;
    }
    const item = SUMUT_KABUPATEN_LIST.find((k) => k.name === kabName);
    if (item && mapInstanceRef.current) {
      mapInstanceRef.current.setView([item.lat, item.lng], item.zoom);
    }
  };

  // Search query tracking debounce
  useEffect(() => {
    if (!searchQuery || searchQuery.trim().length < 3) return;
    const timer = setTimeout(() => {
      trackGISClientEvent('search_query', { query: searchQuery.trim() });
    }, 1200);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Category toggle
  const toggleCategory = (catId: string) => {
    const cat = categories.find((c) => c.id === catId);
    if (cat) {
      trackGISClientEvent('filter_category', { categoryId: cat.id, categoryName: cat.name });
    }
    const subIds = cat?.subcategories?.map((s) => s.id) || [];
    setSelectedCategories((prev) => {
      const isSel = prev.includes(catId);
      if (isSel) {
        if (subIds.length > 0) {
          setSelectedSubcategories((subPrev) => subPrev.filter((id) => !subIds.includes(id)));
        }
        return prev.filter((id) => id !== catId);
      } else {
        if (subIds.length > 0) {
          setSelectedSubcategories((subPrev) => Array.from(new Set([...subPrev, ...subIds])));
        }
        return [...prev, catId];
      }
    });
  };

  const toggleSubcategory = (subId: string) => {
    setSelectedSubcategories((prev) =>
      prev.includes(subId) ? prev.filter((id) => id !== subId) : [...prev, subId]
    );
  };

  // Legend Drag Handlers (Matching Image 1: "Tarik untuk geser")
  const handleDragStart = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: legendPos.x,
      initialY: legendPos.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - dragStartRef.current.startX;
      const dy = e.clientY - dragStartRef.current.startY;
      setLegendPos({
        x: Math.max(10, Math.min(window.innerWidth - 320, dragStartRef.current.initialX + dx)),
        y: Math.max(70, Math.min(window.innerHeight - 380, dragStartRef.current.initialY + dy)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  // Load spatial export / database data for modal
  const openSqlModal = async (type: 'zip' | 'shp' | 'geojson' | 'kml' | 'kmz' | 'postgis' | 'mysql') => {
    setActiveSqlTab(type);
    setIsSqlModalOpen(true);
    trackGISClientEvent('download_data', { format: type });
    try {
      if (type === 'zip' || type === 'shp' || type === 'kmz') {
        setSqlContent(`/* File biner spasial siap diunduh */\nFormat: ${type.toUpperCase()}\nStatus: Siap diunduh sebagai berkas biner/arsip (.${type}).\n\nKlik tombol hijau di bawah untuk mengunduh seluruh data spasial.`);
        return;
      }
      const res = await fetch(`/api/export?type=${type}`);
      if (type === 'geojson') {
        const json = await res.json();
        setSqlContent(JSON.stringify(json, null, 2));
      } else {
        const text = await res.text();
        setSqlContent(text);
      }
    } catch {
      setSqlContent('-- Gagal memuat script data spasial');
    }
  };

  // Reusable search box component (rendered in header on main page, or as floating card in widget mode)
  const renderSearchBox = (isFloating: boolean = false) => (
    <div
      ref={searchContainerRef}
      className={
        isFloating
          ? 'relative w-44 xs:w-56 sm:w-72 md:w-80 shrink-0 z-[1001]'
          : 'relative w-36 xs:w-48 sm:w-60 md:w-[320px] shrink-0 z-[50001]'
      }
    >
      <div className={`relative ${isFloating ? 'bg-white/95 backdrop-blur-md rounded-lg sm:rounded-xl border border-slate-200/90 shadow-lg' : ''}`}>
        <Search className={`text-slate-400 absolute left-2.5 sm:left-3 md:left-4 top-1/2 -translate-y-1/2 pointer-events-none ${isFloating ? 'w-4 h-4' : 'w-4 h-4 md:w-5 md:h-5'}`} />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setIsSearchDropdownOpen(true);
          }}
          onFocus={() => setIsSearchDropdownOpen(true)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              if (matchingSearchGroups.length > 0) {
                zoomToMapRecord(matchingSearchGroups[0]);
                setIsSearchDropdownOpen(false);
              }
            }
          }}
          placeholder="masukan nama kelompok"
          className={
            isFloating
              ? 'w-full pl-8 sm:pl-9 md:pl-10 pr-7 sm:pr-8 py-1.5 sm:py-2 bg-transparent text-xs sm:text-sm focus:outline-hidden text-slate-900 font-medium placeholder:text-slate-400 placeholder:italic'
              : 'w-full pl-8 sm:pl-9 md:pl-12 pr-7 sm:pr-8 md:pr-10 py-1.5 md:py-2.5 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden text-slate-900 transition-all font-medium placeholder:text-slate-400 placeholder:italic'
          }
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setIsSearchDropdownOpen(false);
            }}
            className="absolute right-2 sm:right-2.5 md:right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
            title="Hapus pencarian"
          >
            <X className="w-3.5 h-3.5 md:w-4 md:h-4" />
          </button>
        )}
      </div>

      {/* Autocomplete Dropdown List - Positioned strictly in front of everything on map */}
      {isSearchDropdownOpen && searchQuery.trim() && (
        <div
          className={`absolute top-full ${
            isFloating ? 'left-0' : 'right-0'
          } mt-1.5 w-[min(calc(100vw-24px),380px)] bg-white rounded-xl shadow-2xl border-2 border-emerald-500 overflow-hidden z-[50002] max-h-72 sm:max-h-80 overflow-y-auto ring-4 ring-black/20 animate-in fade-in slide-in-from-top-1 duration-150`}
        >
          {matchingSearchGroups.length > 0 ? (
            <>
              <div className="px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-600 bg-slate-100 border-b border-slate-200 flex items-center justify-between sticky top-0 z-10">
                <span>Hasil Kelompok ({matchingSearchGroups.length})</span>
                <span className="text-[10px] text-emerald-700 font-extrabold">Pilih untuk zoom</span>
              </div>
              {matchingSearchGroups.slice(0, 20).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    zoomToMapRecord(item);
                    setIsSearchDropdownOpen(false);
                  }}
                  className="w-full text-left px-3.5 py-2.5 hover:bg-emerald-50/90 border-b border-slate-100 last:border-0 flex items-center justify-between transition-colors cursor-pointer group"
                >
                  <div className="min-w-0 pr-2">
                    <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-700 truncate">
                      {item.name}
                    </div>
                    <div className="text-[10px] text-slate-500 truncate mt-0.5">
                      {item.desa ? `Desa ${item.desa}, ` : ''}{item.kabupaten || 'Sumut'}
                      {item.areaHa ? ` • ${item.areaHa.toLocaleString('id-ID')} Ha` : ''}
                    </div>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-bold opacity-0 group-hover:opacity-100 transition-opacity flex items-center shrink-0 pl-1">
                    Zoom <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                </button>
              ))}
            </>
          ) : (
            <div className="px-4 py-4 text-center text-xs text-slate-500 font-medium">
              Tidak ada kelompok dengan nama &quot;{searchQuery}&quot;
            </div>
          )}
        </div>
      )}
    </div>
  );

  return (
    <div
      className={`relative w-full overflow-hidden flex flex-col bg-[#f8fafc] font-sans text-slate-800 ${
        hideHeader ? 'h-full min-h-full' : 'h-[100dvh] min-h-[100dvh] max-h-[100dvh]'
      }`}
    >
      {/* Realtime Center Circular Loading with Percentage in Center */}
      {isLoadingActive && (
        <CircularLoading
          progress={loadingProgress}
        />
      )}

      {/* Top Navigation Bar with High Z-Index so search dropdown is never covered - Hidden in widget mode */}
      {!hideHeader && (
        <header className="h-14 sm:h-16 md:h-24 bg-white border-b border-slate-200 z-[50000] px-3 sm:px-6 md:px-9 flex items-center justify-between gap-3 shadow-xs shrink-0 relative">
          <div className="flex items-center gap-2 sm:gap-3.5 md:gap-5 min-w-0">
            <a
              href="https://walhisumut.or.id"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center shrink-0 hover:opacity-90 transition-opacity"
              title="Kunjungi situs resmi"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={settings?.logoUrl || 'https://walhisumut.or.id/wp-content/uploads/2023/12/WALHIBAWAH2-1.png'}
                alt="Logo Peta"
                className="h-8 sm:h-10 md:h-[60px] max-w-[200px] w-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </a>
            <div className="border-l border-slate-200 pl-2 sm:pl-3 md:pl-5 min-w-0">
              <h1 className="text-xs sm:text-base md:text-2xl font-bold tracking-tight text-slate-900 leading-tight truncate">
                {settings?.navbarTitle || 'Peta Interaktif WALHI Sumatera Utara'}
              </h1>
              <p className="text-[10px] sm:text-[11px] md:text-sm text-slate-500 mt-0.5 hidden xs:block truncate">
                Provinsi Sumatera Utara
              </p>
            </div>
          </div>

          {/* Right Corner Search Bar with Elevated Dropdown Suggestions */}
          {renderSearchBox(false)}
        </header>
      )}

      {/* Main Map Container */}
      <div className="relative flex-1 w-full h-full">
        {/* Floating Search Bar on Top-Left when in Widget Mode (No Header) */}
        {hideHeader && (
          <div className="absolute top-3 left-3 sm:top-4 sm:left-4 z-[1001] select-none">
            {renderSearchBox(true)}
          </div>
        )}

        {!isClient && (
          <div className="w-full h-full flex items-center justify-center bg-[#f8fafc] text-slate-500 font-medium">
            Memuat Peta Spasial Sumatera Utara...
          </div>
        )}
        <div ref={mapContainerRef} className="w-full h-full" />

        {/* Top-Right Unified Map Control Bar (Home, Zoom, Basemap, Legenda) */}
        <div ref={mapControlsRef} className="absolute top-3 right-3 sm:top-4 sm:right-4 z-1000 flex flex-col items-end space-y-2 select-none">
          {/* Main Controls Row */}
          <div className="bg-white/95 backdrop-blur-md p-1 sm:p-1.5 rounded-lg sm:rounded-xl shadow-xl border border-slate-200/90 flex items-center space-x-1 sm:space-x-1.5">
            {/* Home Button */}
            <button
              type="button"
              onClick={handleResetToHome}
              title="Kembali ke Ukuran & Posisi Awal Peta Sumatera Utara (Home)"
              className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-md sm:rounded-lg text-[11px] sm:text-xs font-bold transition-all flex items-center space-x-1 cursor-pointer border bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 shadow-2xs"
            >
              <Home className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="hidden xs:inline">Home</span>
            </button>

            <div className="w-px h-4 sm:h-5 bg-slate-200/90 my-auto" />

            {/* Zoom Control Group */}
            <div className="flex items-center bg-slate-100/90 rounded-md sm:rounded-lg p-0.5 border border-slate-200/80">
              <button
                type="button"
                onClick={() => mapInstanceRef.current?.zoomIn()}
                title="Perbesar (Zoom In)"
                className="w-6 h-6 sm:w-7 sm:h-7 flex items-center justify-center rounded font-bold text-slate-700 hover:bg-white hover:text-slate-900 transition-all cursor-pointer text-xs sm:text-sm shadow-2xs"
              >
                +
              </button>
              <div className="w-px h-3 sm:h-3.5 bg-slate-300 mx-0.5" />
              <button
                type="button"
                onClick={() => mapInstanceRef.current?.zoomOut()}
                title="Perkecil (Zoom Out)"
                className="w-6 h-6 sm:w-7 sm:h-7 flex items-center justify-center rounded font-bold text-slate-700 hover:bg-white hover:text-slate-900 transition-all cursor-pointer text-xs sm:text-sm shadow-2xs"
              >
                −
              </button>
            </div>

            <div className="w-px h-4 sm:h-5 bg-slate-200/90 my-auto" />

            {/* Basemap Button */}
            <button
              type="button"
              onClick={() => {
                setIsBasemapOpen(!isBasemapOpen);
                setIsLegendOpen(false);
              }}
              className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded-md sm:rounded-lg text-[11px] sm:text-xs font-bold transition-all flex items-center space-x-1 sm:space-x-1.5 cursor-pointer border ${
                isBasemapOpen
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>Basemap</span>
            </button>

            {/* Legenda / Layer Button */}
            <button
              type="button"
              onClick={() => {
                setIsLegendOpen(!isLegendOpen);
                setIsBasemapOpen(false);
              }}
              className={`px-2 sm:px-3 py-1 sm:py-1.5 rounded-md sm:rounded-lg text-[11px] sm:text-xs font-bold transition-all flex items-center space-x-1 sm:space-x-1.5 cursor-pointer border ${
                isLegendOpen
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>Layer</span>
            </button>
          </div>

          {/* Simplified Basemap Switcher Popover Panel (Horizontal Layout) */}
          {isBasemapOpen && (
            <div className="bg-white/95 backdrop-blur-md p-1.5 rounded-xl shadow-xl border border-slate-200 animate-in fade-in slide-in-from-top-2 duration-150 flex flex-row items-center gap-1.5 overflow-x-auto max-w-[calc(100vw-2rem)]">
              <button
                type="button"
                onClick={() => {
                  setBasemap('osm');
                  setIsBasemapOpen(false);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 whitespace-nowrap ${
                  basemap === 'osm'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span>Standar</span>
                {basemap === 'osm' && <span className="text-xs font-bold text-emerald-400">✓</span>}
              </button>
              <button
                type="button"
                onClick={() => {
                  setBasemap('satellite');
                  setIsBasemapOpen(false);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 whitespace-nowrap ${
                  basemap === 'satellite'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span>Satellite</span>
                {basemap === 'satellite' && <span className="text-xs font-bold text-emerald-400">✓</span>}
              </button>
              <button
                type="button"
                onClick={() => {
                  setBasemap('topo');
                  setIsBasemapOpen(false);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 whitespace-nowrap ${
                  basemap === 'topo'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span>Terrain</span>
                {basemap === 'topo' && <span className="text-xs font-bold text-emerald-400">✓</span>}
              </button>
            </div>
          )}

          {/* Layer Popover Panel */}
          {isLegendOpen && (
            <div className="w-[calc(100vw-1.5rem)] sm:w-80 max-w-sm bg-white/95 backdrop-blur-md rounded-xl shadow-2xl border border-slate-200 overflow-hidden select-none animate-in fade-in slide-in-from-top-2 duration-150">
              {/* Header */}
              <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Layers className="w-3.5 h-3.5 text-emerald-600" />
                  <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Layer
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsLegendOpen(false)}
                  className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Layer Items List */}
              <div className="p-3 space-y-3 max-h-88 overflow-y-auto">
                {/* Wilayah Kelola Rakyat (WKR) Section */}
                <div className="space-y-1.5">
                  <div className="px-1 py-0.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Kategori
                    </span>
                  </div>

                  {categories.map((cat) => {
                    const isSelected = selectedCategories.includes(cat.id);
                    const count = maps.filter((m) => m.categoryId === cat.id && m.status === 'Active').length;
                    const hasSub = cat.subcategories && cat.subcategories.length > 0;

                    return (
                      <div key={cat.id} className="space-y-1">
                        <label
                          className={`flex items-center justify-between px-3 py-2 rounded-sm text-xs cursor-pointer transition-all border select-none ${
                            isSelected
                              ? 'bg-slate-50/80 hover:bg-slate-100/90 border-slate-200 text-slate-800 shadow-2xs'
                              : 'opacity-40 hover:opacity-70 bg-transparent border-transparent text-slate-400'
                          }`}
                          style={{
                            borderLeftWidth: isSelected ? '4px' : '1px',
                            borderLeftColor: isSelected ? (cat.strokeColor || cat.color) : 'transparent',
                          }}
                        >
                          <div className="flex items-center space-x-2.5">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleCategory(cat.id)}
                              className="w-3.5 h-3.5 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600 shrink-0"
                              aria-label={`Pilih layer ${cat.name}`}
                            />
                            <span
                              className="w-3.5 h-3.5 rounded-xs inline-block shrink-0 shadow-2xs"
                              style={{
                                backgroundColor: cat.color,
                              }}
                            />
                            <span className="font-semibold text-slate-700">
                              {cat.name}
                            </span>
                          </div>

                          <div className="flex items-center space-x-1.5">
                            <span className="text-[11px] text-slate-500 font-mono font-bold">({count})</span>
                          </div>
                        </label>

                        {/* Subcategories (if any) */}
                        {hasSub && isSelected && (
                          <div className="ml-5 pl-2 border-l-2 border-slate-200 space-y-1 py-1">
                            {cat.subcategories!.map((sub) => {
                              const isSubSelected = selectedSubcategories.includes(sub.id);
                              const subCount = maps.filter(
                                (m) => m.subcategoryId === sub.id && m.status === 'Active'
                              ).length;
                              const subColor = sub.color || cat.color;

                              return (
                                <label
                                  key={sub.id}
                                  className={`flex items-center justify-between px-2.5 py-1 rounded text-[11px] cursor-pointer transition-all select-none ${
                                    isSubSelected
                                      ? 'bg-blue-50/70 text-blue-900 font-medium'
                                      : 'opacity-50 text-slate-500 hover:opacity-80'
                                  }`}
                                >
                                  <div className="flex items-center space-x-2">
                                    <input
                                      type="checkbox"
                                      checked={isSubSelected}
                                      onChange={() => toggleSubcategory(sub.id)}
                                      className="w-3 h-3 rounded text-blue-600 border-slate-300 focus:ring-blue-500 cursor-pointer accent-blue-600 shrink-0"
                                    />
                                    <span
                                      className="w-2.5 h-2.5 rounded-xs inline-block shrink-0 shadow-2xs"
                                      style={{ backgroundColor: subColor }}
                                    />
                                    <span>{sub.name}</span>
                                  </div>
                                  <span className="text-[10px] text-slate-400 font-mono font-bold">({subCount})</span>
                                </label>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom-Left Summary Floating Card (Total Luas & Total Kelompok) */}
        <div className="absolute bottom-2 left-2 sm:bottom-4 sm:left-4 z-1000 select-none pointer-events-auto">
          <div className="bg-white/95 backdrop-blur-md rounded-lg sm:rounded-xl shadow-lg border border-slate-200/90 px-3 py-1.5 sm:px-4 sm:py-2.5 flex items-center gap-3 sm:gap-4 divide-x divide-slate-200">
            {/* Total Luas */}
            <div>
              <span className="block text-[9px] sm:text-[10px] font-bold uppercase tracking-wider text-slate-500 leading-tight">
                Total Luas
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-xs sm:text-base font-extrabold text-slate-900 font-mono tracking-tight leading-none">
                  {totalStats.areaHa}
                </span>
                <span className="text-[10px] sm:text-[11px] font-semibold text-slate-500">Ha</span>
              </div>
            </div>

            {/* Total Kelompok */}
            <div className="pl-3 sm:pl-4">
              <span className="block text-[9px] sm:text-[10px] font-bold uppercase tracking-wider text-slate-500 leading-tight">
                Total Kelompok
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-xs sm:text-base font-extrabold text-slate-900 font-mono tracking-tight leading-none">
                  {totalStats.count.toLocaleString('id-ID')}
                </span>
                <span className="text-[10px] sm:text-[11px] font-semibold text-slate-500">Kelompok</span>
              </div>
            </div>
          </div>
        </div>

        {/* Filter & Search Drawer on the Right */}
        {isFilterDrawerOpen && (
          <div className="absolute top-0 right-0 h-full w-full sm:w-96 max-w-full sm:max-w-md bg-white shadow-2xl z-1000 border-l border-slate-200 flex flex-col animate-in slide-in-from-right duration-200">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-emerald-600" />
                <h2 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Pencarian & Filter</h2>
              </div>
              <button
                onClick={() => setIsFilterDrawerOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-4 flex-1 overflow-y-auto">
              {/* Search input */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Cari Wilayah / Pengelola
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="masukan nama kelompok"
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden text-slate-900"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Kabupaten / Kota Select */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Kabupaten / Kota (Sumut)
                </label>
                <select
                  value={selectedKabupaten}
                  onChange={(e) => handleSelectKabupaten(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden font-medium text-slate-800"
                >
                  <option value="all">Semua Kabupaten / Kota di Sumut</option>
                  {SUMUT_KABUPATEN_LIST.map((kab) => (
                    <option key={kab.name} value={kab.name}>
                      {kab.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Matching Kelompok List */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
                    Daftar Kelompok ({filteredMaps.length})
                  </span>
                  {selectedKabupaten !== 'all' || searchQuery ? (
                    <button
                      onClick={() => {
                        setSelectedKabupaten('all');
                        setSearchQuery('');
                        setSelectedCategories(categories.map((c) => c.id));
                        fitToDeviceSumutBounds(mapInstanceRef.current, true);
                      }}
                      className="text-[11px] text-emerald-600 hover:underline font-bold"
                    >
                      Reset Filter
                    </button>
                  ) : null}
                </div>

                <div className="space-y-2">
                  {filteredMaps.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        zoomToMapRecord(item);
                      }}
                      className="p-3 rounded border border-slate-200 hover:border-emerald-400 hover:bg-slate-50 cursor-pointer transition-all bg-white shadow-2xs"
                      style={{
                        borderLeftWidth: '4px',
                        borderLeftColor: item.categoryColor || '#10b981',
                      }}
                    >
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                          {item.categoryName} {item.subcategoryName ? `• ${item.subcategoryName}` : ''}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 leading-snug">{item.name}</h4>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">📍 {item.address}</p>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500 mt-2 pt-1.5 border-t border-slate-100">
                        <span>Luas: {item.areaHa ? item.areaHa + ' Ha' : '-'}</span>
                        {(item.jumlahKk || item.kkCount) ? (
                          <span>👥 {(item.jumlahKk || item.kkCount)?.toLocaleString('id-ID')} KK</span>
                        ) : null}
                        {item.proses && (
                          <span className="text-emerald-700 font-medium truncate max-w-[140px]" title={item.proses}>
                            ⚡ {item.proses}
                          </span>
                        )}
                        <span className="text-emerald-600 font-bold flex items-center ml-auto">
                          Lihat <ChevronRight className="w-3 h-3 ml-0.5" />
                        </span>
                      </div>
                    </div>
                  ))}

                  {filteredMaps.length === 0 && (
                    <div className="text-center py-8 text-slate-400 text-xs">
                      Tidak ada data kelompok yang sesuai.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Selected Polygon Detail Modal */}
        {selectedMap && (
          <div className="fixed inset-0 z-2000 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-in zoom-in-95 max-h-[90vh] flex flex-col">
              {/* Header */}
              <div
                className="p-4 border-b border-slate-200 flex items-start justify-between relative gap-2"
                style={{
                  backgroundColor: (selectedMap.categoryColor || '#10b981') + '15',
                }}
              >
                <div className="min-w-0 flex-1">
                  <span
                    className="inline-block px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider mb-1.5"
                    style={{
                      backgroundColor: (selectedMap.categoryColor || '#059669') + '25',
                      color: selectedMap.categoryColor || '#047857',
                    }}
                  >
                    {selectedMap.categoryName} {selectedMap.subcategoryName ? `• ${selectedMap.subcategoryName}` : ''}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 leading-snug break-words">{selectedMap.name}</h3>
                </div>
                <button
                  onClick={() => setSelectedMap(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 transition-colors cursor-pointer shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body details matching Data Spasial Management */}
              <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs text-slate-700">
                {/* Lokasi Kelompok */}
                <div>
                  <h4 className="font-bold text-slate-800 text-[11px] uppercase tracking-wider mb-1.5 flex items-center space-x-1">
                    <span>📍 Lokasi Kelompok</span>
                  </h4>
                  <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-center">
                    <div className="min-w-0">
                      <span className="text-slate-400 block text-[9px] uppercase font-bold tracking-wider">Desa / Nagori</span>
                      <strong className="text-slate-900 font-bold text-xs block truncate" title={selectedMap.desa || '-'}>{selectedMap.desa || '-'}</strong>
                    </div>
                    <div className="min-w-0">
                      <span className="text-slate-400 block text-[9px] uppercase font-bold tracking-wider">Kecamatan</span>
                      <strong className="text-slate-900 font-bold text-xs block truncate" title={selectedMap.kecamatan || '-'}>{selectedMap.kecamatan || '-'}</strong>
                    </div>
                    <div className="min-w-0">
                      <span className="text-slate-400 block text-[9px] uppercase font-bold tracking-wider">Kabupaten / Kota</span>
                      <strong className="text-slate-900 font-bold text-xs block truncate" title={selectedMap.kabupaten || 'Sumut'}>{selectedMap.kabupaten || 'Sumut'}</strong>
                    </div>
                  </div>
                </div>

                {/* Grid Attributes WKR */}
                <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Luas Kelola (Ha)</span>
                    <strong className="text-slate-900 font-mono font-bold text-xs">
                      {selectedMap.areaHa ? `${selectedMap.areaHa.toLocaleString('id-ID')} Ha` : '-'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Tahun</span>
                    <strong className="text-slate-900 font-mono font-bold text-xs">{selectedMap.tahun || '-'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Jumlah KK</span>
                    <strong className="text-slate-900 font-mono font-bold text-xs">
                      {selectedMap.kkCount || selectedMap.jumlahKk
                        ? `${(selectedMap.kkCount || selectedMap.jumlahKk)?.toLocaleString('id-ID')} KK`
                        : '-'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Proses</span>
                    <strong className="text-slate-800 font-semibold break-words">{selectedMap.proses || '-'}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Pendamping</span>
                    <strong className="text-slate-800 font-semibold break-words">{selectedMap.pendamping || '-'}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider mb-0.5">Komoditi Utama / Unggulan</span>
                    <strong className="text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 inline-block break-words">
                      🌱 {selectedMap.komoditi || '-'}
                    </strong>
                  </div>
                </div>

                {/* Status Legalitas / SK */}
                {selectedMap.skLegalitas && (
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider mb-1">
                      SK Penetapan / Status Legalitas
                    </span>
                    <div className="text-emerald-900 font-semibold bg-emerald-50 text-xs p-2.5 rounded-lg border border-emerald-200 flex items-start space-x-2">
                      <span className="text-base shrink-0 mt-0.5">📜</span>
                      <span className="break-words leading-relaxed">{selectedMap.skLegalitas}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer Buttons */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                <button
                  onClick={() => {
                    zoomToMapRecord(selectedMap);
                    setSelectedMap(null);
                  }}
                  className="px-3.5 py-2 rounded bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors flex items-center space-x-1.5 cursor-pointer shadow-xs"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>FOKUSKAN DI PETA</span>
                </button>

                <button
                  onClick={() => setSelectedMap(null)}
                  className="px-3.5 py-2 rounded bg-white border border-slate-200 text-slate-700 font-medium text-xs hover:bg-slate-100 cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Database & Spatial Download Modal */}
        {isSqlModalOpen && (
          <div className="fixed inset-0 z-2000 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col border border-slate-200 overflow-hidden animate-in zoom-in-95">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <Database className="w-5 h-5 text-emerald-600" />
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">
                      Unduh Data Spasial & Database
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Ekspor format Shapefile (.shp/.zip), GeoJSON, Google Earth KML/KMZ & SQL Spatial
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsSqlModalOpen(false)}
                  className="text-slate-400 hover:text-slate-700 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-slate-200 bg-slate-50 px-2 sm:px-4 overflow-x-auto">
                <button
                  onClick={() => openSqlModal('zip')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'zip'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Shapefile (.ZIP)
                </button>
                <button
                  onClick={() => openSqlModal('shp')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'shp'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Shapefile (.SHP)
                </button>
                <button
                  onClick={() => openSqlModal('geojson')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'geojson'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  GeoJSON
                </button>
                <button
                  onClick={() => openSqlModal('kml')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'kml'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Google Earth (.KML)
                </button>
                <button
                  onClick={() => openSqlModal('kmz')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'kmz'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Google Earth (.KMZ)
                </button>
                <button
                  onClick={() => openSqlModal('postgis')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'postgis'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  PostGIS SQL
                </button>
                <button
                  onClick={() => openSqlModal('mysql')}
                  className={`py-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeSqlTab === 'mysql'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  MySQL Spatial
                </button>
              </div>

              {/* Code viewer */}
              <div className="p-4 flex-1 overflow-y-auto bg-slate-950 font-mono text-[11px] text-emerald-400 min-h-[160px]">
                <pre className="whitespace-pre-wrap">{sqlContent}</pre>
              </div>

              {/* Footer with Download */}
              <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                <a
                  href={`/api/export?type=${activeSqlTab}`}
                  download={
                    activeSqlTab === 'geojson'
                      ? 'wkr_sumut.geojson'
                      : activeSqlTab === 'zip'
                      ? 'wkr_sumut_shapefile.zip'
                      : activeSqlTab === 'shp'
                      ? 'wkr_sumut.shp'
                      : activeSqlTab === 'kml'
                      ? 'wkr_sumut.kml'
                      : activeSqlTab === 'kmz'
                      ? 'wkr_sumut.kmz'
                      : `wkr_sumut_${activeSqlTab}.sql`
                  }
                  className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>UNDUH FILE {activeSqlTab.toUpperCase()}</span>
                </a>
                <button
                  onClick={() => setIsSqlModalOpen(false)}
                  className="px-3 py-1.5 rounded bg-white border border-slate-300 text-slate-700 text-xs font-medium hover:bg-slate-100 cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
