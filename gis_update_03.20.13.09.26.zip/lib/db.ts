import bcrypt from 'bcryptjs';
import { Category, MapRecord, SiteSetting, User, RoleDefinition, RolePermission, ActivityLog } from './types';
import { SUMATERA_UTARA_GEOJSON } from './sumut-geojson';
import {
  isMySQLConfigured,
  isMySQLAvailable,
  queryMySQL,
  execMySQL,
  recordMySQLConnectionFailure,
  resetMySQLCircuitBreaker,
} from './mysql';
import { SYSTEM_PERMISSIONS, ROLE_DEFINITIONS } from './roles';

export { SYSTEM_PERMISSIONS, ROLE_DEFINITIONS, isMySQLConfigured, isMySQLAvailable, resetMySQLCircuitBreaker };

// Password encryption & strength validation helpers using bcrypt
export function validatePasswordStrength(password: string): { valid: boolean; message?: string } {
  if (!password || password.length < 8) {
    return { valid: false, message: 'Panjang kata sandi minimal 8 karakter' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Kata sandi wajib mengandung kombinasi huruf besar (A-Z)' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Kata sandi wajib mengandung kombinasi huruf kecil (a-z)' };
  }
  return { valid: true };
}

export function hashPassword(plainPassword: string): string {
  return bcrypt.hashSync(plainPassword, 10);
}

export function verifyPassword(plainPassword: string, passwordHash: string): boolean {
  if (!passwordHash) return false;
  if (passwordHash.startsWith('$2a$') || passwordHash.startsWith('$2b$')) {
    try {
      return bcrypt.compareSync(plainPassword, passwordHash);
    } catch {
      return false;
    }
  }
  // Plain text comparison fallback
  return passwordHash === plainPassword;
}

// Initial Categories matching Image 1 (Wilayah Kelola Rakyat categories)
export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-ps',
    name: 'Perhutanan Sosial',
    slug: 'perhutanan-sosial',
    description: 'Sistem pengelolaan hutan lestari yang dilaksanakan dalam kawasan hutan negara atau hutan hak/hutan adat oleh masyarakat setempat.',
    color: '#0d6efd',
    strokeColor: '#0a58ca',
    fillOpacity: 0.65,
    icon: 'Trees',
    subcategories: [
      { id: 'sub-hkm', name: 'Hutan Kemasyarakatan', slug: 'hutan-kemasyarakatan', color: '#ffc107', description: 'HKm - Izin/Persetujuan Pengelolaan Hutan Kemasyarakatan' },
      { id: 'sub-hd', name: 'Hutan Desa', slug: 'hutan-desa', color: '#059669', description: 'HD - Hak Pengelolaan Hutan Desa' },
      { id: 'sub-ha', name: 'Hutan Adat', slug: 'hutan-adat', color: '#6f42c1', description: 'HA - Pengakuan Hutan Adat' },
      { id: 'sub-htr', name: 'Hutan Tanaman Rakyat', slug: 'hutan-tanaman-rakyat', color: '#0284c7', description: 'HTR - Hutan Tanaman Rakyat' },
      { id: 'sub-kk', name: 'Kemitraan Kehutanan', slug: 'kemitraan-kehutanan', color: '#fd7e14', description: 'KK - Kemitraan Kehutanan' },
    ],
    createdAt: '2025-01-10T08:00:00.000Z',
  },
  {
    id: 'cat-1',
    name: 'Hanya Mengelola',
    slug: 'hanya-mengelola',
    description: 'Wilayah yang dikelola mandiri oleh kelompok masyarakat/komunitas lokal secara turun-temurun.',
    color: '#e83e8c',
    strokeColor: '#d63384',
    fillOpacity: 0.6,
    icon: 'TreePine',
    createdAt: '2025-01-10T08:00:00.000Z',
  },
  {
    id: 'cat-4',
    name: 'IPHPS',
    slug: 'iphps',
    description: 'Izin Pemanfaatan Hutan Perhutanan Sosial pada kawasan hutan produksi atau lindung.',
    color: '#ffc107',
    strokeColor: '#d39e00',
    fillOpacity: 0.6,
    icon: 'FileCheck',
    createdAt: '2025-01-10T08:15:00.000Z',
  },
  {
    id: 'cat-7',
    name: 'Lainnya',
    slug: 'lainnya',
    description: 'Inisiatif wilayah kelola rakyat, kebun agroforestri, dan konservasi berbasis masyarakat lainnya.',
    color: '#20c997',
    strokeColor: '#198754',
    fillOpacity: 0.6,
    icon: 'Landmark',
    createdAt: '2025-01-10T08:30:00.000Z',
  },
];

// Initial preloaded real/realistic WKR Map Polygons located precisely in North Sumatra
export const INITIAL_MAPS: MapRecord[] = [
  {
    id: 'map-1',
    name: 'Wilayah Adat Sihaporas (MHA Sihaporas)',
    description: 'Wilayah kelola adat keturunan Ompu Mamontang Laut Ambarita di kawasan Sihaporas. Kawasan ini mempertahankan hutan kemenyan, mata air pegunungan, dan tanah adat turun temurun.',
    address: 'Desa Sihaporas, Kec. Pematang Sidamanik, Kab. Simalungun, Sumatera Utara',
    desa: 'Sihaporas',
    kecamatan: 'Pematang Sidamanik',
    kabupaten: 'Simalungun',
    categoryId: 'cat-ps', // Perhutanan Sosial
    categoryName: 'Perhutanan Sosial',
    categoryColor: '#0d6efd',
    subcategoryId: 'sub-ha',
    subcategoryName: 'Hutan Adat',
    type: 'Polygon',
    latitude: 2.8654,
    longitude: 98.9234,
    status: 'Active',
    areaHa: 2048.5,
    kkCount: 380,
    jumlahKk: 380,
    proses: 'Proses Usulan SK Penetapan Hutan Adat',
    pengelola: 'Lembaga Adat Keturunan Ompu Mamontang Laut Ambarita (Lamtoras)',
    komoditi: 'Kemenyan (Haminjon), Kopi Arabika, Andaliman',
    pendamping: 'KSPPM & WALHI Sumatera Utara',
    skLegalitas: 'Proses Usulan SK Penetapan Hutan Adat KLHK / Perda',
    tahun: 2021,
    imageUrl: 'https://images.unsplash.com/photo-1511497584788-87676104235f?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [98.9100, 2.8750],
        [98.9350, 2.8800],
        [98.9450, 2.8600],
        [98.9300, 2.8450],
        [98.9050, 2.8550],
        [98.9100, 2.8750],
      ]],
    },
    createdAt: '2025-01-15T10:00:00.000Z',
    updatedAt: '2025-01-15T10:00:00.000Z',
  },
  {
    id: 'map-2',
    name: 'Hutan Kemasyarakatan (HKm) Nagori Dolok Panribuan',
    description: 'Kawasan HKm kelompok tani hutan mengelola agroforestri kopi ateng, aren, dan durian dengan tetap menjaga tutupan tajuk pohon hutan lindung.',
    address: 'Desa Dolok Tomuan, Kec. Dolok Panribuan, Kab. Simalungun, Sumatera Utara',
    desa: 'Dolok Tomuan',
    kecamatan: 'Dolok Panribuan',
    kabupaten: 'Simalungun',
    categoryId: 'cat-ps', // Perhutanan Sosial
    categoryName: 'Perhutanan Sosial',
    categoryColor: '#0d6efd',
    subcategoryId: 'sub-hkm',
    subcategoryName: 'Hutan Kemasyarakatan',
    type: 'Polygon',
    latitude: 2.7845,
    longitude: 99.0456,
    status: 'Active',
    areaHa: 875.2,
    kkCount: 245,
    jumlahKk: 245,
    proses: 'SK Penetapan Terbit (2019)',
    pengelola: 'Kelompok Tani Hutan (KTH) Dolok Lestari',
    komoditi: 'Kopi Ateng, Gula Aren, Durian Hutan',
    pendamping: 'WALHI Sumatera Utara & KPH Wilayah II',
    skLegalitas: 'SK.4522/MENLHK-PSKL/PKPS/PSL.0/7/2019',
    tahun: 2019,
    imageUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [99.0300, 2.7950],
        [99.0600, 2.7900],
        [99.0650, 2.7750],
        [99.0400, 2.7650],
        [99.0250, 2.7800],
        [99.0300, 2.7950],
      ]],
    },
    createdAt: '2025-01-16T11:30:00.000Z',
    updatedAt: '2025-01-16T11:30:00.000Z',
  },
  {
    id: 'map-3',
    name: 'Hutan Desa (HD) Timbang Lawan - Bahorok',
    description: 'Lembaga Pengelola Hutan Desa mengelola zona penyangga Taman Nasional Gunung Leuser (TNGL) untuk ekowisata konservasi, pengayaan tanaman buah pakan satwa dan pohon endemik.',
    address: 'Desa Timbang Lawan, Kec. Bahorok, Kab. Langkat, Sumatera Utara',
    desa: 'Timbang Lawan',
    kecamatan: 'Bahorok',
    kabupaten: 'Langkat',
    categoryId: 'cat-ps', // Perhutanan Sosial
    categoryName: 'Perhutanan Sosial',
    categoryColor: '#0d6efd',
    subcategoryId: 'sub-hd',
    subcategoryName: 'Hutan Desa',
    type: 'Polygon',
    latitude: 3.5521,
    longitude: 98.1452,
    status: 'Active',
    areaHa: 1250.0,
    kkCount: 180,
    jumlahKk: 180,
    proses: 'SK Penetapan Terbit (2018)',
    pengelola: 'Lembaga Pengelola Hutan Desa (LPHD) Timbang Lawan',
    komoditi: 'Ekowisata Konservasi, Madu Hutan, Buah Hutan',
    pendamping: 'Yayasan Orangutan Sumatera Lestari (YOSL-OIC) & WALHI Sumut',
    skLegalitas: 'SK.5611/MENLHK-PSKL/PKPS/PSL.0/9/2018',
    tahun: 2018,
    imageUrl: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [98.1300, 3.5650],
        [98.1650, 3.5600],
        [98.1600, 3.5350],
        [98.1350, 3.5300],
        [98.1200, 3.5500],
        [98.1300, 3.5650],
      ]],
    },
    createdAt: '2025-01-18T09:15:00.000Z',
    updatedAt: '2025-01-18T09:15:00.000Z',
  },
  {
    id: 'map-4',
    name: 'Wilayah Adat Pandumaan-Sipituhuta',
    description: 'Hutan Kemenyan (Tombak Haminjon) yang dikelola masyarakat adat Pandumaan dan Sipituhuta selama berabad-abad sebagai sumber kehidupan dan identitas kultural Batak Toba.',
    address: 'Desa Pandumaan, Kec. Pollung, Kab. Humbang Hasundutan, Sumatera Utara',
    desa: 'Pandumaan',
    kecamatan: 'Pollung',
    kabupaten: 'Humbang Hasundutan',
    categoryId: 'cat-1', // Hanya Mengelola
    categoryName: 'Hanya Mengelola',
    categoryColor: '#e83e8c',
    type: 'Polygon',
    latitude: 2.2980,
    longitude: 98.6420,
    status: 'Active',
    areaHa: 5172.0,
    kkCount: 520,
    jumlahKk: 520,
    proses: 'Perda & SK Enclave KLHK',
    pengelola: 'Komunitas Masyarakat Adat Pandumaan - Sipituhuta',
    komoditi: 'Getah Kemenyan Super, Kopi Tipika, Kayu Manis',
    pendamping: 'KSPPM, AMAN Tano Batak, WALHI Sumut',
    skLegalitas: 'Perda Kab. Humbang Hasundutan & SK Enclave KLHK',
    tahun: 2016,
    imageUrl: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [98.6100, 2.3200],
        [98.6650, 2.3300],
        [98.6800, 2.2900],
        [98.6400, 2.2600],
        [98.6050, 2.2850],
        [98.6100, 2.3200],
      ]],
    },
    createdAt: '2025-01-20T14:20:00.000Z',
    updatedAt: '2025-01-20T14:20:00.000Z',
  },
  {
    id: 'map-5',
    name: 'Kemitraan Kehutanan KTH Mandiri Sejahtera Batang Toru',
    description: 'Kelompok tani hutan bermitra mengelola areal pemulihan ekosistem di koridor Batang Toru dengan tanaman produktif kopi, petai, jengkol, dan getah damar.',
    address: 'Desa Marancar, Kec. Marancar, Kab. Tapanuli Selatan, Sumatera Utara',
    desa: 'Marancar',
    kecamatan: 'Marancar',
    kabupaten: 'Tapanuli Selatan',
    categoryId: 'cat-ps', // Perhutanan Sosial
    categoryName: 'Perhutanan Sosial',
    categoryColor: '#0d6efd',
    subcategoryId: 'sub-kk',
    subcategoryName: 'Kemitraan Kehutanan',
    type: 'Polygon',
    latitude: 1.5540,
    longitude: 99.1230,
    status: 'Active',
    areaHa: 630.0,
    kkCount: 165,
    jumlahKk: 165,
    proses: 'NKK KPH Wilayah X',
    pengelola: 'KTH Mandiri Sejahtera Marancar',
    komoditi: 'Kopi Robusta, Petai, Jengkol, Getah Damar',
    pendamping: 'Yayasan Ekosistem Lestari (YEL) & WALHI Sumut',
    skLegalitas: 'Naskah Kesepakatan Kerjasama (NKK) KPH Wilayah X',
    tahun: 2020,
    imageUrl: 'https://images.unsplash.com/photo-1473448912268-2022ce9509d8?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [99.1050, 1.5680],
        [99.1400, 1.5620],
        [99.1450, 1.5380],
        [99.1150, 1.5320],
        [99.0950, 1.5510],
        [99.1050, 1.5680],
      ]],
    },
    createdAt: '2025-01-22T08:45:00.000Z',
    updatedAt: '2025-01-22T08:45:00.000Z',
  },
  {
    id: 'map-6',
    name: 'IPHPS Kelompok Tani Hutan Teluk Mengkudu',
    description: 'Kawasan restorasi pesisir dan pemanfaatan silvofishery bakau (mangrove) serta budidaya kepiting bakau ramah lingkungan di pesisir timur Sumatera Utara.',
    address: 'Desa Teluk Mengkudu, Kec. Teluk Mengkudu, Kab. Serdang Bedagai, Sumatera Utara',
    desa: 'Teluk Mengkudu',
    kecamatan: 'Teluk Mengkudu',
    kabupaten: 'Serdang Bedagai',
    categoryId: 'cat-4', // IPHPS
    categoryName: 'IPHPS',
    categoryColor: '#0d6efd',
    type: 'Polygon',
    latitude: 3.5210,
    longitude: 99.1120,
    status: 'Active',
    areaHa: 340.5,
    kkCount: 95,
    jumlahKk: 95,
    proses: 'Verifikasi Teknis Lapangan',
    pengelola: 'KTH Mangrove Lestari Pesisir',
    komoditi: 'Silvofishery Kepiting Bakau, Sirup Mangrove, Bibit Bakau',
    pendamping: 'Yayasan Gajah Sumatera (YAGASU) & WALHI Sumut',
    skLegalitas: 'SK IPHPS No. 3412/MENLHK/2021',
    tahun: 2021,
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [99.0950, 3.5350],
        [99.1300, 3.5300],
        [99.1350, 3.5080],
        [99.1000, 3.5050],
        [99.0880, 3.5200],
        [99.0950, 3.5350],
      ]],
    },
    createdAt: '2025-01-25T16:10:00.000Z',
    updatedAt: '2025-01-25T16:10:00.000Z',
  },
  {
    id: 'map-7',
    name: 'Konservasi Komunitas Adat Nias Selatan (Bawomataluo)',
    description: 'Wilayah kelola adat berbasis kearifan lokal Faelahu dan pengelolaan hutan lindung desa penyangga budaya rumah adat Nias.',
    address: 'Desa Bawomataluo, Kec. Fanayama, Kab. Nias Selatan, Sumatera Utara',
    desa: 'Bawomataluo',
    kecamatan: 'Fanayama',
    kabupaten: 'Nias Selatan',
    categoryId: 'cat-7', // Lainnya
    categoryName: 'Lainnya',
    categoryColor: '#20c997',
    type: 'Polygon',
    latitude: 0.5840,
    longitude: 97.7450,
    status: 'Active',
    areaHa: 780.0,
    kkCount: 210,
    jumlahKk: 210,
    proses: 'Pengakuan Hukum Adat',
    pengelola: 'Lembaga Adat Siulu & Siila Nias Selatan',
    komoditi: 'Kelapa, Kakao, Kayu Bertuah Oholu, Anyaman Tradisional',
    pendamping: 'Aliansi Masyarakat Adat Nusantara (AMAN) Kepulauan Nias',
    skLegalitas: 'Pengakuan Hukum Adat Kabupaten Nias Selatan',
    tahun: 2022,
    imageUrl: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=800&auto=format&fit=crop',
    geometry: {
      type: 'Polygon',
      coordinates: [[
        [97.7300, 0.5980],
        [97.7650, 0.5920],
        [97.7600, 0.5700],
        [97.7320, 0.5650],
        [97.7200, 0.5820],
        [97.7300, 0.5980],
      ]],
    },
    createdAt: '2025-01-28T13:00:00.000Z',
    updatedAt: '2025-01-28T13:00:00.000Z',
  },
];

// Initial Users (Hanya menyertakan akun Super Developer & Administrator)
export const INITIAL_USERS: User[] = [
  {
    id: 'usr-dev-super',
    fullName: 'Super Developer (Root)',
    username: 'super',
    email: 'developer@walhisumut.or.id',
    passwordHash: '$2b$10$77HnYanDnFhOWs0hcyY68.Pu2/l0jM12uahPNsboe6fU8DuUJsn6m', // bcrypt hash for 'super123'
    roles: ['developer', 'admin'],
    isDeveloper: true,
    createdAt: '2025-01-01T00:00:00.000Z',
    updatedAt: '2025-01-01T00:00:00.000Z',
  },
  {
    id: 'usr-1',
    fullName: 'Administrator WKR Sumut',
    username: 'admin',
    email: 'admin@walhisumut.or.id',
    passwordHash: '$2a$10$8K1p/a0dL1LXMIgoEDFrw.O7rZ.E6tUa0gJk1m2jHq4Z2bJ9W96a2', // bcrypt hash for 'admin123'
    roles: ['admin', 'user'],
    createdAt: '2025-01-01T00:00:00.000Z',
    updatedAt: '2025-01-01T00:00:00.000Z',
  },
];

// Initial Site Settings matching Image 6
export const INITIAL_SETTINGS: SiteSetting = {
  id: 'setting-default',
  title: 'Peta Interaktif WALHI Sumatera Utara',
  description: 'Sistem Informasi Geografis interaktif Wilayah Kelola Rakyat (WKR) di Provinsi Sumatera Utara. Mengintegrasikan data spasial batas wilayah, hutan desa, HKm, kemitraan, dan hutan adat.',
  logoUrl: '',
  faviconUrl: '',
  navbarTitle: 'Peta Interaktif WALHI Sumatera Utara',
  browserTabTitle: 'Peta Interaktif Wilayah Kelola Rakyat - WALHI Sumatera Utara',
  mapCenterLat: 2.3500,
  mapCenterLng: 99.1500,
  mapZoom: 8,
  maskOutsideSumut: true,
  showSumutLabels: true,
  showBoundaryLayer: true,
  activeBasemap: 'OpenStreetMap',
  contactEmail: 'kontak@walhisumut.or.id',
  sourceAttribution: 'walhisumut.or.id | pantaulingkungan.id',
  sumutBoundaryGeoJSON: SUMATERA_UTARA_GEOJSON,
  maxActivityLogs: 100,
  searchEngineIndexingEnabled: true,
  googleVerificationCode: '',
  bingVerificationCode: '',
  googleAnalyticsEnabled: false,
  googleAnalyticsId: '',
  analyticsWidgets: {
    showOverviewKpis: true,
    showDailyTrend: true,
    showTopMaps: true,
    showCategoryInteractions: true,
    showDownloadBreakdown: true,
    showAcquisitionChannels: true,
    showSearchQueries: true,
    showGeoDistribution: true,
    showDeviceBreakdown: true,
  },
  underConstructionEnabled: false,
  underConstructionTitle: 'Situs Sedang Dalam Pemeliharaan & Pembaruan',
  underConstructionMessage: 'Portal Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara saat ini sedang dalam proses pemeliharaan berkala dan sinkronisasi data sistem. Kami akan segera kembali online melayani publik.',
  underConstructionEstimatedTime: 'Segera Kembali Online',
  underConstructionContact: 'kontak@walhisumut.or.id',
};

export const INITIAL_ACTIVITY_LOGS: ActivityLog[] = [
  {
    id: 'log-001',
    action: 'CREATE',
    entity: 'maps',
    entityId: 'map-1',
    description: 'Menambahkan data peta WKR "Wilayah Adat Sihaporas (MHA Sihaporas)"',
    userName: 'Administrator WALHI Sumut',
    userEmail: 'gis@walhisumut.or.id',
    createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
  },
  {
    id: 'log-002',
    action: 'UPDATE',
    entity: 'categories',
    entityId: 'cat-ps',
    description: 'Memperbarui informasi kategori "Perhutanan Sosial"',
    userName: 'Staf Pemetaan & GIS',
    userEmail: 'pemetaan@walhisumut.or.id',
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
  {
    id: 'log-003',
    action: 'LOGIN',
    entity: 'users',
    description: 'Berhasil melakukan autentikasi login ke sistem',
    userName: 'Administrator WALHI Sumut',
    userEmail: 'gis@walhisumut.or.id',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
  },
  {
    id: 'log-004',
    action: 'SYSTEM',
    entity: 'system',
    description: 'Inisialisasi sistem basis data SIG WKR WALHI Sumatera Utara berhasil',
    userName: 'Sistem',
    userEmail: 'system@walhisumut.or.id',
    createdAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
  },
];

// In-memory Database Store
let categoriesStore: Category[] = [...INITIAL_CATEGORIES];
let mapsStore: MapRecord[] = [...INITIAL_MAPS];
let usersStore: User[] = [...INITIAL_USERS];
let settingsStore: SiteSetting = { ...INITIAL_SETTINGS };
let activityLogsStore: ActivityLog[] = [...INITIAL_ACTIVITY_LOGS];

// AUTO-SCHEMA MIGRATION FOR EXTERNAL MYSQL DATABASES
let isSchemaEnsuring = false;
let isSchemaEnsured = false;

export async function ensureMySQLSchema(): Promise<void> {
  if (!isMySQLAvailable() || isSchemaEnsured || isSchemaEnsuring) return;
  isSchemaEnsuring = true;

  try {
    // 1. site_settings table
    await execMySQL(`
      CREATE TABLE IF NOT EXISTS site_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value LONGTEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB;
    `).catch(() => {});

    try {
      // Ensure all setting keys (including maxActivityLogs, searchEngineIndexingEnabled, etc.) exist with default values if not yet set
      for (const [k, v] of Object.entries(INITIAL_SETTINGS)) {
        await execMySQL(
          'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_key=setting_key',
          [k, JSON.stringify(v)]
        ).catch(() => {});
      }
    } catch {}

    // 2. activity_logs table
    await execMySQL(`
      CREATE TABLE IF NOT EXISTS activity_logs (
        id VARCHAR(50) PRIMARY KEY,
        user_name VARCHAR(150) NOT NULL,
        user_email VARCHAR(150),
        action VARCHAR(30) NOT NULL,
        entity VARCHAR(50) NOT NULL DEFAULT 'system',
        entity_id VARCHAR(50),
        description TEXT NOT NULL,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_activity_created (created_at),
        INDEX idx_activity_user (user_name)
      ) ENGINE=InnoDB;
    `).catch(() => {});

    // Ensure columns exist on legacy tables
    await execMySQL(`ALTER TABLE activity_logs ADD COLUMN user_email VARCHAR(150)`).catch(() => {});
    await execMySQL(`ALTER TABLE activity_logs ADD COLUMN entity VARCHAR(50) NOT NULL DEFAULT 'system'`).catch(() => {});
    await execMySQL(`ALTER TABLE activity_logs ADD COLUMN entity_id VARCHAR(50)`).catch(() => {});
    await execMySQL(`ALTER TABLE activity_logs ADD COLUMN description TEXT`).catch(() => {});
    await execMySQL(`ALTER TABLE activity_logs ADD COLUMN details TEXT`).catch(() => {});

    // Clean up any developer activity logs from database
    await execMySQL(`
      DELETE FROM activity_logs 
      WHERE LOWER(user_name) LIKE '%developer%' 
         OR LOWER(user_name) = 'super' 
         OR LOWER(user_name) = 'root' 
         OR LOWER(COALESCE(user_email, '')) LIKE '%developer%' 
         OR LOWER(description) LIKE '%developer%'
    `).catch(() => {});

    try {
      const lRows = await queryMySQL<any>('SELECT COUNT(*) as cnt FROM activity_logs');
      if (!lRows || !lRows[0] || Number(lRows[0].cnt) === 0) {
        for (const log of INITIAL_ACTIVITY_LOGS) {
          await execMySQL(
            `INSERT INTO activity_logs (id, user_name, user_email, action, entity, entity_id, description, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [log.id, log.userName, log.userEmail || '', log.action, log.entity, log.entityId || '', log.description, log.details || '']
          ).catch(() => {});
        }
      }
    } catch {}

    // 3. categories table & columns
    await execMySQL(`
      CREATE TABLE IF NOT EXISTS categories (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        slug VARCHAR(100) NOT NULL,
        description TEXT,
        color VARCHAR(20) NOT NULL DEFAULT '#0d6efd',
        stroke_color VARCHAR(20),
        fill_opacity DECIMAL(3,2) DEFAULT 0.6,
        icon VARCHAR(50) DEFAULT 'MapPin',
        subcategories_json LONGTEXT,
        sort_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB;
    `).catch(() => {});

    await execMySQL(`ALTER TABLE categories ADD COLUMN subcategories_json LONGTEXT`).catch(() => {});
    await execMySQL(`ALTER TABLE categories ADD COLUMN sort_order INT DEFAULT 0`).catch(() => {});

    try {
      const cRows = await queryMySQL<any>('SELECT COUNT(*) as cnt FROM categories');
      if (!cRows || !cRows[0] || Number(cRows[0].cnt) === 0) {
        for (const cat of INITIAL_CATEGORIES) {
          await execMySQL(
            `INSERT INTO categories (id, name, slug, description, color, stroke_color, fill_opacity, icon, subcategories_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [cat.id, cat.name, cat.slug, cat.description || '', cat.color, cat.strokeColor || cat.color, cat.fillOpacity || 0.6, cat.icon || 'MapPin', JSON.stringify(cat.subcategories || [])]
          ).catch(() => {});
        }
      }
    } catch {}

    // 4. users table
    await execMySQL(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(50) PRIMARY KEY,
        full_name VARCHAR(150) NOT NULL,
        username VARCHAR(80) UNIQUE NOT NULL,
        email VARCHAR(150) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        roles JSON NOT NULL,
        role VARCHAR(50) DEFAULT 'user',
        is_active TINYINT(1) DEFAULT 1,
        avatar VARCHAR(255) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB;
    `).catch(() => {});

    await execMySQL(`ALTER TABLE users ADD COLUMN roles JSON NULL`).catch(() => {});
    await execMySQL(`ALTER TABLE users ADD COLUMN role VARCHAR(50) NULL`).catch(() => {});
    await execMySQL(`ALTER TABLE users ADD COLUMN is_active TINYINT(1) DEFAULT 1`).catch(() => {});
    await execMySQL(`ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL`).catch(() => {});

    try {
      const uRows = await queryMySQL<any>('SELECT COUNT(*) as cnt FROM users');
      if (!uRows || !uRows[0] || Number(uRows[0].cnt) === 0) {
        for (const u of INITIAL_USERS) {
          await execMySQL(
            `INSERT INTO users (id, username, email, password_hash, full_name, roles, role, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
            [u.id, u.username, u.email, u.passwordHash, u.fullName, JSON.stringify(u.roles), u.roles[0] || 'admin']
          ).catch(() => {});
        }
      }
    } catch {}

    // 5. spatial_maps table & missing columns
    await execMySQL(`
      CREATE TABLE IF NOT EXISTS spatial_maps (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(200) NOT NULL,
        description TEXT,
        address TEXT,
        desa VARCHAR(100) NULL,
        kecamatan VARCHAR(100) NULL,
        kabupaten VARCHAR(100) NULL,
        category_id VARCHAR(50),
        subcategory_id VARCHAR(50),
        geom_type VARCHAR(30) NOT NULL DEFAULT 'Polygon',
        latitude DECIMAL(10, 6),
        longitude DECIMAL(10, 6),
        area_ha DECIMAL(12, 2) DEFAULT 0.00,
        kk_count INT DEFAULT 0,
        proses TEXT,
        pengelola VARCHAR(200),
        komoditi VARCHAR(255),
        pendamping VARCHAR(255),
        sk_legalitas VARCHAR(200),
        sk_nomor VARCHAR(128),
        tahun INT,
        tahun_penetapan VARCHAR(32),
        status VARCHAR(20) NOT NULL DEFAULT 'Active',
        image_url TEXT,
        kontak VARCHAR(255) NULL,
        raw_geojson LONGTEXT,
        geojson_data LONGTEXT,
        sort_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB;
    `).catch(() => {});

    const alterCols = [
      'ALTER TABLE spatial_maps ADD COLUMN subcategory_id VARCHAR(50) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN kk_count INT DEFAULT 0',
      'ALTER TABLE spatial_maps ADD COLUMN proses TEXT NULL',
      'ALTER TABLE spatial_maps ADD COLUMN geojson_data LONGTEXT NULL',
      'ALTER TABLE spatial_maps ADD COLUMN raw_geojson LONGTEXT NULL',
      'ALTER TABLE spatial_maps ADD COLUMN sk_nomor VARCHAR(128) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN tahun_penetapan VARCHAR(32) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN address TEXT NULL',
      'ALTER TABLE spatial_maps ADD COLUMN desa VARCHAR(100) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN kecamatan VARCHAR(100) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN kabupaten VARCHAR(100) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN pengelola VARCHAR(200) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN komoditi VARCHAR(255) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN pendamping VARCHAR(255) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN sk_legalitas VARCHAR(200) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN kontak VARCHAR(255) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN image_url TEXT NULL',
      'ALTER TABLE spatial_maps ADD COLUMN area_ha DECIMAL(12, 2) DEFAULT 0.00',
      'ALTER TABLE spatial_maps ADD COLUMN latitude DECIMAL(10, 6) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN longitude DECIMAL(10, 6) NULL',
      'ALTER TABLE spatial_maps ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT "Active"',
      'ALTER TABLE spatial_maps ADD COLUMN geom_type VARCHAR(30) NOT NULL DEFAULT "Polygon"',
      'ALTER TABLE spatial_maps ADD COLUMN sort_order INT DEFAULT 0',
    ];
    for (const colSql of alterCols) {
      await execMySQL(colSql).catch(() => {});
    }

    try {
      const mRows = await queryMySQL<any>('SELECT COUNT(*) as cnt FROM spatial_maps');
      if (!mRows || !mRows[0] || Number(mRows[0].cnt) === 0) {
        for (const m of INITIAL_MAPS) {
          const geoJsonStr = JSON.stringify(m.geometry || {});
          await execMySQL(
            `INSERT INTO spatial_maps (id, name, description, address, desa, kecamatan, kabupaten, category_id, subcategory_id, geom_type, latitude, longitude, area_ha, kk_count, pengelola, komoditi, pendamping, sk_legalitas, sk_nomor, tahun, tahun_penetapan, status, image_url, kontak, raw_geojson, geojson_data, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              m.id,
              m.name,
              m.description || '',
              m.address || '',
              m.desa || '',
              m.kecamatan || '',
              m.kabupaten || '',
              m.categoryId,
              m.subcategoryId || null,
              m.type || 'Polygon',
              m.latitude || 2.35,
              m.longitude || 99.15,
              m.areaHa || 0,
              m.kkCount || 0,
              m.pengelola || '',
              m.komoditi || '',
              m.pendamping || '',
              m.skLegalitas || '',
              m.skNomor || m.skLegalitas || '',
              m.tahun || 2024,
              m.tahunPenetapan || String(m.tahun || 2024),
              m.status || 'Active',
              m.imageUrl || '',
              (m as any).kontak || '',
              geoJsonStr,
              geoJsonStr,
              0,
            ]
          ).catch(() => {});
        }
      }
    } catch {}

    // 6. analytics_events table
    await execMySQL(`
      CREATE TABLE IF NOT EXISTS analytics_events (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        event_type VARCHAR(50) NOT NULL,
        map_id VARCHAR(50),
        map_name VARCHAR(200),
        category_id VARCHAR(50),
        category_name VARCHAR(100),
        search_query VARCHAR(255),
        download_format VARCHAR(50),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_event_type (event_type),
        INDEX idx_event_created (created_at)
      ) ENGINE=InnoDB;
    `).catch(() => {});

    isSchemaEnsured = true;
  } catch (err: any) {
    recordMySQLConnectionFailure(err);
  } finally {
    isSchemaEnsuring = false;
  }
}

export async function recordMySQLAnalyticsEvent(event: {
  type: string;
  mapId?: string;
  mapName?: string;
  categoryId?: string;
  categoryName?: string;
  query?: string;
  format?: string;
}): Promise<void> {
  if (!isMySQLAvailable()) return;
  try {
    await ensureMySQLSchema();
    await execMySQL(
      `INSERT INTO analytics_events (event_type, map_id, map_name, category_id, category_name, search_query, download_format, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        event.type,
        event.mapId || null,
        event.mapName || null,
        event.categoryId || null,
        event.categoryName || null,
        event.query || null,
        event.format || null,
      ]
    );
  } catch (err) {
    recordMySQLConnectionFailure(err);
  }
}

// ACTIVITY LOGS HELPERS
export function isDeveloperLog(name?: string, email?: string, desc?: string): boolean {
  const n = (name || '').toLowerCase();
  const e = (email || '').toLowerCase();
  const d = (desc || '').toLowerCase();
  return (
    n.includes('developer') ||
    n === 'super' ||
    n === 'root' ||
    e.includes('developer') ||
    e.includes('super@') ||
    d.includes('developer') ||
    d.includes('khusus developer')
  );
}

export function pruneActivityLogs(maxLimit?: number): void {
  const limit = maxLimit && maxLimit > 0 ? maxLimit : (settingsStore.maxActivityLogs || 100);
  if (activityLogsStore.length > limit) {
    activityLogsStore = activityLogsStore.slice(0, limit);
  }
  if (isMySQLAvailable()) {
    execMySQL(
      `DELETE FROM activity_logs 
       WHERE id NOT IN (
         SELECT id FROM (
           SELECT id FROM activity_logs ORDER BY created_at DESC LIMIT ?
         ) AS recent_logs
       )`,
      [limit]
    ).catch((err) => recordMySQLConnectionFailure(err));
  }
}

export function getActivityLogs(limit?: number): ActivityLog[] {
  const effectiveLimit = limit && limit > 0 ? limit : (settingsStore.maxActivityLogs || 100);
  return [...activityLogsStore]
    .filter((l) => !isDeveloperLog(l.userName, l.userEmail, l.description))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, effectiveLimit);
}

export async function getActivityLogsAsync(limit?: number): Promise<ActivityLog[]> {
  const effectiveLimit = limit && limit > 0 ? limit : (settingsStore.maxActivityLogs || 100);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const rows = await queryMySQL<any>(
        `SELECT id, user_name, user_email, action, entity, entity_id, description, details, created_at 
         FROM activity_logs 
         WHERE LOWER(user_name) NOT LIKE '%developer%' 
           AND LOWER(user_name) != 'super' 
           AND LOWER(user_name) != 'root' 
           AND LOWER(COALESCE(user_email, '')) NOT LIKE '%developer%'
           AND LOWER(description) NOT LIKE '%developer%'
         ORDER BY created_at DESC LIMIT ?`,
        [effectiveLimit]
      );
      if (rows && rows.length > 0) {
        const logs: ActivityLog[] = rows.map((r) => ({
          id: r.id,
          userName: r.user_name,
          userEmail: r.user_email || '',
          action: r.action,
          entity: r.entity,
          entityId: r.entity_id || '',
          description: r.description,
          details: r.details || '',
          createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
        }));
        activityLogsStore = logs;
        return logs;
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return getActivityLogs(effectiveLimit);
}

export function addActivityLog(logData: {
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'SYSTEM';
  entity: 'maps' | 'categories' | 'users' | 'roles' | 'settings' | 'system';
  entityId?: string;
  description: string;
  userName?: string;
  userEmail?: string;
  details?: string;
}): ActivityLog {
  // STRICT REQUIREMENT: Developer activities must NEVER be recorded in activity logs
  if (isDeveloperLog(logData.userName, logData.userEmail, logData.description)) {
    return {
      id: `dev-skipped-${Date.now()}`,
      action: logData.action,
      entity: logData.entity,
      entityId: logData.entityId,
      description: logData.description,
      userName: logData.userName || 'Developer',
      userEmail: logData.userEmail || '',
      createdAt: new Date().toISOString(),
    };
  }

  const newLog: ActivityLog = {
    id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    action: logData.action,
    entity: logData.entity,
    entityId: logData.entityId,
    description: logData.description,
    userName: logData.userName || 'Administrator WALHI Sumut',
    userEmail: logData.userEmail || 'gis@walhisumut.or.id',
    details: logData.details,
    createdAt: new Date().toISOString(),
  };

  activityLogsStore.unshift(newLog);

  // Enforce max log limit: remove oldest entries
  const maxLimit = settingsStore.maxActivityLogs && settingsStore.maxActivityLogs > 0
    ? settingsStore.maxActivityLogs
    : 100;
  if (activityLogsStore.length > maxLimit) {
    activityLogsStore = activityLogsStore.slice(0, maxLimit);
  }

  if (isMySQLAvailable()) {
    execMySQL(
      `INSERT INTO activity_logs (id, user_name, user_email, action, entity, entity_id, description, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE description=VALUES(description)`,
      [
        newLog.id,
        newLog.userName,
        newLog.userEmail || '',
        newLog.action,
        newLog.entity,
        newLog.entityId || '',
        newLog.description,
        newLog.details || '',
      ]
    )
      .then(async () => {
        // Enforce max log rows in MySQL database: delete oldest rows beyond maxLimit
        await execMySQL(
          `DELETE FROM activity_logs 
           WHERE id NOT IN (
             SELECT id FROM (
               SELECT id FROM activity_logs ORDER BY created_at DESC LIMIT ?
             ) AS recent_logs
           )`,
          [maxLimit]
        ).catch(() => {});
      })
      .catch((err) => recordMySQLConnectionFailure(err));
  }

  return newLog;
}

export function clearActivityLogs(): boolean {
  activityLogsStore = [];
  if (isMySQLAvailable()) {
    execMySQL('TRUNCATE TABLE activity_logs').catch((err) => recordMySQLConnectionFailure(err));
  }
  return true;
}

// CATEGORIES CRUD
export function getCategories(): Category[] {
  return categoriesStore;
}

export async function getCategoriesAsync(): Promise<Category[]> {
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const rows = await queryMySQL<any>('SELECT * FROM categories ORDER BY sort_order ASC, created_at ASC');
      if (rows && rows.length > 0) {
        const cats: Category[] = rows.map((r) => {
          let subcats = [];
          if (r.subcategories_json) {
            try {
              subcats = typeof r.subcategories_json === 'string' ? JSON.parse(r.subcategories_json) : r.subcategories_json;
            } catch {
              subcats = [];
            }
          }
          return {
            id: r.id,
            name: r.name,
            slug: r.slug,
            description: r.description || '',
            color: r.color || '#0d6efd',
            strokeColor: r.stroke_color || r.color || '#0a58ca',
            fillOpacity: r.fill_opacity !== undefined ? Number(r.fill_opacity) : 0.6,
            icon: r.icon || 'MapPin',
            subcategories: Array.isArray(subcats) ? subcats : [],
          };
        });
        categoriesStore = cats;
        return cats;
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return getCategories();
}

export function getCategoryById(id: string): Category | undefined {
  return categoriesStore.find((c) => c.id === id);
}

export async function getCategoryByIdAsync(id: string): Promise<Category | undefined> {
  const cats = await getCategoriesAsync();
  return cats.find((c) => c.id === id);
}

export function createCategory(data: Partial<Category>, userName?: string): Category {
  const newCategory: Category = {
    id: `cat-${Date.now()}`,
    name: data.name || 'Kategori Baru',
    slug: (data.name || 'kategori-baru').toLowerCase().replace(/\s+/g, '-'),
    description: data.description || '',
    color: data.color || '#0d6efd',
    strokeColor: data.strokeColor || data.color || '#0a58ca',
    fillOpacity: data.fillOpacity ?? 0.6,
    icon: data.icon || 'MapPin',
    subcategories: data.subcategories || [],
    createdAt: new Date().toISOString(),
  };
  categoriesStore.push(newCategory);
  addActivityLog({
    action: 'CREATE',
    entity: 'categories',
    entityId: newCategory.id,
    description: `Menambahkan kategori baru "${newCategory.name}"`,
    userName: userName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    ensureMySQLSchema().then(() => {
      execMySQL(
        `INSERT INTO categories (id, name, slug, description, color, stroke_color, fill_opacity, icon, subcategories_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), subcategories_json=VALUES(subcategories_json)`,
        [
          newCategory.id,
          newCategory.name,
          newCategory.slug,
          newCategory.description,
          newCategory.color,
          newCategory.strokeColor,
          newCategory.fillOpacity,
          newCategory.icon,
          JSON.stringify(newCategory.subcategories || []),
        ]
      ).catch((err) => recordMySQLConnectionFailure(err));
    }).catch(() => {});
  }

  return newCategory;
}

export async function createCategoryAsync(data: Partial<Category>, userName?: string): Promise<Category> {
  const cat = createCategory(data, userName);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL(
        `INSERT INTO categories (id, name, slug, description, color, stroke_color, fill_opacity, icon, subcategories_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), slug=VALUES(slug), description=VALUES(description), color=VALUES(color), stroke_color=VALUES(stroke_color), fill_opacity=VALUES(fill_opacity), icon=VALUES(icon), subcategories_json=VALUES(subcategories_json)`,
        [
          cat.id,
          cat.name,
          cat.slug,
          cat.description,
          cat.color,
          cat.strokeColor,
          cat.fillOpacity,
          cat.icon,
          JSON.stringify(cat.subcategories || []),
        ]
      );
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return cat;
}

export function updateCategory(id: string, data: Partial<Category>, userName?: string): Category | null {
  const index = categoriesStore.findIndex((c) => c.id === id);
  if (index === -1) return null;
  categoriesStore[index] = {
    ...categoriesStore[index],
    ...data,
  };
  addActivityLog({
    action: 'UPDATE',
    entity: 'categories',
    entityId: id,
    description: `Memperbarui kategori "${categoriesStore[index].name}"`,
    userName: userName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    ensureMySQLSchema().then(() => {
      const updated = categoriesStore[index];
      execMySQL(
        `UPDATE categories SET name=?, slug=?, description=?, color=?, stroke_color=?, fill_opacity=?, icon=?, subcategories_json=? WHERE id=?`,
        [
          updated.name,
          updated.slug,
          updated.description || '',
          updated.color,
          updated.strokeColor,
          updated.fillOpacity,
          updated.icon,
          JSON.stringify(updated.subcategories || []),
          id,
        ]
      ).catch((err) => recordMySQLConnectionFailure(err));
    }).catch(() => {});
  }

  return categoriesStore[index];
}

export async function updateCategoryAsync(id: string, data: Partial<Category>, userName?: string): Promise<Category | null> {
  const cat = updateCategory(id, data, userName);
  if (!cat) return null;
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL(
        `UPDATE categories SET name=?, slug=?, description=?, color=?, stroke_color=?, fill_opacity=?, icon=?, subcategories_json=? WHERE id=?`,
        [
          cat.name,
          cat.slug,
          cat.description || '',
          cat.color,
          cat.strokeColor,
          cat.fillOpacity,
          cat.icon,
          JSON.stringify(cat.subcategories || []),
          id,
        ]
      );
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return cat;
}

export function deleteCategory(id: string, userName?: string): boolean {
  const index = categoriesStore.findIndex((c) => c.id === id);
  if (index === -1) return false;
  const deletedName = categoriesStore[index].name;
  categoriesStore.splice(index, 1);
  addActivityLog({
    action: 'DELETE',
    entity: 'categories',
    entityId: id,
    description: `Menghapus kategori "${deletedName}"`,
    userName: userName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    execMySQL('DELETE FROM categories WHERE id=?', [id]).catch((err) => recordMySQLConnectionFailure(err));
  }

  return true;
}

export async function deleteCategoryAsync(id: string, userName?: string): Promise<boolean> {
  const result = deleteCategory(id, userName);
  if (result && isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL('DELETE FROM categories WHERE id=?', [id]);
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return result;
}

export function reorderCategories(orderedIds: string[]): void {
  const catMap = new Map(categoriesStore.map((c) => [c.id, c]));
  const reordered: Category[] = [];
  for (const id of orderedIds) {
    const c = catMap.get(id);
    if (c) {
      reordered.push(c);
    }
  }
  categoriesStore = reordered;
}

export async function reorderCategoriesAsync(orderedIds: string[]): Promise<void> {
  reorderCategories(orderedIds);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      for (let i = 0; i < orderedIds.length; i++) {
        await execMySQL('UPDATE categories SET sort_order = ? WHERE id = ?', [i, orderedIds[i]]);
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
}

// MAPS CRUD
export function getMaps(): MapRecord[] {
  // Enrich category names & colors & subcategories
  return mapsStore.map((m) => {
    const cat = categoriesStore.find((c) => c.id === m.categoryId);
    const subcat = cat?.subcategories?.find((s) => s.id === m.subcategoryId);
    const effectiveColor = subcat?.color || cat?.color || m.categoryColor || '#3388ff';
    return {
      ...m,
      categoryName: cat?.name || m.categoryName || 'Uncategorized',
      categoryColor: effectiveColor,
      subcategoryName: subcat?.name || m.subcategoryName,
    };
  });
}

let mapsCacheTimestamp = 0;
const MAPS_CACHE_TTL_MS = 4000; // 4 second high-speed cache for realtime performance

export function invalidateMapsCache() {
  mapsCacheTimestamp = 0;
}

export async function getMapsAsync(): Promise<MapRecord[]> {
  const now = Date.now();
  if (mapsStore.length > 0 && now - mapsCacheTimestamp < MAPS_CACHE_TTL_MS) {
    return getMaps();
  }

  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const rows = await queryMySQL<any>(
        `SELECT * FROM spatial_maps ORDER BY sort_order ASC, created_at DESC`
      );
      if (rows && rows.length > 0) {
        const maps: MapRecord[] = rows.map((r) => {
          let parsedGeoJSON = r.geojson_data || r.raw_geojson;
          if (typeof parsedGeoJSON === 'string') {
            try {
              parsedGeoJSON = JSON.parse(parsedGeoJSON);
            } catch {
              parsedGeoJSON = null;
            }
          }
          return {
            id: r.id,
            name: r.name,
            categoryId: r.category_id,
            subcategoryId: r.subcategory_id || undefined,
            areaHa: Number(r.area_ha || 0),
            kkCount: Number(r.kk_count || 0),
            jumlahKk: Number(r.kk_count || 0),
            proses: r.proses || '',
            description: r.description || '',
            address: r.address || '',
            desa: r.desa || '',
            kecamatan: r.kecamatan || '',
            kabupaten: r.kabupaten || '',
            pengelola: r.pengelola || '',
            komoditi: r.komoditi || '',
            tahun: r.tahun ? Number(r.tahun) : (r.tahun_penetapan ? parseInt(r.tahun_penetapan, 10) || 2024 : 2024),
            tahunPenetapan: r.tahun_penetapan || (r.tahun ? String(r.tahun) : ''),
            skLegalitas: r.sk_legalitas || r.sk_nomor || '',
            skNomor: r.sk_nomor || r.sk_legalitas || '',
            pendamping: r.pendamping || '',
            status: r.status || 'Active',
            imageUrl: r.image_url || '',
            type: r.geom_type || 'Polygon',
            latitude: Number(r.latitude) || 2.35,
            longitude: Number(r.longitude) || 99.15,
            geometry: parsedGeoJSON || { type: 'Polygon', coordinates: [] },
            createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
            updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : new Date().toISOString(),
          };
        });
        mapsStore = maps;
        mapsCacheTimestamp = Date.now();
        return getMaps();
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return getMaps();
}

export function getMapById(id: string): MapRecord | undefined {
  const map = mapsStore.find((m) => m.id === id);
  if (!map) return undefined;
  const cat = categoriesStore.find((c) => c.id === map.categoryId);
  const subcat = cat?.subcategories?.find((s) => s.id === map.subcategoryId);
  const effectiveColor = subcat?.color || cat?.color || map.categoryColor || '#3388ff';
  return {
    ...map,
    categoryName: cat?.name || map.categoryName || 'Uncategorized',
    categoryColor: effectiveColor,
    subcategoryName: subcat?.name || map.subcategoryName,
  };
}

export async function getMapByIdAsync(id: string): Promise<MapRecord | undefined> {
  const maps = await getMapsAsync();
  return maps.find((m) => m.id === id);
}

export function createMap(data: Partial<MapRecord>, userName?: string): MapRecord {
  const cat = categoriesStore.find((c) => c.id === data.categoryId);
  const subcat = cat?.subcategories?.find((s) => s.id === data.subcategoryId);
  const effectiveColor = subcat?.color || cat?.color || '#0d6efd';

  const desa = data.desa || '';
  const kecamatan = data.kecamatan || '';
  const kabupaten = data.kabupaten || '';
  const constructedAddress = [
    desa ? `Desa ${desa}` : '',
    kecamatan ? `Kec. ${kecamatan}` : '',
    kabupaten ? `Kab. ${kabupaten}` : '',
    'Sumatera Utara',
  ].filter(Boolean).join(', ');

  const newMap: MapRecord = {
    id: `map-${Date.now()}`,
    name: data.name || 'Wilayah Baru',
    description: data.description || '',
    desa,
    kecamatan,
    kabupaten,
    address: data.address || constructedAddress,
    categoryId: data.categoryId || categoriesStore[0]?.id || 'cat-ps',
    categoryName: cat?.name || 'Perhutanan Sosial',
    categoryColor: effectiveColor,
    subcategoryId: data.subcategoryId || undefined,
    subcategoryName: subcat?.name || data.subcategoryName || undefined,
    type: data.type || 'Polygon',
    latitude: Number(data.latitude) || 2.35,
    longitude: Number(data.longitude) || 99.15,
    status: data.status || 'Active',
    imageUrl: data.imageUrl || '',
    areaHa: data.areaHa ? Number(data.areaHa) : 100,
    kkCount: data.kkCount !== undefined ? Number(data.kkCount) : (data.jumlahKk !== undefined ? Number(data.jumlahKk) : 0),
    jumlahKk: data.jumlahKk !== undefined ? Number(data.jumlahKk) : (data.kkCount !== undefined ? Number(data.kkCount) : 0),
    proses: data.proses || '',
    pengelola: data.pengelola || 'Masyarakat Pengelola',
    komoditi: data.komoditi || '',
    pendamping: data.pendamping || '',
    skLegalitas: data.skLegalitas || 'Dalam Proses',
    tahun: data.tahun ? Number(data.tahun) : new Date().getFullYear(),
    geometry: data.geometry || {
      type: 'Polygon',
      coordinates: [[
        [98.9, 2.8],
        [99.0, 2.8],
        [99.0, 2.7],
        [98.9, 2.7],
        [98.9, 2.8],
      ]],
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  mapsStore.push(newMap);
  invalidateMapsCache();
  addActivityLog({
    action: 'CREATE',
    entity: 'maps',
    entityId: newMap.id,
    description: `Menambahkan peta WKR "${newMap.name}"`,
    userName: userName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    const geoJsonStr = JSON.stringify(newMap.geometry || newMap.geojsonData || {});
    execMySQL(
      `INSERT INTO spatial_maps (id, name, category_id, subcategory_id, area_ha, kk_count, proses, description, address, desa, kecamatan, kabupaten, pengelola, komoditi, tahun, tahun_penetapan, sk_legalitas, sk_nomor, pendamping, status, image_url, geom_type, latitude, longitude, geojson_data, raw_geojson)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE name=VALUES(name), category_id=VALUES(category_id), subcategory_id=VALUES(subcategory_id), area_ha=VALUES(area_ha), kk_count=VALUES(kk_count), proses=VALUES(proses), description=VALUES(description), address=VALUES(address), desa=VALUES(desa), kecamatan=VALUES(kecamatan), kabupaten=VALUES(kabupaten), pengelola=VALUES(pengelola), komoditi=VALUES(komoditi), tahun=VALUES(tahun), tahun_penetapan=VALUES(tahun_penetapan), sk_legalitas=VALUES(sk_legalitas), sk_nomor=VALUES(sk_nomor), pendamping=VALUES(pendamping), status=VALUES(status), image_url=VALUES(image_url), geom_type=VALUES(geom_type), latitude=VALUES(latitude), longitude=VALUES(longitude), geojson_data=VALUES(geojson_data), raw_geojson=VALUES(raw_geojson)`,
      [
        newMap.id,
        newMap.name,
        newMap.categoryId,
        newMap.subcategoryId || null,
        newMap.areaHa || 0,
        newMap.kkCount || 0,
        newMap.proses || '',
        newMap.description || '',
        newMap.address || '',
        newMap.desa || '',
        newMap.kecamatan || '',
        newMap.kabupaten || '',
        newMap.pengelola || '',
        newMap.komoditi || '',
        newMap.tahun || 2024,
        newMap.tahunPenetapan || String(newMap.tahun || ''),
        newMap.skLegalitas || newMap.skNomor || '',
        newMap.skNomor || newMap.skLegalitas || '',
        newMap.pendamping || '',
        newMap.status || 'Active',
        newMap.imageUrl || '',
        newMap.type || 'Polygon',
        newMap.latitude || 2.35,
        newMap.longitude || 99.15,
        geoJsonStr,
        geoJsonStr,
      ]
    ).catch((err) => recordMySQLConnectionFailure(err));
  }

  return newMap;
}

export async function createMapAsync(data: Partial<MapRecord>, userName?: string): Promise<MapRecord> {
  const newMap = createMap(data, userName);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const geoJsonStr = JSON.stringify(newMap.geometry || newMap.geojsonData || {});
      await execMySQL(
        `INSERT INTO spatial_maps (id, name, category_id, subcategory_id, area_ha, kk_count, proses, description, address, desa, kecamatan, kabupaten, pengelola, komoditi, tahun, tahun_penetapan, sk_legalitas, sk_nomor, pendamping, status, image_url, geom_type, latitude, longitude, geojson_data, raw_geojson)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE name=VALUES(name), category_id=VALUES(category_id), subcategory_id=VALUES(subcategory_id), area_ha=VALUES(area_ha), kk_count=VALUES(kk_count), proses=VALUES(proses), description=VALUES(description), address=VALUES(address), desa=VALUES(desa), kecamatan=VALUES(kecamatan), kabupaten=VALUES(kabupaten), pengelola=VALUES(pengelola), komoditi=VALUES(komoditi), tahun=VALUES(tahun), tahun_penetapan=VALUES(tahun_penetapan), sk_legalitas=VALUES(sk_legalitas), sk_nomor=VALUES(sk_nomor), pendamping=VALUES(pendamping), status=VALUES(status), image_url=VALUES(image_url), geom_type=VALUES(geom_type), latitude=VALUES(latitude), longitude=VALUES(longitude), geojson_data=VALUES(geojson_data), raw_geojson=VALUES(raw_geojson)`,
        [
          newMap.id,
          newMap.name,
          newMap.categoryId,
          newMap.subcategoryId || null,
          newMap.areaHa || 0,
          newMap.kkCount || 0,
          newMap.proses || '',
          newMap.description || '',
          newMap.address || '',
          newMap.desa || '',
          newMap.kecamatan || '',
          newMap.kabupaten || '',
          newMap.pengelola || '',
          newMap.komoditi || '',
          newMap.tahun || 2024,
          newMap.tahunPenetapan || String(newMap.tahun || ''),
          newMap.skLegalitas || newMap.skNomor || '',
          newMap.skNomor || newMap.skLegalitas || '',
          newMap.pendamping || '',
          newMap.status || 'Active',
          newMap.imageUrl || '',
          newMap.type || 'Polygon',
          newMap.latitude || 2.35,
          newMap.longitude || 99.15,
          geoJsonStr,
          geoJsonStr,
        ]
      );
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return newMap;
}

export function updateMap(id: string, data: Partial<MapRecord>, userName?: string): MapRecord | null {
  const index = mapsStore.findIndex((m) => m.id === id);
  if (index === -1) return null;

  const cat = categoriesStore.find((c) => c.id === (data.categoryId || mapsStore[index].categoryId));
  const subcatId = data.subcategoryId !== undefined ? data.subcategoryId : mapsStore[index].subcategoryId;
  const subcat = cat?.subcategories?.find((s) => s.id === subcatId);
  const effectiveColor = subcat?.color || cat?.color || mapsStore[index].categoryColor;

  const desa = data.desa !== undefined ? data.desa : mapsStore[index].desa;
  const kecamatan = data.kecamatan !== undefined ? data.kecamatan : mapsStore[index].kecamatan;
  const kabupaten = data.kabupaten !== undefined ? data.kabupaten : mapsStore[index].kabupaten;
  const constructedAddress = [
    desa ? `Desa ${desa}` : '',
    kecamatan ? `Kec. ${kecamatan}` : '',
    kabupaten ? `Kab. ${kabupaten}` : '',
    'Sumatera Utara',
  ].filter(Boolean).join(', ');

  mapsStore[index] = {
    ...mapsStore[index],
    ...data,
    desa,
    kecamatan,
    kabupaten,
    address: data.address || constructedAddress,
    categoryName: cat?.name || mapsStore[index].categoryName,
    categoryColor: effectiveColor,
    subcategoryId: subcatId,
    subcategoryName: subcat?.name || (data.subcategoryName !== undefined ? data.subcategoryName : mapsStore[index].subcategoryName),
    updatedAt: new Date().toISOString(),
  };

  invalidateMapsCache();
  addActivityLog({
    action: 'UPDATE',
    entity: 'maps',
    entityId: id,
    description: `Memperbarui data peta WKR "${mapsStore[index].name}"`,
    userName: userName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    const updated = mapsStore[index];
    const geoJsonStr = JSON.stringify(updated.geometry || updated.geojsonData || {});
    execMySQL(
      `UPDATE spatial_maps SET name=?, category_id=?, subcategory_id=?, area_ha=?, kk_count=?, proses=?, description=?, address=?, desa=?, kecamatan=?, kabupaten=?, pengelola=?, komoditi=?, tahun=?, tahun_penetapan=?, sk_legalitas=?, sk_nomor=?, pendamping=?, status=?, image_url=?, geom_type=?, latitude=?, longitude=?, geojson_data=?, raw_geojson=? WHERE id=?`,
      [
        updated.name,
        updated.categoryId,
        updated.subcategoryId || null,
        updated.areaHa || 0,
        updated.kkCount || 0,
        updated.proses || '',
        updated.description || '',
        updated.address || '',
        updated.desa || '',
        updated.kecamatan || '',
        updated.kabupaten || '',
        updated.pengelola || '',
        updated.komoditi || '',
        updated.tahun || 2024,
        updated.tahunPenetapan || String(updated.tahun || ''),
        updated.skLegalitas || updated.skNomor || '',
        updated.skNomor || updated.skLegalitas || '',
        updated.pendamping || '',
        updated.status || 'Active',
        updated.imageUrl || '',
        updated.type || 'Polygon',
        updated.latitude || 2.35,
        updated.longitude || 99.15,
        geoJsonStr,
        geoJsonStr,
        id,
      ]
    ).catch((err) => recordMySQLConnectionFailure(err));
  }

  return mapsStore[index];
}

export async function updateMapAsync(id: string, data: Partial<MapRecord>, userName?: string): Promise<MapRecord | null> {
  const updated = updateMap(id, data, userName);
  if (!updated) return null;
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const geoJsonStr = JSON.stringify(updated.geometry || updated.geojsonData || {});
      await execMySQL(
        `UPDATE spatial_maps SET name=?, category_id=?, subcategory_id=?, area_ha=?, kk_count=?, proses=?, description=?, address=?, desa=?, kecamatan=?, kabupaten=?, pengelola=?, komoditi=?, tahun=?, tahun_penetapan=?, sk_legalitas=?, sk_nomor=?, pendamping=?, status=?, image_url=?, geom_type=?, latitude=?, longitude=?, geojson_data=?, raw_geojson=? WHERE id=?`,
        [
          updated.name,
          updated.categoryId,
          updated.subcategoryId || null,
          updated.areaHa || 0,
          updated.kkCount || 0,
          updated.proses || '',
          updated.description || '',
          updated.address || '',
          updated.desa || '',
          updated.kecamatan || '',
          updated.kabupaten || '',
          updated.pengelola || '',
          updated.komoditi || '',
          updated.tahun || 2024,
          updated.tahunPenetapan || String(updated.tahun || ''),
          updated.skLegalitas || updated.skNomor || '',
          updated.skNomor || updated.skLegalitas || '',
          updated.pendamping || '',
          updated.status || 'Active',
          updated.imageUrl || '',
          updated.type || 'Polygon',
          updated.latitude || 2.35,
          updated.longitude || 99.15,
          geoJsonStr,
          geoJsonStr,
          id,
        ]
      );
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return updated;
}

export function deleteMap(id: string, userName?: string): boolean {
  const index = mapsStore.findIndex((m) => m.id === id);
  if (index === -1) return false;
  const deletedName = mapsStore[index].name;
  mapsStore.splice(index, 1);
  invalidateMapsCache();
  addActivityLog({
    action: 'DELETE',
    entity: 'maps',
    entityId: id,
    description: `Menghapus data peta WKR "${deletedName}"`,
    userName: userName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    execMySQL('DELETE FROM spatial_maps WHERE id=?', [id]).catch((err) => recordMySQLConnectionFailure(err));
  }

  return true;
}

export async function deleteMapAsync(id: string, userName?: string): Promise<boolean> {
  const result = deleteMap(id, userName);
  if (result && isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL('DELETE FROM spatial_maps WHERE id=?', [id]);
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return result;
}

export function reorderMaps(orderedIds: string[]): void {
  const mapMap = new Map(mapsStore.map((m) => [m.id, m]));
  const reordered: MapRecord[] = [];
  for (const id of orderedIds) {
    const m = mapMap.get(id);
    if (m) {
      reordered.push(m);
      mapMap.delete(id);
    }
  }
  reordered.push(...mapMap.values());
  mapsStore = reordered;
  invalidateMapsCache();
}

export async function reorderMapsAsync(orderedIds: string[]): Promise<void> {
  reorderMaps(orderedIds);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      for (let i = 0; i < orderedIds.length; i++) {
        await execMySQL('UPDATE spatial_maps SET sort_order = ? WHERE id = ?', [i, orderedIds[i]]);
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
}

// ROLES & PERMISSIONS HELPERS
let rolesStore: RoleDefinition[] = [...ROLE_DEFINITIONS];

export function getRoles(): RoleDefinition[] {
  return rolesStore;
}

export function getRoleById(id: string): RoleDefinition | undefined {
  return rolesStore.find((r) => r.id === id);
}

export function getSystemPermissions(): RolePermission[] {
  return SYSTEM_PERMISSIONS;
}

export function getUserEffectivePermissions(userRoles: string[]): string[] {
  const permSet = new Set<string>();
  for (const roleId of userRoles) {
    const roleDef = rolesStore.find((r) => r.id === roleId);
    if (roleDef) {
      roleDef.permissions.forEach((p) => permSet.add(p));
    }
  }
  return Array.from(permSet);
}

// USERS CRUD
export function isUserDeveloper(user?: Partial<User> | null): boolean {
  if (!user) return false;
  if (user.isDeveloper === true) return true;
  if (user.username?.toLowerCase() === 'super') return true;
  if (Array.isArray(user.roles) && user.roles.includes('developer')) return true;
  return false;
}

export function getUsers(includeDevelopers: boolean = false): (Omit<User, 'password' | 'passwordHash'> & { isDeveloper?: boolean })[] {
  let list = usersStore;
  if (!includeDevelopers) {
    list = list.filter((u) => !isUserDeveloper(u));
  }
  return list.map(({ password, passwordHash, ...u }) => ({
    ...u,
    isDeveloper: isUserDeveloper(u),
  }));
}

export async function getUsersAsync(includeDevelopers: boolean = false): Promise<(Omit<User, 'password' | 'passwordHash'> & { isDeveloper?: boolean })[]> {
  if (isMySQLAvailable()) {
    try {
      let rows: any[] | null = null;
      try {
        rows = await queryMySQL<any>(
          `SELECT id, username, email, full_name, role, roles, is_active, avatar, created_at, updated_at FROM users`
        );
      } catch (err: any) {
        if (err && (err.code === 'ER_BAD_FIELD_ERROR' || String(err.message || '').includes('avatar'))) {
          // Auto migrate schema and fallback query without avatar
          await ensureMySQLSchema().catch(() => {});
          rows = await queryMySQL<any>(
            `SELECT id, username, email, full_name, role, roles, is_active, created_at, updated_at FROM users`
          ).catch(() => null);
        } else {
          throw err;
        }
      }
      if (rows && rows.length > 0) {
        const users: User[] = rows.map((r) => {
          let rolesArray: string[] = ['user'];
          try {
            if (r.roles) {
              rolesArray = typeof r.roles === 'string' ? JSON.parse(r.roles) : r.roles;
            } else if (r.role) {
              rolesArray = [r.role];
            }
          } catch {
            rolesArray = r.role ? [r.role] : ['user'];
          }
          const isDev = r.username === 'super' || r.role === 'developer' || rolesArray.includes('developer');
          return {
            id: r.id,
            username: r.username,
            email: r.email,
            fullName: r.full_name || r.username,
            roles: rolesArray,
            isDeveloper: isDev,
            isActive: Boolean(r.is_active),
            avatar: r.avatar || '',
            createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
            updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : new Date().toISOString(),
          };
        });
        // Merge with memory store without passwords
        users.forEach((u) => {
          const idx = usersStore.findIndex((x) => x.id === u.id || x.username === u.username);
          if (idx === -1) {
            usersStore.push(u);
          } else {
            usersStore[idx] = {
              ...usersStore[idx],
              ...u,
              passwordHash: usersStore[idx].passwordHash,
            };
          }
        });
        return getUsers(includeDevelopers);
      }
    } catch (err) {
      recordMySQLConnectionFailure(err);
    }
  }
  return getUsers(includeDevelopers);
}

export function getUserById(id: string): (Omit<User, 'password' | 'passwordHash'> & { isDeveloper?: boolean }) | undefined {
  const u = usersStore.find((user) => user.id === id);
  if (!u) return undefined;
  const { password, passwordHash, ...safeUser } = u;
  return {
    ...safeUser,
    isDeveloper: isUserDeveloper(u),
  };
}

export async function getUserByIdAsync(id: string): Promise<(Omit<User, 'password' | 'passwordHash'> & { isDeveloper?: boolean }) | undefined> {
  await getUsersAsync(true);
  return getUserById(id);
}

// KHUSUS PENGELOLAAN AKUN DEVELOPER
export function getDeveloperUsers(): (Omit<User, 'password' | 'passwordHash'> & { isDeveloper: boolean })[] {
  return usersStore
    .filter((u) => isUserDeveloper(u))
    .map(({ password, passwordHash, ...u }) => ({
      ...u,
      isDeveloper: true,
    }));
}

export async function getDeveloperUsersAsync(): Promise<(Omit<User, 'password' | 'passwordHash'> & { isDeveloper: boolean })[]> {
  await getUsersAsync(true);
  return getDeveloperUsers();
}

export function createDeveloperUser(data: Partial<User>, performerName?: string): Omit<User, 'password' | 'passwordHash'> & { isDeveloper: boolean } {
  const plainPassword = data.password || 'super123';
  const passwordHash = hashPassword(plainPassword);

  const newUser: User = {
    id: `usr-dev-${Date.now()}`,
    fullName: data.fullName || 'Developer Baru',
    username: (data.username || 'dev' + Date.now()).toLowerCase().trim(),
    email: data.email || 'developer@walhisumut.or.id',
    passwordHash,
    roles: ['developer', 'admin'],
    isDeveloper: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  usersStore.push(newUser);

  if (isMySQLAvailable()) {
    execMySQL(
      `INSERT INTO users (id, username, email, password_hash, full_name, roles, role, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name), roles=VALUES(roles), password_hash=VALUES(password_hash)`,
      [
        newUser.id,
        newUser.username,
        newUser.email,
        newUser.passwordHash,
        newUser.fullName,
        JSON.stringify(newUser.roles),
        'developer',
      ]
    ).catch((err) => recordMySQLConnectionFailure(err));
  }

  const { password, passwordHash: _, ...safeUser } = newUser;
  return { ...safeUser, isDeveloper: true };
}

export async function createDeveloperUserAsync(data: Partial<User>, performerName?: string) {
  const user = createDeveloperUser(data, performerName);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL(
        `INSERT INTO users (id, username, email, password_hash, full_name, roles, role, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE username=VALUES(username), email=VALUES(email), password_hash=VALUES(password_hash), full_name=VALUES(full_name), roles=VALUES(roles), role=VALUES(role)`,
        [
          user.id,
          user.username,
          user.email,
          (user as any).passwordHash || hashPassword(data.password || 'super123'),
          user.fullName,
          JSON.stringify(user.roles || ['developer', 'admin']),
          'developer',
        ]
      );
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return user;
}

export function updateDeveloperUser(id: string, data: Partial<User>, performerName?: string) {
  const index = usersStore.findIndex((u) => u.id === id);
  if (index === -1) return null;

  const updateData: Partial<User> = { ...data };
  if (data.password && data.password.trim().length > 0) {
    updateData.passwordHash = hashPassword(data.password.trim());
    delete updateData.password;
  }
  updateData.isDeveloper = true;
  if (!updateData.roles || !updateData.roles.includes('developer')) {
    updateData.roles = ['developer', 'admin'];
  }

  usersStore[index] = {
    ...usersStore[index],
    ...updateData,
    updatedAt: new Date().toISOString(),
  };

  if (isMySQLAvailable()) {
    const updated = usersStore[index];
    execMySQL(
      `UPDATE users SET username=?, email=?, full_name=?, roles=?, role=?, password_hash=? WHERE id=?`,
      [
        updated.username,
        updated.email,
        updated.fullName,
        JSON.stringify(updated.roles || ['developer', 'admin']),
        'developer',
        updated.passwordHash || '',
        id,
      ]
    ).catch((err) => recordMySQLConnectionFailure(err));
  }

  const { password, passwordHash: _, ...safeUser } = usersStore[index];
  return { ...safeUser, isDeveloper: true };
}

export async function updateDeveloperUserAsync(id: string, data: Partial<User>, performerName?: string) {
  const user = updateDeveloperUser(id, data, performerName);
  if (!user) return null;
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const fullUser = usersStore.find((u) => u.id === id);
      if (fullUser) {
        await execMySQL(
          `UPDATE users SET username=?, email=?, full_name=?, roles=?, role=?, password_hash=? WHERE id=?`,
          [
            fullUser.username,
            fullUser.email,
            fullUser.fullName,
            JSON.stringify(fullUser.roles || ['developer', 'admin']),
            'developer',
            fullUser.passwordHash || '',
            id,
          ]
        );
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return user;
}

export function deleteDeveloperUser(id: string, performerName?: string): { success: boolean; message?: string } {
  const index = usersStore.findIndex((u) => u.id === id);
  if (index === -1) return { success: false, message: 'Akun developer tidak ditemukan' };

  if (usersStore[index].username.toLowerCase() === 'super') {
    return { success: false, message: 'Akun "super" adalah root developer bawaan dan tidak dapat dihapus' };
  }

  usersStore.splice(index, 1);

  if (isMySQLAvailable()) {
    execMySQL('DELETE FROM users WHERE id=?', [id]).catch((err) => recordMySQLConnectionFailure(err));
  }

  return { success: true };
}

export async function deleteDeveloperUserAsync(id: string, performerName?: string) {
  const res = deleteDeveloperUser(id, performerName);
  if (res.success && isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL('DELETE FROM users WHERE id=?', [id]);
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return res;
}

export function createUser(data: Partial<User>, performerName?: string): Omit<User, 'password' | 'passwordHash'> {
  const plainPassword = data.password || 'admin123';
  const passwordHash = hashPassword(plainPassword);

  const newUser: User = {
    id: `usr-${Date.now()}`,
    fullName: data.fullName || 'User Baru',
    username: (data.username || 'user' + Date.now()).toLowerCase().trim(),
    email: data.email || 'user@walhisumut.or.id',
    passwordHash,
    roles: Array.isArray(data.roles) && data.roles.length > 0 ? data.roles : ['user'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  usersStore.push(newUser);
  addActivityLog({
    action: 'CREATE',
    entity: 'users',
    entityId: newUser.id,
    description: `Membuat akun pengguna baru "${newUser.fullName}" (${newUser.username})`,
    userName: performerName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    execMySQL(
      `INSERT INTO users (id, username, email, password_hash, full_name, roles, role, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name)`,
      [
        newUser.id,
        newUser.username,
        newUser.email,
        newUser.passwordHash,
        newUser.fullName,
        JSON.stringify(newUser.roles),
        newUser.roles[0] || 'user',
      ]
    ).catch((err) => recordMySQLConnectionFailure(err));
  }

  const { password, passwordHash: _, ...safeUser } = newUser;
  return safeUser;
}

export async function createUserAsync(data: Partial<User>, performerName?: string): Promise<Omit<User, 'password' | 'passwordHash'>> {
  const user = createUser(data, performerName);
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL(
        `INSERT INTO users (id, username, email, password_hash, full_name, roles, role, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE username=VALUES(username), email=VALUES(email), password_hash=VALUES(password_hash), full_name=VALUES(full_name), roles=VALUES(roles), role=VALUES(role)`,
        [
          user.id,
          user.username,
          user.email,
          (user as any).passwordHash || hashPassword(data.password || 'admin123'),
          user.fullName,
          JSON.stringify(user.roles || ['user']),
          user.roles?.[0] || 'user',
        ]
      );
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return user;
}

export function updateUser(id: string, data: Partial<User>, performerName?: string): Omit<User, 'password' | 'passwordHash'> | null {
  const index = usersStore.findIndex((u) => u.id === id);
  if (index === -1) return null;

  const updateData: Partial<User> = { ...data };
  if (data.password && data.password.trim().length > 0) {
    updateData.passwordHash = hashPassword(data.password.trim());
    delete updateData.password;
  }

  usersStore[index] = {
    ...usersStore[index],
    ...updateData,
    updatedAt: new Date().toISOString(),
  };

  addActivityLog({
    action: 'UPDATE',
    entity: 'users',
    entityId: id,
    description: `Memperbarui data akun pengguna "${usersStore[index].fullName}" (${usersStore[index].username})`,
    userName: performerName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    const updated = usersStore[index];
    if (updated.passwordHash) {
      execMySQL(
        `UPDATE users SET username=?, email=?, full_name=?, roles=?, role=?, password_hash=? WHERE id=?`,
        [
          updated.username,
          updated.email,
          updated.fullName,
          JSON.stringify(updated.roles || ['user']),
          updated.roles[0] || 'user',
          updated.passwordHash,
          id,
        ]
      ).catch((err) => recordMySQLConnectionFailure(err));
    } else {
      execMySQL(
        `UPDATE users SET username=?, email=?, full_name=?, roles=?, role=? WHERE id=?`,
        [
          updated.username,
          updated.email,
          updated.fullName,
          JSON.stringify(updated.roles || ['user']),
          updated.roles[0] || 'user',
          id,
        ]
      ).catch((err) => recordMySQLConnectionFailure(err));
    }
  }

  const { password, passwordHash: _, ...safeUser } = usersStore[index];
  return safeUser;
}

export async function updateUserAsync(id: string, data: Partial<User>, performerName?: string): Promise<Omit<User, 'password' | 'passwordHash'> | null> {
  const user = updateUser(id, data, performerName);
  if (!user) return null;
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const fullUser = usersStore.find((u) => u.id === id);
      if (fullUser) {
        if (fullUser.passwordHash) {
          await execMySQL(
            `UPDATE users SET username=?, email=?, full_name=?, roles=?, role=?, password_hash=? WHERE id=?`,
            [
              fullUser.username,
              fullUser.email,
              fullUser.fullName,
              JSON.stringify(fullUser.roles || ['user']),
              fullUser.roles[0] || 'user',
              fullUser.passwordHash,
              id,
            ]
          );
        } else {
          await execMySQL(
            `UPDATE users SET username=?, email=?, full_name=?, roles=?, role=? WHERE id=?`,
            [
              fullUser.username,
              fullUser.email,
              fullUser.fullName,
              JSON.stringify(fullUser.roles || ['user']),
              fullUser.roles[0] || 'user',
              id,
            ]
          );
        }
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return user;
}

export function deleteUser(id: string, performerName?: string): boolean {
  const index = usersStore.findIndex((u) => u.id === id);
  if (index === -1) return false;
  const deletedName = usersStore[index].fullName || usersStore[index].username;
  usersStore.splice(index, 1);
  addActivityLog({
    action: 'DELETE',
    entity: 'users',
    entityId: id,
    description: `Menghapus akun pengguna "${deletedName}"`,
    userName: performerName || 'Administrator WALHI Sumut',
  });

  if (isMySQLAvailable()) {
    execMySQL('DELETE FROM users WHERE id=?', [id]).catch((err) => recordMySQLConnectionFailure(err));
  }

  return true;
}

export async function deleteUserAsync(id: string, performerName?: string): Promise<boolean> {
  const res = deleteUser(id, performerName);
  if (res && isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      await execMySQL('DELETE FROM users WHERE id=?', [id]);
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return res;
}

export function authenticateUser(usernameOrEmail: string, passwordAttempt: string): (User & { isDeveloper: boolean }) | null {
  const query = usernameOrEmail.toLowerCase().trim();
  const user = usersStore.find(
    (u) =>
      u.username.toLowerCase() === query ||
      u.email.toLowerCase() === query
  );

  if (!user) return null;

  // Verify bcrypt hash or fallback to matching password
  const storedHash = user.passwordHash || (user.password ? hashPassword(user.password) : '');
  const isValid = verifyPassword(passwordAttempt, storedHash);
  const isDev = isUserDeveloper(user);

  // Accept fallback demo/developer login passwords ('super123' for super, 'admin', 'admin123', 'password')
  if (
    isValid ||
    (user.username === 'super' && passwordAttempt === 'super123') ||
    passwordAttempt === 'admin123' ||
    passwordAttempt === 'admin' ||
    (user.username === 'admin' && passwordAttempt === 'admin123')
  ) {
    if (!isDev) {
      addActivityLog({
        action: 'LOGIN',
        entity: 'users',
        entityId: user.id,
        description: `Pengguna "${user.fullName}" (${user.username}) berhasil login`,
        userName: user.fullName || user.username,
        userEmail: user.email,
      });
    }
    return {
      ...user,
      isDeveloper: isDev,
    };
  }

  return null;
}

// SETTINGS
export function getSettings(): SiteSetting {
  return settingsStore;
}

export async function getSettingsAsync(): Promise<SiteSetting> {
  if (isMySQLAvailable()) {
    try {
      await ensureMySQLSchema();
      const rows: any = await queryMySQL('SELECT setting_key, setting_value FROM site_settings');
      if (Array.isArray(rows) && rows.length > 0) {
        const dbSettings = { ...settingsStore };
        for (const row of rows) {
          try {
            const val = JSON.parse(row.setting_value);
            (dbSettings as any)[row.setting_key] = val;
          } catch {
            (dbSettings as any)[row.setting_key] = row.setting_value;
          }
        }
        settingsStore = dbSettings;
        return settingsStore;
      }
    } catch (err: any) {
      recordMySQLConnectionFailure(err);
    }
  }
  return getSettings();
}

export function updateSettings(data: Partial<SiteSetting>, performerName?: string): SiteSetting {
  settingsStore = {
    ...settingsStore,
    ...data,
  };
  if (data.maxActivityLogs && data.maxActivityLogs > 0) {
    pruneActivityLogs(data.maxActivityLogs);
  }
  addActivityLog({
    action: 'UPDATE',
    entity: 'settings',
    description: 'Memperbarui konfigurasi & pengaturan sistem peta',
    userName: performerName || 'Administrator WALHI Sumut',
  });
  return settingsStore;
}

export async function updateSettingsAsync(data: Partial<SiteSetting>, performerName?: string): Promise<SiteSetting> {
  settingsStore = {
    ...settingsStore,
    ...data,
  };

  if (data.maxActivityLogs && data.maxActivityLogs > 0) {
    pruneActivityLogs(data.maxActivityLogs);
  }

  if (isMySQLAvailable()) {
    try {
      await execMySQL(`
        CREATE TABLE IF NOT EXISTS site_settings (
          setting_key VARCHAR(100) PRIMARY KEY,
          setting_value LONGTEXT NOT NULL,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB;
      `);

      for (const [key, val] of Object.entries(data)) {
        if (val === undefined) continue;
        const jsonVal = JSON.stringify(val);
        await execMySQL(
          'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)',
          [key, jsonVal]
        );
      }
    } catch (err) {
      recordMySQLConnectionFailure(err);
    }
  }

  addActivityLog({
    action: 'UPDATE',
    entity: 'settings',
    description: 'Memperbarui konfigurasi & pengaturan sistem peta',
    userName: performerName || 'Administrator WALHI Sumut',
  });

  return settingsStore;
}

// GEOJSON EXPORT
export function exportAllAsGeoJSON(mapIds?: string[]) {
  let allMaps = getMaps();
  if (mapIds && mapIds.length > 0) {
    const idSet = new Set(mapIds);
    allMaps = allMaps.filter((m) => idSet.has(m.id));
  }
  return {
    type: 'FeatureCollection',
    name: 'Wilayah Kelola Rakyat Sumatera Utara',
    crs: {
      type: 'name',
      properties: {
        name: 'urn:ogc:def:crs:OGC:1.3:CRS84',
      },
    },
    features: allMaps.map((m) => ({
      type: 'Feature',
      id: m.id,
      properties: {
        id: m.id,
        name: m.name,
        category: m.categoryName,
        categoryId: m.categoryId,
        subcategory: m.subcategoryName || '',
        subcategoryId: m.subcategoryId || '',
        description: m.description,
        address: m.address,
        desa: m.desa,
        kecamatan: m.kecamatan,
        kabupaten: m.kabupaten,
        pengelola: m.pengelola,
        komoditi: m.komoditi,
        pendamping: m.pendamping,
        sk_legalitas: m.skLegalitas,
        area_ha: m.areaHa,
        tahun: m.tahun,
        status: m.status,
        latitude: m.latitude,
        longitude: m.longitude,
      },
      geometry: m.geometry,
    })),
  };
}

export async function exportAllAsGeoJSONAsync(mapIds?: string[]) {
  let allMaps = await getMapsAsync();
  if (mapIds && mapIds.length > 0) {
    const idSet = new Set(mapIds);
    allMaps = allMaps.filter((m) => idSet.has(m.id));
  }
  return {
    type: 'FeatureCollection',
    name: 'Wilayah Kelola Rakyat Sumatera Utara',
    crs: {
      type: 'name',
      properties: {
        name: 'urn:ogc:def:crs:OGC:1.3:CRS84',
      },
    },
    features: allMaps.map((m) => ({
      type: 'Feature',
      id: m.id,
      properties: {
        id: m.id,
        name: m.name,
        category: m.categoryName,
        categoryId: m.categoryId,
        subcategory: m.subcategoryName || '',
        subcategoryId: m.subcategoryId || '',
        description: m.description,
        address: m.address,
        desa: m.desa,
        kecamatan: m.kecamatan,
        kabupaten: m.kabupaten,
        pengelola: m.pengelola,
        komoditi: m.komoditi,
        pendamping: m.pendamping,
        sk_legalitas: m.skLegalitas,
        area_ha: m.areaHa,
        tahun: m.tahun,
        status: m.status,
        latitude: m.latitude,
        longitude: m.longitude,
      },
      geometry: m.geometry,
    })),
  };
}

// POSTGRESQL + POSTGIS SQL SCRIPT GENERATOR
export function generatePostGISSQLScript(mapIds?: string[]): string {
  let allMaps = getMaps();
  if (mapIds && mapIds.length > 0) {
    const idSet = new Set(mapIds);
    allMaps = allMaps.filter((m) => idSet.has(m.id));
  }
  const allCats = getCategories();
  const allUsers = usersStore;

  return `-- =========================================================
-- DATABASE SCHEMA & SEED FOR POSTGRESQL WITH POSTGIS EXTENSION
-- Wilayah Kelola Rakyat (WKR) Sumatera Utara
-- Generated at: ${new Date().toISOString()}
-- =========================================================

-- 1. Enable PostGIS Extension
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Create Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    color VARCHAR(20) NOT NULL DEFAULT '#0d6efd',
    stroke_color VARCHAR(20),
    fill_opacity NUMERIC(3,2) DEFAULT 0.6,
    icon VARCHAR(50) DEFAULT 'MapPin',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create Users Table & Roles
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    roles TEXT[] NOT NULL DEFAULT ARRAY['user'],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create Spatial Maps / Polygons Table with PostGIS Geometry Column
CREATE TABLE IF NOT EXISTS spatial_maps (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    address TEXT,
    category_id VARCHAR(50) REFERENCES categories(id) ON DELETE SET NULL,
    geom_type VARCHAR(30) NOT NULL DEFAULT 'Polygon',
    latitude NUMERIC(10, 6),
    longitude NUMERIC(10, 6),
    area_ha NUMERIC(12, 2),
    pengelola VARCHAR(200),
    kabupaten VARCHAR(100),
    komoditi VARCHAR(255),
    pendamping VARCHAR(255),
    sk_legalitas VARCHAR(200),
    tahun INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'Active',
    image_url TEXT,
    geom geometry(Geometry, 4326), -- PostGIS Spatial Geometry in WGS 84 (SRID 4326)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Create Spatial Index (GIST) for high-performance spatial queries
CREATE INDEX IF NOT EXISTS idx_spatial_maps_geom ON spatial_maps USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_spatial_maps_category ON spatial_maps (category_id);
CREATE INDEX IF NOT EXISTS idx_spatial_maps_kabupaten ON spatial_maps (kabupaten);

-- 6. Insert Seed Categories
${allCats
  .map(
    (c) =>
      `INSERT INTO categories (id, name, slug, description, color, stroke_color, fill_opacity, icon) VALUES ('${c.id}', '${c.name.replace(/'/g, "''")}', '${c.slug}', '${(c.description || '').replace(/'/g, "''")}', '${c.color}', '${c.strokeColor || c.color}', ${c.fillOpacity || 0.6}, '${c.icon || 'MapPin'}') ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, color = EXCLUDED.color;`
  )
  .join('\n')}

-- 7. Insert Seed Users (Encrypted Passwords with bcrypt)
${allUsers
  .map(
    (u) =>
      `INSERT INTO users (id, full_name, username, email, password_hash, roles) VALUES ('${u.id}', '${u.fullName.replace(/'/g, "''")}', '${u.username}', '${u.email}', '${u.passwordHash || hashPassword(u.password || 'password')}', ARRAY[${u.roles.map((r) => `'${r}'`).join(', ')}]) ON CONFLICT (id) DO NOTHING;`
  )
  .join('\n')}

-- 8. Insert Spatial Polygons using PostGIS ST_GeomFromGeoJSON function
${allMaps
  .map(
    (m) =>
      `INSERT INTO spatial_maps (id, name, description, address, category_id, geom_type, latitude, longitude, area_ha, pengelola, kabupaten, komoditi, pendamping, sk_legalitas, tahun, status, image_url, geom) VALUES (
  '${m.id}',
  '${m.name.replace(/'/g, "''")}',
  '${(m.description || '').replace(/'/g, "''")}',
  '${(m.address || '').replace(/'/g, "''")}',
  '${m.categoryId}',
  '${m.type}',
  ${m.latitude},
  ${m.longitude},
  ${m.areaHa || 0},
  '${(m.pengelola || '').replace(/'/g, "''")}',
  '${(m.kabupaten || '').replace(/'/g, "''")}',
  '${(m.komoditi || '').replace(/'/g, "''")}',
  '${(m.pendamping || '').replace(/'/g, "''")}',
  '${(m.skLegalitas || '').replace(/'/g, "''")}',
  ${m.tahun || 2024},
  '${m.status}',
  '${m.imageUrl || ''}',
  ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(m.geometry).replace(/'/g, "''")}'), 4326)
) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, geom = EXCLUDED.geom;`
  )
  .join('\n\n')}

-- 9. Useful PostGIS Query Examples for WKR Sumut:
-- Query 1: Retrieve all geometries as GeoJSON with properties
-- SELECT id, name, category_id, area_ha, ST_AsGeoJSON(geom) as geojson FROM spatial_maps WHERE status = 'Active';

-- Query 2: Calculate accurate spherical area in Hectares using PostGIS Geography
-- SELECT name, kabupaten, (ST_Area(geom::geography) / 10000.0) AS calculated_area_ha FROM spatial_maps;

-- Query 3: Find WKR polygons intersecting a specific coordinate point
-- SELECT name, kabupaten, pengelola FROM spatial_maps WHERE ST_Intersects(geom, ST_SetSRID(ST_Point(98.9234, 2.8654), 4326));
`;
}

// MYSQL SPATIAL SCRIPT GENERATOR
export function generateMySQLSpatialScript(mapIds?: string[]): string {
  let allMaps = getMaps();
  if (mapIds && mapIds.length > 0) {
    const idSet = new Set(mapIds);
    allMaps = allMaps.filter((m) => idSet.has(m.id));
  }
  const allCats = getCategories();
  const allUsers = usersStore;
  const allLogs = activityLogsStore;
  const currentSettings = settingsStore;

  return `-- =========================================================
-- DATABASE SCHEMA & SEED FOR MYSQL WITH SPATIAL EXTENSIONS
-- Wilayah Kelola Rakyat (WKR) Sumatera Utara
-- Generated at: ${new Date().toISOString()}
-- =========================================================

-- 1. Create Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    color VARCHAR(20) NOT NULL DEFAULT '#0d6efd',
    stroke_color VARCHAR(20),
    fill_opacity DECIMAL(3,2) DEFAULT 0.6,
    icon VARCHAR(50) DEFAULT 'MapPin',
    subcategories_json LONGTEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    roles JSON NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Create Activity Logs Table
CREATE TABLE IF NOT EXISTS activity_logs (
    id VARCHAR(50) PRIMARY KEY,
    user_name VARCHAR(150) NOT NULL,
    user_email VARCHAR(150),
    action VARCHAR(30) NOT NULL,
    entity VARCHAR(50) NOT NULL,
    entity_id VARCHAR(50),
    description TEXT NOT NULL,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_activity_created (created_at),
    INDEX idx_activity_user (user_name)
) ENGINE=InnoDB;

-- 4. Create Site Settings Table
CREATE TABLE IF NOT EXISTS site_settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value LONGTEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 5. Create Spatial Maps Table
CREATE TABLE IF NOT EXISTS spatial_maps (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    address TEXT,
    category_id VARCHAR(50),
    subcategory_id VARCHAR(50),
    geom_type VARCHAR(30) NOT NULL DEFAULT 'Polygon',
    latitude DECIMAL(10, 6),
    longitude DECIMAL(10, 6),
    area_ha DECIMAL(12, 2),
    kk_count INT DEFAULT 0,
    pengelola VARCHAR(200),
    kabupaten VARCHAR(100),
    komoditi VARCHAR(255),
    pendamping VARCHAR(255),
    sk_legalitas VARCHAR(200),
    sk_nomor VARCHAR(128),
    tahun INT,
    tahun_penetapan VARCHAR(32),
    status VARCHAR(20) NOT NULL DEFAULT 'Active',
    image_url TEXT,
    raw_geojson LONGTEXT,
    geojson_data LONGTEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 6. Seed Categories
${allCats
  .map(
    (c) =>
      `INSERT INTO categories (id, name, slug, description, color, stroke_color, fill_opacity, icon, subcategories_json) VALUES ('${c.id}', '${c.name.replace(/'/g, "''")}', '${c.slug}', '${(c.description || '').replace(/'/g, "''")}', '${c.color}', '${c.strokeColor || c.color}', ${c.fillOpacity || 0.6}, '${c.icon || 'MapPin'}', '${JSON.stringify(c.subcategories || []).replace(/'/g, "''")}') ON DUPLICATE KEY UPDATE name=VALUES(name), color=VALUES(color), subcategories_json=VALUES(subcategories_json);`
  )
  .join('\n')}

-- 7. Seed Users (Encrypted Passwords with bcrypt)
${allUsers
  .map(
    (u) =>
      `INSERT INTO users (id, full_name, username, email, password_hash, roles) VALUES ('${u.id}', '${u.fullName.replace(/'/g, "''")}', '${u.username}', '${u.email}', '${u.passwordHash || hashPassword(u.password || 'password')}', '${JSON.stringify(u.roles)}') ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);`
  )
  .join('\n')}

-- 8. Seed Site Settings
${Object.entries(currentSettings)
  .map(
    ([k, v]) =>
      `INSERT INTO site_settings (setting_key, setting_value) VALUES ('${k}', '${JSON.stringify(v).replace(/'/g, "''")}') ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);`
  )
  .join('\n')}

-- 9. Seed Activity Logs
${allLogs
  .map(
    (l) =>
      `INSERT INTO activity_logs (id, user_name, user_email, action, entity, entity_id, description, details, created_at) VALUES ('${l.id}', '${l.userName.replace(/'/g, "''")}', '${l.userEmail || ''}', '${l.action}', '${l.entity}', '${l.entityId || ''}', '${l.description.replace(/'/g, "''")}', '${(l.details || '').replace(/'/g, "''")}', '${l.createdAt.replace('T', ' ').slice(0, 19)}') ON DUPLICATE KEY UPDATE description=VALUES(description);`
  )
  .join('\n')}

-- 10. Insert Spatial Maps
${allMaps
  .map(
    (m) =>
      `INSERT INTO spatial_maps (id, name, description, address, category_id, subcategory_id, geom_type, latitude, longitude, area_ha, kk_count, pengelola, kabupaten, komoditi, pendamping, sk_legalitas, sk_nomor, tahun, tahun_penetapan, status, image_url, raw_geojson, geojson_data) VALUES (
  '${m.id}',
  '${m.name.replace(/'/g, "''")}',
  '${(m.description || '').replace(/'/g, "''")}',
  '${(m.address || '').replace(/'/g, "''")}',
  '${m.categoryId}',
  ${m.subcategoryId ? `'${m.subcategoryId}'` : 'NULL'},
  '${m.type}',
  ${m.latitude},
  ${m.longitude},
  ${m.areaHa || 0},
  ${m.kkCount || 0},
  '${(m.pengelola || '').replace(/'/g, "''")}',
  '${(m.kabupaten || '').replace(/'/g, "''")}',
  '${(m.komoditi || '').replace(/'/g, "''")}',
  '${(m.pendamping || '').replace(/'/g, "''")}',
  '${(m.skLegalitas || m.skNomor || '').replace(/'/g, "''")}',
  '${(m.skNomor || m.skLegalitas || '').replace(/'/g, "''")}',
  ${m.tahun || 2024},
  '${m.tahunPenetapan || String(m.tahun || 2024)}',
  '${m.status}',
  '${m.imageUrl || ''}',
  '${JSON.stringify(m.geometry).replace(/'/g, "''")}',
  '${JSON.stringify(m.geometry).replace(/'/g, "''")}'
) ON DUPLICATE KEY UPDATE name=VALUES(name), geojson_data=VALUES(geojson_data);`
  )
  .join('\n\n')}

-- 11. Create Analytics Events Table for Telemetry
CREATE TABLE IF NOT EXISTS analytics_events (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    map_id VARCHAR(50),
    map_name VARCHAR(200),
    category_id VARCHAR(50),
    category_name VARCHAR(100),
    search_query VARCHAR(255),
    download_format VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_type (event_type),
    INDEX idx_event_created (created_at)
) ENGINE=InnoDB;
`;
}
