-- =========================================================================
-- SCHEMA & SEED DATA SISTEM INFORMASI GEOGRAFIS (SIG)
-- WILAYAH KELOLA RAKYAT (WKR) - EKSEKUTIF DAERAH WALHI SUMATERA UTARA
-- Database: walhisum_gis / wkr_walhisumut
-- Compatibility: MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.3+ (phpMyAdmin / cPanel / VPS)
-- =========================================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+07:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- -------------------------------------------------------------------------
-- 1. TABEL: `categories` (Kategori Kawasan WKR)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `color` VARCHAR(20) NOT NULL DEFAULT '#0d6efd',
  `stroke_color` VARCHAR(20) DEFAULT '#0a58ca',
  `fill_opacity` DECIMAL(3,2) DEFAULT 0.60,
  `icon` VARCHAR(50) DEFAULT 'MapPin',
  `subcategories_json` LONGTEXT DEFAULT NULL,
  `sort_order` INT(11) DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categories_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Data Categories WKR WALHI Sumut
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `color`, `stroke_color`, `fill_opacity`, `icon`, `subcategories_json`, `sort_order`) VALUES
('cat-ps', 'Perhutanan Sosial', 'perhutanan-sosial', 'Sistem pengelolaan hutan lestari yang dilaksanakan dalam kawasan hutan negara atau hutan hak/hutan adat oleh masyarakat setempat.', '#0d6efd', '#0a58ca', 0.65, 'Trees', '[{"id":"sub-hkm","name":"Hutan Kemasyarakatan","slug":"hutan-kemasyarakatan","color":"#ffc107","description":"HKm - Izin/Persetujuan Pengelolaan Hutan Kemasyarakatan"},{"id":"sub-hd","name":"Hutan Desa","slug":"hutan-desa","color":"#059669","description":"HD - Hak Pengelolaan Hutan Desa"},{"id":"sub-ha","name":"Hutan Adat","slug":"hutan-adat","color":"#6f42c1","description":"HA - Pengakuan Hutan Adat"},{"id":"sub-htr","name":"Hutan Tanaman Rakyat","slug":"hutan-tanaman-rakyat","color":"#0284c7","description":"HTR - Hutan Tanaman Rakyat"},{"id":"sub-kk","name":"Kemitraan Kehutanan","slug":"kemitraan-kehutanan","color":"#fd7e14","description":"KK - Kemitraan Kehutanan"}]', 1),
('cat-1', 'Hanya Mengelola', 'hanya-mengelola', 'Wilayah yang dikelola mandiri oleh kelompok masyarakat/komunitas lokal secara turun-temurun.', '#e83e8c', '#d63384', 0.60, 'TreePine', '[]', 2),
('cat-4', 'IPHPS', 'iphps', 'Izin Pemanfaatan Hutan Perhutanan Sosial pada kawasan hutan produksi atau lindung.', '#ffc107', '#d39e00', 0.60, 'FileCheck', '[]', 3),
('cat-7', 'Lainnya', 'lainnya', 'Inisiatif wilayah kelola rakyat, kebun agroforestri, dan konservasi berbasis masyarakat lainnya.', '#20c997', '#198754', 0.60, 'Landmark', '[]', 4)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`), `color`=VALUES(`color`), `description`=VALUES(`description`), `subcategories_json`=VALUES(`subcategories_json`);

-- -------------------------------------------------------------------------
-- 2. TABEL: `users` (Pengguna, Akun Staf & Hak Akses RBAC)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `username` VARCHAR(80) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `roles` JSON NOT NULL,
  `role` VARCHAR(50) DEFAULT 'admin',
  `is_active` TINYINT(1) DEFAULT 1,
  `avatar` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Data Users (Password 'super' = super123, Password 'admin' = admin123)
INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `password_hash`, `roles`, `role`, `is_active`, `avatar`) VALUES
('usr-dev-super', 'Super Developer (Root)', 'super', 'developer@walhisumut.or.id', '$2b$10$77HnYanDnFhOWs0hcyY68.Pu2/l0jM12uahPNsboe6fU8DuUJsn6m', '["developer","admin"]', 'developer', 1, NULL),
('usr-admin-001', 'Administrator WALHI Sumut', 'admin', 'gis@walhisumut.or.id', '$2a$10$rN7x7Yd27Z3sRzLKnZfNneW4.rG0LdO6YtqJpLg4bW9D.Qj1C5Mla', '["superadmin","admin"]', 'admin', 1, NULL),
('usr-editor-002', 'Staf Pemetaan & GIS', 'editor_gis', 'pemetaan@walhisumut.or.id', '$2a$10$rN7x7Yd27Z3sRzLKnZfNneW4.rG0LdO6YtqJpLg4bW9D.Qj1C5Mla', '["editor"]', 'editor', 1, NULL)
ON DUPLICATE KEY UPDATE `full_name`=VALUES(`full_name`), `roles`=VALUES(`roles`), `role`=VALUES(`role`), `is_active`=1;

-- -------------------------------------------------------------------------
-- 3. TABEL: `spatial_maps` (Data Spasial Polygon, Titik & Atribut WKR)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `spatial_maps` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `desa` VARCHAR(100) DEFAULT NULL,
  `kecamatan` VARCHAR(100) DEFAULT NULL,
  `kabupaten` VARCHAR(100) DEFAULT NULL,
  `category_id` VARCHAR(50) DEFAULT NULL,
  `subcategory_id` VARCHAR(50) DEFAULT NULL,
  `geom_type` VARCHAR(30) NOT NULL DEFAULT 'Polygon',
  `latitude` DECIMAL(10, 6) DEFAULT NULL,
  `longitude` DECIMAL(10, 6) DEFAULT NULL,
  `area_ha` DECIMAL(12, 2) DEFAULT 0.00,
  `kk_count` INT(11) DEFAULT 0,
  `proses` TEXT DEFAULT NULL,
  `pengelola` VARCHAR(200) DEFAULT NULL,
  `komoditi` VARCHAR(255) DEFAULT NULL,
  `pendamping` VARCHAR(255) DEFAULT NULL,
  `sk_legalitas` VARCHAR(200) DEFAULT NULL,
  `sk_nomor` VARCHAR(128) DEFAULT NULL,
  `tahun` INT(11) DEFAULT NULL,
  `tahun_penetapan` VARCHAR(32) DEFAULT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'Active',
  `image_url` TEXT DEFAULT NULL,
  `kontak` VARCHAR(255) DEFAULT NULL,
  `raw_geojson` LONGTEXT DEFAULT NULL,
  `geojson_data` LONGTEXT DEFAULT NULL,
  `sort_order` INT(11) DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_spatial_category` (`category_id`),
  KEY `idx_spatial_kabupaten` (`kabupaten`),
  KEY `idx_spatial_status` (`status`),
  CONSTRAINT `fk_spatial_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Data Spatial Maps WKR Sumatera Utara
INSERT INTO `spatial_maps` (
  `id`, `name`, `description`, `address`, `desa`, `kecamatan`, `kabupaten`, 
  `category_id`, `subcategory_id`, `geom_type`, `latitude`, `longitude`, `area_ha`, 
  `kk_count`, `proses`, `pengelola`, `komoditi`, `pendamping`, `sk_legalitas`, `sk_nomor`, 
  `tahun`, `tahun_penetapan`, `status`, `image_url`, `raw_geojson`, `geojson_data`
) VALUES 
(
  'map-1',
  'Wilayah Adat Sihaporas (MHA Sihaporas)',
  'Wilayah kelola adat keturunan Ompu Mamontang Laut Ambarita di kawasan Sihaporas. Kawasan ini mempertahankan hutan kemenyan, mata air pegunungan, dan tanah adat turun temurun.',
  'Desa Sihaporas, Kec. Pematang Sidamanik, Kab. Simalungun, Sumatera Utara',
  'Sihaporas',
  'Pematang Sidamanik',
  'Simalungun',
  'cat-ps',
  'sub-ha',
  'Polygon',
  2.865400,
  98.923400,
  2048.50,
  380,
  'Proses Usulan SK Penetapan Hutan Adat',
  'Lembaga Adat Keturunan Ompu Mamontang Laut Ambarita (Lamtoras)',
  'Kemenyan (Haminjon), Kopi Arabika, Andaliman',
  'KSPPM & WALHI Sumatera Utara',
  'Proses Usulan SK Penetapan Hutan Adat KLHK / Perda',
  'Usulan Penetapan MHA Sihaporas',
  2021,
  '2021',
  'Active',
  'https://images.unsplash.com/photo-1511497584788-87676104235f?q=80&w=800&auto=format&fit=crop',
  '{"type":"Polygon","coordinates":[[[98.9100,2.8750],[98.9350,2.8800],[98.9450,2.8600],[98.9300,2.8450],[98.9050,2.8550],[98.9100,2.8750]]]}',
  '{"type":"Polygon","coordinates":[[[98.9100,2.8750],[98.9350,2.8800],[98.9450,2.8600],[98.9300,2.8450],[98.9050,2.8550],[98.9100,2.8750]]]}'
),
(
  'map-2',
  'Hutan Kemasyarakatan (HKm) Muara Nauli Samosir',
  'Pengelolaan hutan berbasis masyarakat di perbukitan Danau Toba untuk rehabilitasi tutupan hutan, perlindungan tata air Danau Toba, dan peningkatan ekonomi rakyat melalui agroforestri ramah lingkungan.',
  'Desa Simanindo, Kec. Simanindo, Kab. Samosir, Sumatera Utara',
  'Simanindo',
  'Simanindo',
  'Samosir',
  'cat-ps',
  'sub-hkm',
  'Polygon',
  2.684000,
  98.752000,
  1250.00,
  245,
  'SK Penetapan Terbit (2018)',
  'Koperasi HKm Sejahtera Mandiri Samosir',
  'Kopi Arabika Typica, Kayu Manis, Alpukat, Hortikultura Ramah Lingkungan',
  'WALHI Sumatera Utara',
  'SK.4312/MENLHK-PSKL/PKPS/PSL.0/7/2018',
  'SK.4312/MENLHK-PSKL/PKPS/PSL.0/7/2018',
  2018,
  '2018',
  'Active',
  'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=800&auto=format&fit=crop',
  '{"type":"Polygon","coordinates":[[[98.7300,2.6950],[98.7700,2.7000],[98.7750,2.6700],[98.7400,2.6650],[98.7300,2.6950]]]}',
  '{"type":"Polygon","coordinates":[[[98.7300,2.6950],[98.7700,2.7000],[98.7750,2.6700],[98.7400,2.6650],[98.7300,2.6950]]]}'
),
(
  'map-3',
  'Hutan Desa (HD) Timbang Lawang Bahorok',
  'Zona penyangga Ekosistem Leuser yang dikelola oleh Lembaga Pengelola Hutan Desa (LPHD) Timbang Lawang guna melindungi koridor satwa Orangutan Sumatera dan mata air sungai Bahorok.',
  'Desa Timbang Lawang, Kec. Bahorok, Kab. Langkat, Sumatera Utara',
  'Timbang Lawang',
  'Bahorok',
  'Langkat',
  'cat-ps',
  'sub-hd',
  'Polygon',
  3.548000,
  98.145000,
  890.00,
  160,
  'SK Penetapan Terbit (2018)',
  'Lembaga Pengelola Hutan Desa (LPHD) Timbang Lawang',
  'Kakao Organik, Karet Rakyat, Durian Lokal, Ekowisata Alam',
  'Yayasan Orangutan Sumatera Lestari (YOSL-OIC) & WALHI Sumut',
  'SK.5611/MENLHK-PSKL/PKPS/PSL.0/9/2018',
  'SK.5611/MENLHK-PSKL/PKPS/PSL.0/9/2018',
  2018,
  '2018',
  'Active',
  'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=800&auto=format&fit=crop',
  '{"type":"Polygon","coordinates":[[[98.1300,3.5650],[98.1650,3.5600],[98.1600,3.5350],[98.1350,3.5300],[98.1200,3.5500],[98.1300,3.5650]]]}',
  '{"type":"Polygon","coordinates":[[[98.1300,3.5650],[98.1650,3.5600],[98.1600,3.5350],[98.1350,3.5300],[98.1200,3.5500],[98.1300,3.5650]]]}'
),
(
  'map-4',
  'Wilayah Adat Pandumaan-Sipituhuta',
  'Hutan Kemenyan (Tombak Haminjon) yang dikelola masyarakat adat Pandumaan dan Sipituhuta selama berabad-abad sebagai sumber kehidupan dan identitas kultural Batak Toba.',
  'Desa Pandumaan, Kec. Pollung, Kab. Humbang Hasundutan, Sumatera Utara',
  'Pandumaan',
  'Pollung',
  'Humbang Hasundutan',
  'cat-1',
  NULL,
  'Polygon',
  2.298000,
  98.642000,
  5172.00,
  520,
  'Perda & SK Enclave KLHK',
  'Komunitas Masyarakat Adat Pandumaan - Sipituhuta',
  'Getah Kemenyan Super, Kopi Tipika, Kayu Manis',
  'KSPPM, AMAN Tano Batak, WALHI Sumut',
  'Perda Kab. Humbang Hasundutan & SK Enclave KLHK',
  'SK Enclave Hutan Kemenyan',
  2016,
  '2016',
  'Active',
  'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=800&auto=format&fit=crop',
  '{"type":"Polygon","coordinates":[[[98.6100,2.3200],[98.6650,2.3300],[98.6800,2.2900],[98.6400,2.2600],[98.6050,2.2850],[98.6100,2.3200]]]}',
  '{"type":"Polygon","coordinates":[[[98.6100,2.3200],[98.6650,2.3300],[98.6800,2.2900],[98.6400,2.2600],[98.6050,2.2850],[98.6100,2.3200]]]}'
),
(
  'map-5',
  'Kemitraan Kehutanan KTH Mandiri Sejahtera Batang Toru',
  'Kelompok tani hutan bermitra mengelola areal pemulihan ekosistem di koridor Batang Toru dengan tanaman produktif kopi, petai, jengkol, dan getah damar.',
  'Desa Marancar, Kec. Marancar, Kab. Tapanuli Selatan, Sumatera Utara',
  'Marancar',
  'Marancar',
  'Tapanuli Selatan',
  'cat-ps',
  'sub-kk',
  'Polygon',
  1.554000,
  99.123000,
  740.00,
  115,
  'NKK KPH Wilayah X',
  'KTH Mandiri Sejahtera Marancar',
  'Kopi Robusta, Petai Hutan, Jengkol, Damar Kaca',
  'WALHI Sumatera Utara',
  'Naskah Kesepakatan Kerjasama (NKK) Kemitraan',
  'NKK.021/KPHP-XI/2019',
  2019,
  '2019',
  'Active',
  'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?q=80&w=800&auto=format&fit=crop',
  '{"type":"Polygon","coordinates":[[[99.1050,1.5650],[99.1400,1.5600],[99.1350,1.5350],[99.1080,1.5400],[99.1050,1.5650]]]}',
  '{"type":"Polygon","coordinates":[[[99.1050,1.5650],[99.1400,1.5600],[99.1350,1.5350],[99.1080,1.5400],[99.1050,1.5650]]]}'
)
ON DUPLICATE KEY UPDATE 
  `name`=VALUES(`name`),
  `area_ha`=VALUES(`area_ha`),
  `kk_count`=VALUES(`kk_count`),
  `proses`=VALUES(`proses`),
  `description`=VALUES(`description`),
  `geojson_data`=VALUES(`geojson_data`);

-- -------------------------------------------------------------------------
-- 4. TABEL: `activity_logs` (Riwayat Aktivitas, Audit Trail & Auto-Pruning)
-- -------------------------------------------------------------------------
-- Catatan: Sistem membatasi jumlah baris secara dinamis (FIFO Auto-Pruning)
-- berdasarkan nilai `maxActivityLogs` yang dikonfigurasi di `site_settings`.
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` VARCHAR(50) NOT NULL,
  `user_name` VARCHAR(150) NOT NULL,
  `user_email` VARCHAR(150) DEFAULT NULL,
  `action` VARCHAR(30) NOT NULL,
  `entity` VARCHAR(50) NOT NULL DEFAULT 'system',
  `entity_id` VARCHAR(50) DEFAULT NULL,
  `description` TEXT NOT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_activity_created` (`created_at`),
  KEY `idx_activity_user` (`user_name`),
  KEY `idx_activity_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Initial Activity Logs
INSERT INTO `activity_logs` (`id`, `user_name`, `user_email`, `action`, `entity`, `entity_id`, `description`, `details`, `created_at`) VALUES
('log-init-001', 'Administrator WALHI Sumut', 'gis@walhisumut.or.id', 'CREATE', 'maps', 'map-1', 'Menambahkan data peta WKR "Wilayah Adat Sihaporas (MHA Sihaporas)"', 'Inisialisasi data peta WKR', NOW() - INTERVAL 25 MINUTE),
('log-init-002', 'Staf Pemetaan & GIS', 'pemetaan@walhisumut.or.id', 'UPDATE', 'categories', 'cat-ps', 'Memperbarui informasi kategori "Perhutanan Sosial"', 'Penyesuaian kode warna dan subkategori', NOW() - INTERVAL 2 HOUR),
('log-init-003', 'Administrator WALHI Sumut', 'gis@walhisumut.or.id', 'LOGIN', 'users', 'usr-admin-001', 'Berhasil melakukan autentikasi login ke sistem', 'Login dari perangkat admin', NOW() - INTERVAL 3 HOUR),
('log-init-004', 'Sistem', 'system@walhisumut.or.id', 'SYSTEM', 'system', NULL, 'Inisialisasi sistem basis data SIG WKR WALHI Sumatera Utara berhasil', 'Database schema migration executed', NOW() - INTERVAL 5 HOUR)
ON DUPLICATE KEY UPDATE `description`=VALUES(`description`);

-- -------------------------------------------------------------------------
-- 5. TABEL: `site_settings` (Konfigurasi Sistem, Batas Log, SEO & Analitik)
-- -------------------------------------------------------------------------
-- Menyimpan parameter sistem, pengaturan batas kapasitas log aktivitas,
-- indeksasi mesin pencari Google & Bing, serta tracking Google Analytics GA4.
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_settings` (
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Default Settings (Termasuk Log Limit, Search Engine & Analytics)
INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('id', '"setting-default"'),
('title', '"Peta Interaktif WALHI Sumatera Utara"'),
('description', '"Sistem Informasi Geografis interaktif Wilayah Kelola Rakyat (WKR) di Provinsi Sumatera Utara. Mengintegrasikan data spasial batas wilayah, hutan desa, HKm, kemitraan, dan hutan adat."'),
('mapCenterLat', '2.35'),
('mapCenterLng', '99.15'),
('mapZoom', '8'),
('maskOutsideSumut', 'true'),
('showSumutLabels', 'true'),
('showBoundaryLayer', 'true'),
('activeBasemap', '"OpenStreetMap"'),
('contactEmail', '"kontak@walhisumut.or.id"'),
('sourceAttribution', '"walhisumut.or.id | pantaulingkungan.id"'),
-- PENGATURAN LOG: Batas kapasitas baris catatan aktivitas (Auto-Prune FIFO)
('maxActivityLogs', '100'),
-- PENGATURAN SEO & PENGINDEKSAN MESIN PENCARI (Google & Bing)
('searchEngineIndexingEnabled', 'true'),
('googleVerificationCode', '""'),
('bingVerificationCode', '""'),
-- PENGATURAN ANALITIK (Google Analytics 4 / GA4)
('googleAnalyticsEnabled', 'false'),
('googleAnalyticsId', '""'),
-- PENGATURAN MODE PEMELIHARAAN (Under Construction)
('underConstructionEnabled', 'false'),
('underConstructionTitle', '"Situs Sedang Dalam Pemeliharaan & Pembaruan"'),
('underConstructionMessage', '"Portal Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara saat ini sedang dalam proses pemeliharaan berkala dan sinkronisasi data sistem. Kami akan segera kembali online melayani publik."'),
('underConstructionEstimatedTime', '"Segera Kembali Online"'),
('underConstructionContact', '"kontak@walhisumut.or.id"')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);

-- -------------------------------------------------------------------------
-- 6. VIEW KOMPATIBILITAS (Opsional: Backward Compatibility untuk Legacy App)
-- -------------------------------------------------------------------------
CREATE OR REPLACE VIEW `wkr_areas` AS 
SELECT 
  `id`,
  `name` AS `nama_kawasan`,
  `category_id`,
  `kabupaten`,
  `kecamatan`,
  `desa`,
  `area_ha` AS `luas_ha`,
  `kk_count` AS `jumlah_kk`,
  `proses`,
  `komoditi` AS `komoditas_utama`,
  `sk_legalitas` AS `sk_hukum`,
  `sk_nomor` AS `nomor_sk`,
  `tahun`,
  `description` AS `deskripsi`,
  `latitude`,
  `longitude`,
  `geojson_data` AS `geojson`,
  `image_url` AS `foto_kawasan`,
  `status`
FROM `spatial_maps`;

CREATE OR REPLACE VIEW `app_settings` AS
SELECT 
  `setting_key` AS `key_name`,
  `setting_value` AS `value_json`,
  `updated_at`
FROM `site_settings`;

COMMIT;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
