<?php
/**
 * Plugin Name: Peta Interaktif WALHI Sumut (WKR Widget)
 * Plugin URI: https://walhisumut.or.id
 * Description: Plugin & Shortcode resmi untuk menyematkan Peta Spasial Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara ke halaman, artikel, atau widget WordPress. Data terhubung langsung secara realtime dengan server GIS aplikasi ini.
 * Version: 1.0.0
 * Author: WALHI Sumatera Utara
 * Author URI: https://walhisumut.or.id
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Konfigurasi URL Server Peta GIS WALHI Sumut
 * Anda dapat mengubah konstanta ini jika aplikasi peta dihosting di domain/subdomain khusus
 */
if (!defined('PETA_WALHISUMUT_DEFAULT_URL')) {
    define('PETA_WALHISUMUT_DEFAULT_URL', 'https://walhisumut.or.id/widget');
}

/**
 * Shortcode [peta_walhisumut]
 * 
 * Penggunaan:
 * [peta_walhisumut]
 * [peta_walhisumut height="650px"]
 * [peta_walhisumut height="700px" width="100%" radius="16px"]
 * [peta_walhisumut url="https://subdomain.anda.com/widget" height="600px"]
 */
function peta_walhisumut_shortcode_handler($atts) {
    $atts = shortcode_atts(array(
        'url'    => '',
        'height' => '650px',
        'width'  => '100%',
        'radius' => '12px',
        'shadow' => 'true',
        'border' => 'none',
        'title'  => 'Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara',
    ), $atts, 'peta_walhisumut');

    // Tentukan URL peta GIS
    $map_url = !empty($atts['url']) ? esc_url($atts['url']) : PETA_WALHISUMUT_DEFAULT_URL;
    $map_url = apply_filters('peta_walhisumut_embed_url', $map_url);

    $height       = esc_attr($atts['height']);
    $width        = esc_attr($atts['width']);
    $radius       = esc_attr($atts['radius']);
    $title        = esc_attr($atts['title']);
    $shadow_style = ($atts['shadow'] === 'true') ? 'box-shadow: 0 4px 20px rgba(0,0,0,0.08);' : '';
    $border_style = esc_attr($atts['border']);

    return sprintf(
        '<div class="peta-walhisumut-widget-wrapper" style="width:%s; margin: 16px auto; max-width:100%%; position:relative; clear:both;">
            <iframe 
                src="%s" 
                width="100%%" 
                height="%s" 
                style="border:%s; width:100%%; height:%s; border-radius:%s; %s display:block; overflow:hidden;" 
                title="%s"
                allow="geolocation"
                allowfullscreen="true"
                loading="lazy">
            </iframe>
        </div>',
        $width,
        $map_url,
        $height,
        $border_style,
        $height,
        $radius,
        $shadow_style,
        $title
    );
}
add_shortcode('peta_walhisumut', 'peta_walhisumut_shortcode_handler');
add_shortcode('peta_wkr', 'peta_walhisumut_shortcode_handler');

/**
 * Widget Klasik WordPress (Appearance -> Widgets)
 */
class Peta_WalhiSumut_WP_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'peta_walhisumut_widget',
            __('Peta Interaktif WALHI Sumut', 'peta-walhisumut'),
            array('description' => __('Menampilkan widget peta interaktif WKR WALHI Sumatera Utara secara realtime.', 'peta-walhisumut'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        $height = !empty($instance['height']) ? $instance['height'] : '550px';
        $url    = !empty($instance['url']) ? $instance['url'] : '';
        echo do_shortcode('[peta_walhisumut height="' . esc_attr($height) . '" url="' . esc_attr($url) . '"]');
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title  = !empty($instance['title']) ? $instance['title'] : __('Peta Wilayah Kelola Rakyat', 'peta-walhisumut');
        $height = !empty($instance['height']) ? $instance['height'] : '550px';
        $url    = !empty($instance['url']) ? $instance['url'] : '';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Judul Widget:'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('height')); ?>"><?php _e('Tinggi Peta (misal: 550px, 650px):'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('height')); ?>" name="<?php echo esc_attr($this->get_field_name('height')); ?>" type="text" value="<?php echo esc_attr($height); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('url')); ?>"><?php _e('URL Widget Khusus (Opsional, kosongkan untuk default):'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('url')); ?>" name="<?php echo esc_attr($this->get_field_name('url')); ?>" type="text" value="<?php echo esc_attr($url); ?>" placeholder="https://domain-anda.com/widget">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title']  = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['height'] = (!empty($new_instance['height'])) ? sanitize_text_field($new_instance['height']) : '550px';
        $instance['url']    = (!empty($new_instance['url'])) ? esc_url_raw($new_instance['url']) : '';
        return $instance;
    }
}

function register_peta_walhisumut_wp_widget() {
    register_widget('Peta_WalhiSumut_WP_Widget');
}
add_action('widgets_init', 'register_peta_walhisumut_wp_widget');
