'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { SiteSetting } from '@/lib/types';
import {
  Wrench,
  Clock,
  Mail,
  ExternalLink,
  RefreshCw,
  Globe,
} from 'lucide-react';

interface UnderConstructionViewProps {
  settings: SiteSetting;
}

export default function UnderConstructionView({
  settings,
}: UnderConstructionViewProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    if (typeof window !== 'undefined') {
      window.location.reload();
    }
  };

  const title =
    settings.underConstructionTitle || 'Situs Sedang Dalam Pemeliharaan & Pembaruan';
  const message =
    settings.underConstructionMessage ||
    'Portal Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara saat ini sedang dalam proses pemeliharaan berkala dan sinkronisasi data sistem. Kami akan segera kembali online melayani publik.';
  const estimatedTime =
    settings.underConstructionEstimatedTime || 'Segera Kembali Online';
  const contact =
    settings.underConstructionContact ||
    settings.contactEmail ||
    'kontak@walhisumut.or.id';
  const isEmail = contact.includes('@') && !contact.includes(' ');

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Background Decorative Pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-emerald-500 blur-3xl" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-amber-500 blur-3xl" />
        <div className="w-full h-full bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px]" />
      </div>

      {/* Top Navigation Bar */}
      <header className="relative z-10 w-full border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white px-2.5 py-1 rounded-md shadow-xs flex items-center shrink-0">
              <Image
                src={
                  settings.logoUrl ||
                  'https://walhisumut.or.id/wp-content/uploads/2023/12/WALHIBAWAH2-1.png'
                }
                alt="WALHI Sumatera Utara Logo"
                width={130}
                height={38}
                className="h-7 sm:h-8 w-auto object-contain"
                referrerPolicy="no-referrer"
                priority
              />
            </div>
            <div className="hidden sm:block border-l border-slate-700 pl-3">
              <p className="text-xs font-bold text-slate-200 uppercase tracking-tight">
                {settings.navbarTitle || 'Peta Interaktif WKR Sumut'}
              </p>
              <p className="text-[10px] text-slate-400">
                Sistem Informasi Geografis Lingkungan Hidup
              </p>
            </div>
          </div>

          <a
            href="https://walhisumut.or.id"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-all border border-slate-700 shadow-xs"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>walhisumut.or.id</span>
          </a>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 sm:px-6 py-12">
        <div className="max-w-2xl w-full mx-auto text-center space-y-8">
          {/* Status Badge */}
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold tracking-wide animate-pulse">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>UNDER CONSTRUCTION &bull; MODE PEMELIHARAAN SISTEM</span>
          </div>

          {/* Icon Graphic Container */}
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-br from-emerald-500/20 via-slate-800 to-amber-500/10 border border-slate-700/80 shadow-2xl flex items-center justify-center text-emerald-400 relative">
                <Wrench className="w-12 h-12 sm:w-14 sm:h-14 stroke-[1.75]" />
                <div className="absolute -bottom-2 -right-2 w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-lg border-2 border-slate-900">
                  <Clock className="w-5 h-5 stroke-[2.2]" />
                </div>
              </div>
            </div>
          </div>

          {/* Title & Description */}
          <div className="space-y-3">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-tight">
              {title}
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto leading-relaxed">
              {message}
            </p>
          </div>

          {/* Status Details Card */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-5 max-w-lg mx-auto backdrop-blur-md shadow-xl text-left space-y-3.5">
            <div className="flex items-center justify-between text-xs pb-3 border-b border-slate-700/60">
              <span className="text-slate-400 font-medium flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Status Pemulihan:</span>
              </span>
              <span className="font-semibold text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-800/60">
                {estimatedTime}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium flex items-center space-x-1.5 shrink-0">
                <Mail className="w-3.5 h-3.5 text-sky-400" />
                <span>Kontak / Informasi:</span>
              </span>
              {isEmail ? (
                <a
                  href={`mailto:${contact}`}
                  className="text-sky-400 hover:text-sky-300 underline underline-offset-2 font-medium break-all"
                >
                  {contact}
                </a>
              ) : (
                <span className="text-slate-200 font-medium text-right pl-3 break-words">
                  {contact}
                </span>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3.5 pt-2">
            <button
              type="button"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs sm:text-sm transition-all cursor-pointer disabled:opacity-50 shadow-md"
            >
              <RefreshCw
                className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-400' : 'text-slate-400'}`}
              />
              <span>{isRefreshing ? 'Memeriksa...' : 'Cek Status Situs'}</span>
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full border-t border-slate-800/80 bg-slate-950/60 py-4 text-center text-xs text-slate-400">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span suppressHydrationWarning>
            &copy; {new Date().getFullYear()} WALHI Sumatera Utara. Hak Cipta Dilindungi.
          </span>
          <div className="flex items-center space-x-4 text-[11px]">
            <a
              href="https://walhisumut.or.id"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-emerald-400 flex items-center space-x-1"
            >
              <span>Portal WALHI Sumut</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
