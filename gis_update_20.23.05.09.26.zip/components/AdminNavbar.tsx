'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  FolderTree,
  Map as MapIcon,
  Settings,
  Users,
  LogOut,
  Globe,
  ChevronDown,
  UserCheck,
  UserPlus,
  Shield,
  User,
  Menu,
  X,
  Terminal,
  Code2,
} from 'lucide-react';

interface AdminNavbarProps {
  siteTitle?: string;
  userFullName?: string;
}

export default function AdminNavbar({
  siteTitle = 'Sumatera Utara',
  userFullName = 'Administrator',
}: AdminNavbarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [usersDropdownOpen, setUsersDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [isDeveloper, setIsDeveloper] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [siteLogo, setSiteLogo] = useState<string>('https://walhisumut.or.id/wp-content/uploads/2023/12/WALHIBAWAH2-1.png');
  const [customTitle, setCustomTitle] = useState<string>('');

  const usersDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/auth')
      .then((res) => res.json())
      .then((data) => {
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
          setIsDeveloper(Boolean(data.isDeveloper || data.user.isDeveloper || data.user.username === 'super'));
        }
      })
      .catch(() => {});

    fetch('/api/settings')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data) {
          if (data.data.logoUrl) setSiteLogo(data.data.logoUrl);
          if (data.data.navbarTitle) setCustomTitle(data.data.navbarTitle);
        }
      })
      .catch(() => {});
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        usersDropdownRef.current &&
        !usersDropdownRef.current.contains(event.target as Node)
      ) {
        setUsersDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await fetch('/api/auth', { method: 'DELETE' });
      router.push('/login');
      router.refresh();
    } catch {
      router.push('/login');
    } finally {
      setLoggingOut(false);
    }
  };

  const navItems = [
    {
      label: 'Dashboard',
      href: '/admin',
      icon: LayoutDashboard,
      active: pathname === '/admin',
    },
    {
      label: 'Kategori',
      href: '/admin/categories',
      icon: FolderTree,
      active: pathname.startsWith('/admin/categories'),
    },
    {
      label: 'Data',
      href: '/admin/maps',
      icon: MapIcon,
      active: pathname.startsWith('/admin/maps'),
    },
    {
      label: 'Pengaturan Sistem',
      href: '/admin/settings',
      icon: Settings,
      active: pathname === '/admin/settings',
    },
    {
      label: 'Pengaturan Akun',
      href: '/admin/account',
      icon: Shield,
      active: pathname.startsWith('/admin/account'),
    },
    ...(isDeveloper
      ? [
          {
            label: 'Widget WordPress',
            href: '/admin/widget',
            icon: Code2,
            active: pathname.startsWith('/admin/widget'),
            isDev: true,
          },
          {
            label: 'Konsol Developer',
            href: '/admin/developer',
            icon: Terminal,
            active: pathname.startsWith('/admin/developer'),
            isDev: true,
          },
        ]
      : []),
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      {/* Top Banner Bar matching Geometric Balance Theme */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-4">
        {/* Left: Logo & System Title */}
        <div className="flex items-center space-x-3.5">
          <Link href="/admin" className="flex items-center shrink-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={siteLogo || 'https://walhisumut.or.id/wp-content/uploads/2023/12/WALHIBAWAH2-1.png'}
              alt="Logo Sistem"
              className="h-9 sm:h-10 max-w-[180px] w-auto object-contain"
              referrerPolicy="no-referrer"
            />
          </Link>
          <div className="border-l border-slate-200 pl-3 hidden sm:block max-w-[280px]">
            <span className="text-xs font-bold text-slate-900 tracking-tight leading-none line-clamp-1">
              {customTitle ? customTitle : 'PANEL ADMIN'}
            </span>
          </div>
        </div>

        {/* Right: Quick actions & Logout */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Public Map Link */}
          <Link
            href="/"
            target="_blank"
            className="hidden sm:inline-flex items-center space-x-1.5 px-3 py-1.5 rounded border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors shadow-2xs"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600" />
            <span>PETA PUBLIK</span>
          </Link>

          {/* Developer Root Badge */}
          {isDeveloper && (
            <Link
              href="/admin/developer"
              className="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded bg-emerald-950 border border-emerald-500/50 text-[10px] font-black text-emerald-300 font-mono uppercase tracking-wider shadow-2xs hover:bg-emerald-900 transition-colors"
              title="Akses Konsol Pengembang (Developer)"
            >
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">ROOT / DEV</span>
            </Link>
          )}

          {/* User Account Quick Link */}
          <Link
            href="/admin/account"
            className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded border text-xs font-bold transition-colors shadow-2xs ${
              pathname.startsWith('/admin/account')
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <User className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden md:inline">{userFullName}</span>
            <span className="md:hidden">Akun</span>
          </Link>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            disabled={loggingOut}
            className="inline-flex items-center space-x-1.5 px-3 sm:px-3.5 py-1.5 rounded bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-2xs transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{loggingOut ? 'Keluar...' : 'LOGOUT'}</span>
          </button>

          {/* Mobile menu toggle button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="sm:hidden p-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Desktop Navigation Menu Bar - NO overflow clipping, clean dropdown handling */}
      <div className="border-t border-slate-100 bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="hidden sm:flex items-center space-x-1 py-1.5 relative">
            {navItems.slice(0, 3).map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`inline-flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                    item.active
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white border border-transparent hover:border-slate-200'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${item.active ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </Link>
              );
            })}

            {/* Users Management Dropdown - Perfectly positioned without scroll/overflow clipping */}
            <div className="relative" ref={usersDropdownRef}>
              <button
                type="button"
                onClick={() => setUsersDropdownOpen(!usersDropdownOpen)}
                className={`inline-flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  pathname.startsWith('/admin/users')
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : usersDropdownOpen
                    ? 'bg-white text-slate-900 border border-slate-300 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white border border-transparent hover:border-slate-200'
                }`}
              >
                <Users className={`w-3.5 h-3.5 ${pathname.startsWith('/admin/users') ? 'text-white' : 'text-slate-400'}`} />
                <span>Kelola Pengguna</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${
                    usersDropdownOpen ? 'rotate-180 text-emerald-600' : 'text-slate-400'
                  }`}
                />
              </button>

              {usersDropdownOpen && (
                <div
                  className="absolute left-0 top-full mt-1.5 w-60 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2"
                >
                  <div className="px-3.5 py-1.5 border-b border-slate-100 mb-1">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Menu Pengguna & Role
                    </p>
                  </div>

                  <Link
                    href="/admin/users"
                    onClick={() => setUsersDropdownOpen(false)}
                    className={`flex items-center space-x-2.5 px-3.5 py-2 text-xs font-semibold transition-colors ${
                      pathname === '/admin/users'
                        ? 'bg-emerald-50 text-emerald-700 font-bold'
                        : 'text-slate-700 hover:bg-slate-50 hover:text-emerald-700'
                    }`}
                  >
                    <UserCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="leading-none">Daftar Pengguna</div>
                      <span className="text-[10px] text-slate-400 font-normal">Lihat dan kelola akun</span>
                    </div>
                  </Link>

                  <Link
                    href="/admin/users/create"
                    onClick={() => setUsersDropdownOpen(false)}
                    className={`flex items-center space-x-2.5 px-3.5 py-2 text-xs font-semibold transition-colors ${
                      pathname === '/admin/users/create'
                        ? 'bg-emerald-50 text-emerald-700 font-bold'
                        : 'text-slate-700 hover:bg-slate-50 hover:text-emerald-700'
                    }`}
                  >
                    <UserPlus className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="leading-none">Tambah Pengguna Baru</div>
                      <span className="text-[10px] text-slate-400 font-normal">Buat akun & tetapkan role</span>
                    </div>
                  </Link>

                  <div className="border-t border-slate-100 my-1"></div>

                  <Link
                    href="/admin/account"
                    onClick={() => setUsersDropdownOpen(false)}
                    className={`flex items-center space-x-2.5 px-3.5 py-2 text-xs font-semibold transition-colors ${
                      pathname.startsWith('/admin/account')
                        ? 'bg-emerald-50 text-emerald-700 font-bold'
                        : 'text-slate-700 hover:bg-slate-50 hover:text-emerald-700'
                    }`}
                  >
                    <Shield className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="leading-none">Pengaturan Akun & Role</div>
                      <span className="text-[10px] text-slate-400 font-normal">Matriks hak akses Anda</span>
                    </div>
                  </Link>

                  {isDeveloper && (
                    <>
                      <div className="border-t border-slate-100 my-1"></div>
                      <Link
                        href="/admin/developer"
                        onClick={() => setUsersDropdownOpen(false)}
                        className={`flex items-center space-x-2.5 px-3.5 py-2 text-xs font-semibold transition-colors ${
                          pathname.startsWith('/admin/developer')
                            ? 'bg-emerald-950 text-emerald-300 font-bold'
                            : 'text-emerald-900 bg-emerald-50/70 hover:bg-emerald-100/80'
                        }`}
                      >
                        <Terminal className="w-4 h-4 text-emerald-600 shrink-0" />
                        <div>
                          <div className="leading-none flex items-center space-x-1.5">
                            <span className="font-bold">Akun Khusus Developer</span>
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-700 text-white font-mono uppercase">ROOT</span>
                          </div>
                          <span className="text-[10px] text-emerald-700/80 font-normal">Kelola dev, MySQL & deploy</span>
                        </div>
                      </Link>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Remaining nav items: Settings & Account */}
            {navItems.slice(3).map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`inline-flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                    item.active
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white border border-transparent hover:border-slate-200'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${item.active ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Mobile Drawer / Dropdown */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2 shadow-lg animate-in slide-in-from-top-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider ${
                  item.active
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Icon className="w-4 h-4 text-emerald-600" />
                <span>{item.label}</span>
              </Link>
            );
          })}

          <div className="pt-2 border-t border-slate-100 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 py-1">
              Manajemen Pengguna
            </p>
            <Link
              href="/admin/users"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>Daftar Pengguna</span>
            </Link>
            <Link
              href="/admin/users/create"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              <UserPlus className="w-4 h-4 text-emerald-600" />
              <span>Tambah Pengguna Baru</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
