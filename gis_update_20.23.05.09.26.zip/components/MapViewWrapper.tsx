'use client';

import dynamic from 'next/dynamic';
import React, { useSyncExternalStore } from 'react';
import Link from 'next/link';
import CircularLoading from '@/components/CircularLoading';
import UnderConstructionView from '@/components/UnderConstructionView';
import { MapRecord, Category, SiteSetting } from '@/lib/types';
import { AlertTriangle, Settings } from 'lucide-react';

const PublicMapView = dynamic(() => import('@/components/PublicMapView'), {
  ssr: false,
  loading: () => <CircularLoading progress={0} fullscreen={true} />,
});

interface MapViewWrapperProps {
  initialMaps: MapRecord[];
  initialCategories: Category[];
  initialSettings: SiteSetting;
  isLoggedInServer?: boolean;
  hideHeader?: boolean;
}

function subscribeToAuth(callback: () => void) {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener('storage', callback);
  return () => window.removeEventListener('storage', callback);
}

function getClientAuthSnapshot(): boolean {
  try {
    const hasCookie = typeof document !== 'undefined' && document.cookie.includes('wkr_auth_token=');
    const hasStorage = typeof window !== 'undefined' && Boolean(localStorage.getItem('wkr_auth_token'));
    return Boolean(hasCookie || hasStorage);
  } catch {
    return false;
  }
}

function getServerAuthSnapshot(): boolean {
  return false;
}

export default function MapViewWrapper(props: MapViewWrapperProps) {
  const { initialSettings, isLoggedInServer } = props;

  const isClientLoggedIn = useSyncExternalStore(
    subscribeToAuth,
    getClientAuthSnapshot,
    getServerAuthSnapshot
  );

  const isLoggedIn = Boolean(isLoggedInServer) || isClientLoggedIn;
  const isUnderConstruction = Boolean(initialSettings.underConstructionEnabled);

  // If under construction is ON and user is NOT logged in: Show Under Construction screen
  if (isUnderConstruction && !isLoggedIn) {
    return <UnderConstructionView settings={initialSettings} />;
  }

  // If user is logged in or under construction is OFF: Show standard map view
  return (
    <div className="relative w-full h-full">
      {/* Floating alert banner for logged-in users when under construction is active */}
      {isUnderConstruction && isLoggedIn && !props.hideHeader && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-[9999] max-w-xl w-[90%] sm:w-auto bg-amber-500 text-slate-950 px-3.5 py-1.5 rounded-full shadow-lg border border-amber-600 flex items-center justify-between gap-3 text-xs font-semibold animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex items-center space-x-2 shrink-0">
            <span className="w-2 h-2 rounded-full bg-red-700 animate-ping" />
            <AlertTriangle className="w-3.5 h-3.5 text-slate-950" />
            <span>
              Mode Under Construction Aktif &bull; Peta hanya tampil untuk user login.
            </span>
          </div>
          <Link
            href="/admin/settings?tab=system"
            className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-slate-950 text-white text-[11px] font-bold hover:bg-slate-800 transition-colors shrink-0"
          >
            <Settings className="w-3 h-3" />
            <span>Atur</span>
          </Link>
        </div>
      )}

      {isUnderConstruction && isLoggedIn && props.hideHeader && (
        <div className="absolute top-2 right-2 z-[9999] bg-amber-500 text-slate-950 px-2.5 py-1 rounded-full text-[10px] font-bold shadow-md border border-amber-600 flex items-center space-x-1">
          <span className="w-1.5 h-1.5 rounded-full bg-red-700 animate-ping" />
          <span>Under Construction (Staf)</span>
        </div>
      )}

      <PublicMapView {...props} hideHeader={props.hideHeader} />
    </div>
  );
}

