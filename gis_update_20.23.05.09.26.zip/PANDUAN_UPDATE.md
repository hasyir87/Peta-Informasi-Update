# Panduan Update Perubahan Sistem SIG WKR WALHI Sumatera Utara
**Versi Sistem:** v05.09.2026 (05 September 2026)

Dokumen ini berisi panduan untuk menerapkan paket update perubahan terbaru pada aplikasi Peta Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara.

---

## Ringkasan Fitur Baru pada Paket Update Ini

1. **Fitur Pembaruan Mandiri (Self-Update Tanpa Terminal / Node.js Setup)**:
   - Pengembang/Admin kini dapat memperbarui aplikasi secara langsung melalui menu **Developer Console -> Tab "Pembaruan Mandiri (Self-Update)"**.
   - Cukup mengunggah file ZIP pembaruan (misal: `update-perubahan-peta-walhisumut.zip`), lalu menekan tombol **"Terapkan Pembaruan Sekarang"**.
   - Sistem akan mengekstrak file pembaruan, mencadangkan file lama secara otomatis, dan mengeksekusi migrasi database jika ada file SQL tanpa harus membuka terminal atau login SSH / cPanel.

2. **Sistem Pencadangan Otomatis & Rollback (Kembali ke Versi Sebelumnya)**:
   - Sebelum berkas baru diterapkan, sistem otomatis membuat berkas cadangan (`backups/backup_[versi]_[timestamp].zip`).
   - Apabila proses pembaruan gagal, sistem secara otomatis melakukan rollback ke kondisi sebelumnya.
   - Tersedia tombol **"Kembalikan ke Versi Ini (Rollback)"** dengan 1 klik pada riwayat versi jika pengembang ingin mengembalikan aplikasi ke versi sebelumnya kapan saja.

3. **Penamaan Versi Berdasarkan Tanggal, Bulan, dan Tahun**:
   - Versi aplikasi kini secara otomatis mengikuti format: `v[Tanggal].[Bulan].[Tahun]` (contoh: `v05.09.2026` untuk 05 September 2026).
   - Label versi ditampilkan secara transparan di header Konsol Developer, footer, dan riwayat sistem.

4. **Widget WordPress Resmi WALHI Sumut (Tanpa Headbar)**:
   - Mode headless widget pada rute `/widget` dan `/embed` tanpa headbar dengan floating search bar.
   - Plugin WordPress siap pakai `peta-walhi-sumut-widget.zip` untuk shortcode `[peta_walhisumut]` dan Gutenberg block.
   - Menu pengelolaan dan generator kode widget di `/admin/widget`.

---

## Cara Menerapkan Update

### METODE UTAMA (Sangat Direkomendasikan): Pembaruan Mandiri Melalui Menu Developer
1. Buka menu **Konsol Developer** di browser: `/admin/developer`.
2. Pilih tab **"Pembaruan Mandiri (Self-Update)"**.
3. Tarik & lepas atau pilih berkas `update-perubahan-peta-walhisumut.zip`.
4. Sistem akan menampilkan pratinjau berkas yang diperbarui dan target versi baru.
5. Klik tombol **"Terapkan Pembaruan Sekarang (Update Mandiri)"**.
6. Selesai! Aplikasi langsung terupdate dan database langsung termigrasi secara mandiri tanpa perlu terminal atau setup Node.js ulang.
7. *Catatan:* Jika terjadi kendala, klik tombol **"Kembalikan ke Versi Ini"** pada tabel Riwayat Versi untuk melakukan rollback instan.

---

### METODE ALTERNATIF (Manual via cPanel / Terminal)
Jika server Anda tidak mengizinkan penulisan berkas langsung melalui Node.js:
1. Upload file ZIP ke root direktori domain aplikasi Anda di cPanel File Manager.
2. Ekstrak file ZIP dan timpa (overwrite) file yang ada.
3. Jika terdapat file SQL (misal `update_database_*.sql`), jalankan di phpMyAdmin.
4. Restart aplikasi Node.js melalui menu **Setup Node.js App** di cPanel dengan menekan tombol **Restart**.

#### Metode B: Jika Menggunakan Paket Deploy Produksi
1. Upload file ZIP ke root direktori domain aplikasi Anda di cPanel File Manager.
2. Ekstrak file ZIP dan replace file yang ada.
3. Restart aplikasi Node.js melalui menu **Setup Node.js App** di cPanel dengan menekan tombol **Restart**.

---

## Verifikasi Hasil Update
1. **Pengaturan Identitas & Logo**: Buka `/admin/settings` -> Kustomisasi Logo, Favicon, Judul Navbar, dan Tab Browser. Klik Simpan dan periksa apakah logo langsung berubah di frontend dan navbar admin.
2. **Peta Publik & Loading**: Buka halaman utama `/`, perhatikan animasi loading bar dengan persentase saat data dimuat, serta coba fitur pencarian peta di mana dropdown hasil pencarian kini berada di lapisan terdepan.
3. **Admin Form**: Buka `/admin/maps/create` atau edit peta, verifikasi label "Jumlah KK" bersih tanpa embel-embel numerik dan input tersimpan cepat.

---
*Tim GIS & Teknologi Informasi WALHI Sumatera Utara*

