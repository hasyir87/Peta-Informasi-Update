-- =========================================================================
-- FILE MIGRASI / UPDATE DATABASE SIG WKR WALHI SUMATERA UTARA
-- Versi Pembaruan: 2026-09-04
-- Target Database: MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.3+
-- Deskripsi:
-- 1. Penambahan kolom `proses` (TEXT) pada tabel `spatial_maps`
-- 2. Penyesuaian kolom `kk_count` (INT) untuk Jumlah Kepala Keluarga (KK)
-- 3. Pembaruan VIEW kompatibilitas `wkr_areas`
-- =========================================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- -------------------------------------------------------------------------
-- 1. PENAMBAHAN KOLOM `proses` KE TABEL `spatial_maps`
-- (Jika MySQL versi Anda belum mendukung 'IF NOT EXISTS' pada ALTER TABLE,
--  jalankan ALTER TABLE spatial_maps ADD COLUMN proses TEXT DEFAULT NULL)
-- -------------------------------------------------------------------------
ALTER TABLE `spatial_maps` 
ADD COLUMN IF NOT EXISTS `proses` TEXT DEFAULT NULL AFTER `kk_count`;

-- -------------------------------------------------------------------------
-- 2. PENYESUAIAN TIPE DATA `kk_count` MENJADI INT (JUMLAH KK)
-- -------------------------------------------------------------------------
ALTER TABLE `spatial_maps` 
MODIFY COLUMN `kk_count` INT(11) DEFAULT 0;

-- -------------------------------------------------------------------------
-- 3. PERBARUI DATA DEFAULT PETA WKR (OPSIONAL UNTUK DATA SEEDING AWAL)
-- -------------------------------------------------------------------------
UPDATE `spatial_maps` 
SET `proses` = 'Proses Usulan SK Penetapan Hutan Adat' 
WHERE `id` = 'map-1' AND (`proses` IS NULL OR `proses` = '');

UPDATE `spatial_maps` 
SET `proses` = 'SK Penetapan Terbit (2018)' 
WHERE `id` = 'map-2' AND (`proses` IS NULL OR `proses` = '');

UPDATE `spatial_maps` 
SET `proses` = 'SK Penetapan Terbit (2018)' 
WHERE `id` = 'map-3' AND (`proses` IS NULL OR `proses` = '');

UPDATE `spatial_maps` 
SET `proses` = 'Perda & SK Enclave KLHK' 
WHERE `id` = 'map-4' AND (`proses` IS NULL OR `proses` = '');

UPDATE `spatial_maps` 
SET `proses` = 'NKK KPH Wilayah X' 
WHERE `id` = 'map-5' AND (`proses` IS NULL OR `proses` = '');

-- -------------------------------------------------------------------------
-- 4. PEMBARUAN VIEW `wkr_areas` (MENCAKUP `proses` DAN `jumlah_kk`)
-- -------------------------------------------------------------------------
CREATE OR REPLACE VIEW `wkr_areas` AS 
SELECT 
  `id`,
  `name` AS `nama_kawasan`,
  `category_id`,
  `kabupaten`,
  `kecamatan`,
  `desa`,
  `area_ha` AS `luas_ha`,
  `kk_count` AS `jumlah_kk`,
  `proses`,
  `komoditi` AS `komoditas_utama`,
  `sk_legalitas` AS `sk_hukum`,
  `sk_nomor` AS `nomor_sk`,
  `tahun`,
  `description` AS `deskripsi`,
  `latitude`,
  `longitude`,
  `geojson_data` AS `geojson`,
  `image_url` AS `foto_kawasan`,
  `status`
FROM `spatial_maps`;

-- -------------------------------------------------------------------------
-- 5. TAMBAH / UPDATE AKUN SUPER DEVELOPER ROOT (username: super, password: super123)
-- -------------------------------------------------------------------------
INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `password_hash`, `roles`, `role`, `is_active`) VALUES
('usr-dev-super', 'Super Developer (Root)', 'super', 'developer@walhisumut.or.id', '$2b$10$77HnYanDnFhOWs0hcyY68.Pu2/l0jM12uahPNsboe6fU8DuUJsn6m', '["developer","admin"]', 'developer', 1)
ON DUPLICATE KEY UPDATE `roles`='["developer","admin"]', `role`='developer', `is_active`=1;

-- -------------------------------------------------------------------------
-- 6. TAMBAH PENGATURAN MODE PEMELIHARAAN (UNDER CONSTRUCTION)
-- -------------------------------------------------------------------------
INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('underConstructionEnabled', 'false'),
('underConstructionTitle', '"Situs Sedang Dalam Pemeliharaan & Pembaruan"'),
('underConstructionMessage', '"Portal Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara saat ini sedang dalam proses pemeliharaan berkala dan sinkronisasi data sistem. Kami akan segera kembali online melayani publik."'),
('underConstructionEstimatedTime', '"Segera Kembali Online"'),
('underConstructionContact', '"kontak@walhisumut.or.id"')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

-- Catat aktivitas migrasi pada tabel activity_logs jika tabel tersedia
INSERT INTO `activity_logs` (`id`, `user_name`, `user_email`, `action`, `entity`, `entity_id`, `description`, `details`, `created_at`)
VALUES (
  CONCAT('mig-', DATE_FORMAT(NOW(), '%Y%m%d%H%i%s')),
  'Database Migration Script',
  'system@walhisumut.or.id',
  'MIGRATE',
  'database',
  'spatial_maps',
  'Eksekusi migrasi kolom proses dan penyesuaian kk_count pada spatial_maps',
  'Update schema: ADD COLUMN proses TEXT, MODIFY kk_count INT',
  NOW()
);

COMMIT;
SET FOREIGN_KEY_CHECKS=1;

-- Konfirmasi status
SELECT 'SUKSES: Migrasi database update kolom proses & jumlah KK berhasil diterapkan!' AS `hasil_migrasi`;
