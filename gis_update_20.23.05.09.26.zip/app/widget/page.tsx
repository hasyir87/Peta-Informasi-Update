import React from 'react';
import { cookies } from 'next/headers';
import MapViewWrapper from '@/components/MapViewWrapper';
import { getMapsAsync, getCategoriesAsync, getSettingsAsync } from '@/lib/db';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Widget Peta Interaktif - WALHI Sumatera Utara',
  description: 'Widget Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara tanpa headbar untuk integrasi WordPress & situs web.',
};

export default async function WidgetPage() {
  const maps = await getMapsAsync();
  const categories = await getCategoriesAsync();
  const settings = await getSettingsAsync();

  let isLoggedInServer = false;
  try {
    const cookieStore = await cookies();
    const authToken = cookieStore.get('wkr_auth_token')?.value;
    const userId = cookieStore.get('wkr_user_id')?.value;
    isLoggedInServer = Boolean(authToken && userId);
  } catch {
    // Ignore cookie read error
  }

  return (
    <main className="w-full h-full min-h-[100dvh] max-h-[100dvh] overflow-hidden bg-[#f8fafc]">
      <MapViewWrapper
        initialMaps={maps}
        initialCategories={categories}
        initialSettings={settings}
        isLoggedInServer={isLoggedInServer}
        hideHeader={true}
      />
    </main>
  );
}
