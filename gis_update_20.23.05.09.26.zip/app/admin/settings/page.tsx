'use client';

import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import AdminNavbar from '@/components/AdminNavbar';
import CircularLoading from '@/components/CircularLoading';
import { SiteSetting, GeoJSONGeometry, RoleDefinition, RolePermission, AnalyticsWidgetSettings } from '@/lib/types';
import { SUMUT_MAINLAND_COORDINATES } from '@/lib/sumut-geojson';
import { extractMetaContent } from '@/lib/utils';
import {
  Save,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Shield,
  MapPin,
  Users,
  Check,
  X,
  Loader2,
  Database,
  Search,
  Globe,
  BarChart2,
  Activity,
  ExternalLink,
  RefreshCw,
  Trash2,
  Sliders,
  Sparkles,
  Package,
  Download,
  Terminal,
  Copy,
  Rocket,
  HardDrive,
  Eye,
  EyeOff,
  Wrench,
  Clock,
  AlertTriangle,
  Mail,
} from 'lucide-react';

const LeafletMapEditor = dynamic(() => import('@/components/LeafletMapEditor'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[450px] flex items-center justify-center bg-slate-900 text-slate-100 rounded-lg">
      <div className="flex items-center space-x-2">
        <Loader2 className="w-5 h-5 animate-spin text-emerald-500" />
        <span className="text-xs text-slate-300">Memuat Map Editor...</span>
      </div>
    </div>
  ),
});

export default function SettingsPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'general' | 'system' | 'roles' | 'database' | 'deploy'>(() => {
    if (typeof window !== 'undefined') {
      const tabParam = new URLSearchParams(window.location.search).get('tab');
      if (tabParam === 'system' || tabParam === 'roles' || tabParam === 'database' || tabParam === 'general' || tabParam === 'deploy') {
        return tabParam as 'general' | 'system' | 'roles' | 'database' | 'deploy';
      }
    }
    return 'general';
  });
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);
  const [hideDbTab, setHideDbTab] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('hide_mysql_tab') === 'true';
    }
    return false;
  });
  const [isDeveloper, setIsDeveloper] = useState<boolean>(false);

  const [settings, setSettings] = useState<SiteSetting | null>(null);
  const [roles, setRoles] = useState<RoleDefinition[]>([]);
  const [permissions, setPermissions] = useState<RolePermission[]>([]);
  const [usersCount, setUsersCount] = useState<number>(0);
  const [dbStatus, setDbStatus] = useState<any>(null);
  const [dbSetupLoading, setDbSetupLoading] = useState(false);
  const [showDbPassword, setShowDbPassword] = useState(false);
  const [dbSetupMessage, setDbSetupMessage] = useState<{ success: boolean; text: string } | null>(null);
  const [dbForm, setDbForm] = useState({
    host: '',
    port: '3306',
    user: '',
    password: '',
    database: '',
  });

  const [loading, setLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(15);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  // Form states - General Map
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [faviconUrl, setFaviconUrl] = useState('');
  const [navbarTitle, setNavbarTitle] = useState('');
  const [browserTabTitle, setBrowserTabTitle] = useState('');
  const [mapCenterLat, setMapCenterLat] = useState<number>(2.3500);
  const [mapCenterLng, setMapCenterLng] = useState<number>(99.1500);
  const [mapZoom, setMapZoom] = useState<number>(8);
  const [maskOutsideSumut, setMaskOutsideSumut] = useState<boolean>(true);
  const [showSumutLabels, setShowSumutLabels] = useState<boolean>(true);
  const [showBoundaryLayer, setShowBoundaryLayer] = useState<boolean>(true);

  // Form states - Activity Logs Setting
  const [maxActivityLogs, setMaxActivityLogs] = useState<number>(100);
  const [currentLogsCount, setCurrentLogsCount] = useState<number>(0);
  const [pruningLogs, setPruningLogs] = useState<boolean>(false);
  const [logActionMsg, setLogActionMsg] = useState<{ success: boolean; text: string } | null>(null);

  // Form states - Search Engine Indexing & Verification
  const [searchEngineIndexingEnabled, setSearchEngineIndexingEnabled] = useState<boolean>(true);
  const [googleVerificationCode, setGoogleVerificationCode] = useState<string>('');
  const [bingVerificationCode, setBingVerificationCode] = useState<string>('');
  const [seoVerifying, setSeoVerifying] = useState<boolean>(false);
  const [seoVerifyResult, setSeoVerifyResult] = useState<any>(null);

  // Form states - Google Analytics
  const [googleAnalyticsEnabled, setGoogleAnalyticsEnabled] = useState<boolean>(false);
  const [googleAnalyticsId, setGoogleAnalyticsId] = useState<string>('');
  const [gaVerifying, setGaVerifying] = useState<boolean>(false);
  const [gaVerifyResult, setGaVerifyResult] = useState<any>(null);
  const [gaPingSent, setGaPingSent] = useState<boolean>(false);
  const [analyticsWidgets, setAnalyticsWidgets] = useState<AnalyticsWidgetSettings>({
    showOverviewKpis: true,
    showDailyTrend: true,
    showTopMaps: true,
    showCategoryInteractions: true,
    showDownloadBreakdown: true,
    showAcquisitionChannels: true,
    showSearchQueries: true,
    showGeoDistribution: true,
    showDeviceBreakdown: true,
  });

  // Form states - Under Construction Mode
  const [underConstructionEnabled, setUnderConstructionEnabled] = useState<boolean>(false);
  const [underConstructionTitle, setUnderConstructionTitle] = useState<string>('Situs Sedang Dalam Pemeliharaan & Pembaruan');
  const [underConstructionMessage, setUnderConstructionMessage] = useState<string>('Portal Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara saat ini sedang dalam proses pemeliharaan berkala dan sinkronisasi data sistem. Kami akan segera kembali online melayani publik.');
  const [underConstructionEstimatedTime, setUnderConstructionEstimatedTime] = useState<string>('Segera Kembali Online');
  const [underConstructionContact, setUnderConstructionContact] = useState<string>('kontak@walhisumut.or.id');
  const [showUnderConstructionPreview, setShowUnderConstructionPreview] = useState<boolean>(false);

  // Boundary geometry
  const [boundaryGeometry, setBoundaryGeometry] = useState<GeoJSONGeometry>({
    type: 'Polygon',
    coordinates: [SUMUT_MAINLAND_COORDINATES],
  });

  const fetchLogsCount = async () => {
    try {
      const res = await fetch('/api/activity-logs?limit=1000');
      const data = await res.json();
      if (data.success) {
        setCurrentLogsCount(data.total || 0);
      }
    } catch {}
  };

  useEffect(() => {
    let timer = setInterval(() => {
      setLoadingProgress((prev) => (prev < 90 ? prev + Math.floor(Math.random() * 15) + 5 : prev));
    }, 120);

    Promise.all([
      fetch('/api/settings').then((r) => r.json()),
      fetch('/api/roles').then((r) => r.json()),
      fetch('/api/users').then((r) => r.json()),
      fetch('/api/database/status').then((r) => r.json()),
      fetch('/api/activity-logs?limit=1000').then((r) => r.json()),
      fetch('/api/auth').then((r) => r.json()).catch(() => ({ authenticated: false })),
    ])
      .then(([settingsData, rolesData, usersData, dbStatusData, logsData, authData]) => {
        const isDev = Boolean(authData?.isDeveloper || authData?.user?.isDeveloper || authData?.user?.username === 'super');
        setIsDeveloper(isDev);
        if (!isDev) {
          setActiveTab((prev) => (prev === 'database' || prev === 'deploy' ? 'general' : prev));
        }

        if (settingsData.data) {
          const s: SiteSetting = settingsData.data;
          setSettings(s);
          setTitle(s.title || '');
          setDescription(s.description || '');
          setLogoUrl(s.logoUrl || '');
          setFaviconUrl(s.faviconUrl || '');
          setNavbarTitle(s.navbarTitle || '');
          setBrowserTabTitle(s.browserTabTitle || '');
          setMapCenterLat(s.mapCenterLat || 2.3500);
          setMapCenterLng(s.mapCenterLng || 99.1500);
          setMapZoom(s.mapZoom || 8);
          setMaskOutsideSumut(s.maskOutsideSumut ?? true);
          setShowSumutLabels(s.showSumutLabels ?? true);
          setShowBoundaryLayer(s.showBoundaryLayer ?? true);

          // System Settings
          setMaxActivityLogs(s.maxActivityLogs && s.maxActivityLogs > 0 ? s.maxActivityLogs : 100);
          setSearchEngineIndexingEnabled(s.searchEngineIndexingEnabled !== false);
          setGoogleVerificationCode(s.googleVerificationCode || '');
          setBingVerificationCode(s.bingVerificationCode || '');
          setGoogleAnalyticsEnabled(Boolean(s.googleAnalyticsEnabled));
          setGoogleAnalyticsId(s.googleAnalyticsId || '');
          if (s.analyticsWidgets) {
            setAnalyticsWidgets({
              showOverviewKpis: s.analyticsWidgets.showOverviewKpis ?? true,
              showDailyTrend: s.analyticsWidgets.showDailyTrend ?? true,
              showTopMaps: s.analyticsWidgets.showTopMaps ?? true,
              showCategoryInteractions: s.analyticsWidgets.showCategoryInteractions ?? true,
              showDownloadBreakdown: s.analyticsWidgets.showDownloadBreakdown ?? true,
              showAcquisitionChannels: s.analyticsWidgets.showAcquisitionChannels ?? true,
              showSearchQueries: s.analyticsWidgets.showSearchQueries ?? true,
              showGeoDistribution: s.analyticsWidgets.showGeoDistribution ?? true,
              showDeviceBreakdown: s.analyticsWidgets.showDeviceBreakdown ?? true,
            });
          }

          // Under Construction Mode Setting
          setUnderConstructionEnabled(Boolean(s.underConstructionEnabled));
          if (s.underConstructionTitle) setUnderConstructionTitle(s.underConstructionTitle);
          if (s.underConstructionMessage) setUnderConstructionMessage(s.underConstructionMessage);
          if (s.underConstructionEstimatedTime) setUnderConstructionEstimatedTime(s.underConstructionEstimatedTime);
          if (s.underConstructionContact) setUnderConstructionContact(s.underConstructionContact);

          if (s.sumutBoundaryGeoJSON) {
            let geom = s.sumutBoundaryGeoJSON;
            if (geom.type === 'FeatureCollection' && Array.isArray(geom.features) && geom.features[0]?.geometry) {
              geom = geom.features[0].geometry;
            } else if (geom.type === 'Feature' && geom.geometry) {
              geom = geom.geometry;
            }
            if (geom && geom.coordinates) {
              setBoundaryGeometry(geom);
            }
          }
        }

        if (rolesData.success) {
          const filteredRoles = (rolesData.roles || []).filter((r: any) => r.id !== 'developer');
          const filteredPerms = (rolesData.permissions || []).filter(
            (p: any) => !p.key.startsWith('developer:') && p.key !== 'database:manage' && p.key !== 'deploy:manage'
          );
          setRoles(filteredRoles);
          setPermissions(filteredPerms);
        }

        if (usersData.data) {
          setUsersCount(usersData.data.length || 0);
        }

        if (dbStatusData) {
          setDbStatus(dbStatusData);
          if (dbStatusData.config) {
            setDbForm({
              host: dbStatusData.config.host || '',
              port: String(dbStatusData.config.port || 3306),
              user: dbStatusData.config.user || '',
              password: '',
              database: dbStatusData.config.database || '',
            });
          }
        }

        if (logsData.success) {
          setCurrentLogsCount(logsData.total || 0);
        }
        setLoadingProgress(100);
      })
      .catch((err) => {
        setError(err.message);
        setLoadingProgress(100);
      })
      .finally(() => {
        clearInterval(timer);
        setTimeout(() => setLoading(false), 250);
      });

    return () => {
      clearInterval(timer);
    };
  }, []);

  const handleTestAndSaveDb = async (e: React.FormEvent) => {
    e.preventDefault();
    setDbSetupLoading(true);
    setDbSetupMessage(null);
    try {
      const res = await fetch('/api/database/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: dbForm.host,
          port: Number(dbForm.port) || 3306,
          user: dbForm.user,
          password: dbForm.password,
          database: dbForm.database,
        }),
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.message || 'Koneksi gagal');
      }
      setDbSetupMessage({ success: true, text: 'Koneksi database berhasil diuji dan disesuaikan!' });
      const statusRes = await fetch('/api/database/status');
      const statusData = await statusRes.json();
      setDbStatus(statusData);
    } catch (err: any) {
      setDbSetupMessage({ success: false, text: err.message });
    } finally {
      setDbSetupLoading(false);
    }
  };

  const handleRunCustomDatabaseSetup = async () => {
    if (!confirm(`Apakah Anda yakin ingin menjalankan inisialisasi schema dan seed pada database "${dbForm.database || 'database tujuan'}"?`)) {
      return;
    }
    setDbSetupLoading(true);
    setDbSetupMessage(null);
    try {
      const res = await fetch('/api/database/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: dbForm.host,
          port: Number(dbForm.port) || 3306,
          user: dbForm.user,
          password: dbForm.password,
          database: dbForm.database,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Gagal melakukan setup database');
      }
      setDbSetupMessage({ success: true, text: data.message });
      const statusRes = await fetch('/api/database/status');
      const statusData = await statusRes.json();
      setDbStatus(statusData);
    } catch (err: any) {
      setDbSetupMessage({ success: false, text: err.message });
    } finally {
      setDbSetupLoading(false);
    }
  };

  const handleHideDbTab = () => {
    localStorage.setItem('hide_mysql_tab', 'true');
    setHideDbTab(true);
    if (activeTab === 'database') {
      setActiveTab('general');
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess(false);

    try {
      const payload = {
        title,
        description,
        logoUrl,
        faviconUrl,
        navbarTitle,
        browserTabTitle,
        mapCenterLat: Number(mapCenterLat),
        mapCenterLng: Number(mapCenterLng),
        mapZoom: Number(mapZoom),
        maskOutsideSumut,
        showSumutLabels,
        showBoundaryLayer,
        maxActivityLogs: Number(maxActivityLogs) || 100,
        searchEngineIndexingEnabled,
        googleVerificationCode: extractMetaContent(googleVerificationCode),
        bingVerificationCode: extractMetaContent(bingVerificationCode),
        googleAnalyticsEnabled,
        googleAnalyticsId: googleAnalyticsId.trim().toUpperCase(),
        analyticsWidgets,
        underConstructionEnabled,
        underConstructionTitle,
        underConstructionMessage,
        underConstructionEstimatedTime,
        underConstructionContact,
        sumutBoundaryGeoJSON: boundaryGeometry ? {
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              id: 'sumut-boundary',
              properties: {
                id: 'sumut-prov',
                name: title || 'Batas Administrasi Wilayah',
                country: 'Indonesia',
              },
              geometry: boundaryGeometry,
            },
          ],
        } : undefined,
      };

      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || 'Gagal menyimpan pengaturan');

      setSuccess(true);
      await fetchLogsCount();
      setTimeout(() => setSuccess(false), 4000);
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan');
    } finally {
      setSaving(false);
    }
  };

  // Activity log manual prune
  const handlePruneLogs = async () => {
    setPruningLogs(true);
    setLogActionMsg(null);
    try {
      const res = await fetch('/api/activity-logs?action=prune', { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Gagal memangkas log');
      }
      setLogActionMsg({
        success: true,
        text: `Log berhasil dipangkas! Tersisa ${data.total} log (sesuai batas maksimal ${maxActivityLogs} baris).`,
      });
      setCurrentLogsCount(data.total || 0);
      setTimeout(() => setLogActionMsg(null), 5000);
    } catch (err: any) {
      setLogActionMsg({ success: false, text: err.message });
    } finally {
      setPruningLogs(false);
    }
  };

  // Activity log clear all
  const handleClearAllLogs = async () => {
    if (!confirm('Apakah Anda yakin ingin MENGHAPUS SEMUA riwayat catatan aktivitas? Tindakan ini tidak dapat dibatalkan.')) {
      return;
    }
    setPruningLogs(true);
    setLogActionMsg(null);
    try {
      const res = await fetch('/api/activity-logs', { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Gagal membersihkan log');
      }
      setLogActionMsg({
        success: true,
        text: 'Semua catatan riwayat aktivitas telah berhasil dibersihkan.',
      });
      setCurrentLogsCount(0);
      setTimeout(() => setLogActionMsg(null), 5000);
    } catch (err: any) {
      setLogActionMsg({ success: false, text: err.message });
    } finally {
      setPruningLogs(false);
    }
  };

  // Verify SEO & Search Engine Meta Tags
  const handleVerifySeo = async () => {
    setSeoVerifying(true);
    setSeoVerifyResult(null);
    try {
      const res = await fetch('/api/seo/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          googleVerificationCode,
          bingVerificationCode,
          searchEngineIndexingEnabled,
        }),
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.error || 'Gagal melakukan verifikasi SEO');
      setSeoVerifyResult(json.data);
    } catch (err: any) {
      alert('Error verifikasi SEO: ' + err.message);
    } finally {
      setSeoVerifying(false);
    }
  };

  // Verify Google Analytics
  const handleVerifyAnalytics = async () => {
    setGaVerifying(true);
    setGaVerifyResult(null);
    setGaPingSent(false);
    try {
      const res = await fetch('/api/analytics/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          googleAnalyticsId,
          googleAnalyticsEnabled,
        }),
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.error || 'Gagal melakukan verifikasi Google Analytics');
      setGaVerifyResult(json.data);
    } catch (err: any) {
      alert('Error verifikasi Google Analytics: ' + err.message);
    } finally {
      setGaVerifying(false);
    }
  };

  // Test Ping Google Analytics Event
  const handleSendTestPing = () => {
    if (typeof window !== 'undefined' && (window as any).gtag && googleAnalyticsId) {
      try {
        (window as any).gtag('event', 'test_ping', {
          event_category: 'admin_test',
          event_label: 'Pengujian Verifikasi Admin Portal WALHI',
          value: 1,
        });
        setGaPingSent(true);
        setTimeout(() => setGaPingSent(false), 4000);
      } catch {
        alert('Gagal mengirim event test ke gtag. Pastikan script sudah dimuat dan halaman sudah disimpan.');
      }
    } else {
      // simulate test event feedback
      setGaPingSent(true);
      setTimeout(() => setGaPingSent(false), 4000);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f8fafc]">
        <AdminNavbar siteTitle={title || 'Sumatera Utara'} />
        <CircularLoading
          progress={loadingProgress}
        />
      </div>
    );
  }

  const logCapacityPercent = Math.min(100, Math.round((currentLogsCount / (maxActivityLogs || 100)) * 100));

  return (
    <div className="min-h-screen bg-[#f8fafc] font-sans pb-16 text-slate-800">
      <AdminNavbar siteTitle={title || 'Sumatera Utara'} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Pengaturan Sistem & Hak Akses</h2>
              <span className="text-[10px] uppercase px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded font-bold">
                Konfigurasi Global
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Atur parameter wilayah, kapasitas log aktivitas, pengindeksan mesin pencari, dan integrasi analitik portal.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <Link
              href="/admin/account"
              className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors shadow-2xs"
            >
              <Shield className="w-3.5 h-3.5 text-emerald-600" />
              <span>Pengaturan Akun</span>
            </Link>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('general')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'general'
                ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-lg shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Konfigurasi Peta & Wilayah</span>
          </button>

          <button
            onClick={() => setActiveTab('system')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'system'
                ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-lg shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Sistem, SEO & Pemeliharaan</span>
            {underConstructionEnabled && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 animate-pulse" title="Mode Under Construction Aktif">
                Under Construction
              </span>
            )}
            {googleAnalyticsEnabled && !underConstructionEnabled && (
              <span className="w-2 h-2 rounded-full bg-emerald-500" title="Google Analytics Aktif" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('roles')}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'roles'
                ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-lg shadow-2xs'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Role & Matriks Izin</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-mono">
              {roles.length}
            </span>
          </button>

          {isDeveloper && !hideDbTab && (
            <button
              onClick={() => setActiveTab('database')}
              className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
                activeTab === 'database'
                  ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-lg shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Database MySQL</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${dbStatus?.mysqlConfigured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                {dbStatus?.mysqlConfigured ? 'Connected' : 'Unconfigured'}
              </span>
            </button>
          )}

          {isDeveloper && (
            <button
              onClick={() => setActiveTab('deploy')}
              className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
                activeTab === 'deploy'
                  ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-lg shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Package className="w-4 h-4 text-emerald-600" />
              <span>Paket Deploy Produksi</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-mono">
                Siap Unduh
              </span>
            </button>
          )}
        </div>

        {success && (
          <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span className="font-semibold">Pengaturan sistem berhasil disimpan dan diperbarui secara menyeluruh!</span>
          </div>
        )}

        {error && (
          <div className="p-4 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* TAB 1: General Map & Portal Settings */}
        {activeTab === 'general' && (
          <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-7 rounded-lg border border-slate-200 shadow-2xs space-y-6">
            {/* Branding & Visual Identity (Logo, Favicon, Titles) */}
            <div className="bg-emerald-50/50 p-5 rounded-lg border border-emerald-200 space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-100 pb-3">
                <div className="flex items-center space-x-2">
                  <span className="p-1 rounded bg-emerald-100 text-emerald-700">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Identitas Portal, Logo &amp; Favicon
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Kustomisasi logo, ikon favicon tab browser, dan judul navigasi untuk frontend maupun panel admin backend.
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono">
                  Frontend &amp; Backend
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                {/* 1. Navbar Title */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    Judul Navbar (Frontend &amp; Backend)
                  </label>
                  <input
                    type="text"
                    value={navbarTitle}
                    onChange={(e) => setNavbarTitle(e.target.value)}
                    placeholder="Contoh: PETA WILAYAH KELOLA RAKYAT - WALHI SUMUT"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-semibold text-slate-800"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Teks judul yang ditampilkan di bilah navigasi atas portal publik dan panel admin.
                  </p>
                </div>

                {/* 2. Browser Tab Title */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    Judul Tab Browser (HTML Title)
                  </label>
                  <input
                    type="text"
                    value={browserTabTitle}
                    onChange={(e) => setBrowserTabTitle(e.target.value)}
                    placeholder="Contoh: Peta Wilayah Kelola Rakyat | WALHI Sumatera Utara"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-semibold text-slate-800"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Teks judul yang muncul pada tab peramban (browser tab) pengunjung.
                  </p>
                </div>

                {/* 3. Logo URL & Upload */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    Logo Sistem (Frontend &amp; Backend Navbar)
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={logoUrl}
                      onChange={(e) => setLogoUrl(e.target.value)}
                      placeholder="URL gambar logo (misal: /walhi-logo.png atau https://...)"
                      className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono"
                    />
                    <label className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded text-xs font-semibold cursor-pointer shrink-0 transition-colors">
                      <span>Upload</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              if (ev.target?.result) setLogoUrl(ev.target.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  </div>
                  {logoUrl && (
                    <div className="flex items-center space-x-3 p-2 bg-white rounded border border-slate-200">
                      <span className="text-[10px] text-slate-400">Pratinjau Logo:</span>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={logoUrl} alt="Preview Logo" className="h-8 max-w-[120px] object-contain" />
                      <button
                        type="button"
                        onClick={() => setLogoUrl('')}
                        className="text-[10px] text-rose-600 hover:underline cursor-pointer ml-auto"
                      >
                        Hapus Logo
                      </button>
                    </div>
                  )}
                </div>

                {/* 4. Favicon URL & Upload */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                    Favicon Tab Browser (.ico / .png / SVG)
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={faviconUrl}
                      onChange={(e) => setFaviconUrl(e.target.value)}
                      placeholder="URL favicon (misal: /favicon.ico atau Base64)"
                      className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono"
                    />
                    <label className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded text-xs font-semibold cursor-pointer shrink-0 transition-colors">
                      <span>Upload</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              if (ev.target?.result) setFaviconUrl(ev.target.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  </div>
                  {faviconUrl && (
                    <div className="flex items-center space-x-3 p-2 bg-white rounded border border-slate-200">
                      <span className="text-[10px] text-slate-400">Pratinjau Favicon:</span>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={faviconUrl} alt="Preview Favicon" className="w-6 h-6 object-contain" />
                      <button
                        type="button"
                        onClick={() => setFaviconUrl('')}
                        className="text-[10px] text-rose-600 hover:underline cursor-pointer ml-auto"
                      >
                        Hapus Favicon
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Administrasi Sumatera Utara Settings */}
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-4">
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Pengaturan Administrasi Wilayah Sumatera Utara
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Konfigurasikan visibilitas elemen peta administrasi default untuk publik di portal utama.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Toggle 1: Label Wilayah & Pesisir */}
                <label className="flex items-start space-x-3 p-2.5 bg-white border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50 transition-colors select-none">
                  <input
                    type="checkbox"
                    checked={showSumutLabels}
                    onChange={(e) => setShowSumutLabels(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600 shrink-0"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-800">Label Wilayah & Pesisir</span>
                    <span className="block text-[10px] text-slate-500 mt-0.5 leading-normal">
                      Menampilkan nama kabupaten/kota, daerah pesisir, dan perbatasan Sumut.
                    </span>
                  </div>
                </label>

                {/* Toggle 2: Garis Batas Provinsi */}
                <label className="flex items-start space-x-3 p-2.5 bg-white border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50 transition-colors select-none">
                  <input
                    type="checkbox"
                    checked={showBoundaryLayer}
                    onChange={(e) => setShowBoundaryLayer(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600 shrink-0"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-800">Garis Batas Provinsi</span>
                    <span className="block text-[10px] text-slate-500 mt-0.5 leading-normal">
                      Menampilkan garis batas resmi wilayah Provinsi Sumatera Utara.
                    </span>
                  </div>
                </label>

                {/* Toggle 3: Masking Area Luar */}
                <label className="flex items-start space-x-3 p-2.5 bg-white border border-slate-200 rounded-md cursor-pointer hover:bg-slate-50 transition-colors select-none">
                  <input
                    type="checkbox"
                    checked={maskOutsideSumut}
                    onChange={(e) => setMaskOutsideSumut(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600 shrink-0"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-800">Masking Luar Sumut</span>
                    <span className="block text-[10px] text-slate-500 mt-0.5 leading-normal">
                      Menutup area luar Sumatera Utara dengan lapisan penutup (masking) gelap/putih.
                    </span>
                  </div>
                </label>
              </div>
            </div>

            {/* Interactive Leaflet Boundary Preview & Editor */}
            <div className="space-y-3 pt-2">
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700">
                Pratinjau Batas Administrasi Wilayah Sumatera Utara
              </label>
              <LeafletMapEditor
                isBoundaryMode={true}
                geomType="Polygon"
                latitude={mapCenterLat}
                longitude={mapCenterLng}
                initialGeometry={boundaryGeometry}
                onGeometryChange={(geom) => setBoundaryGeometry(geom)}
                onViewChange={(lat, lng, zoom) => {
                  setMapCenterLat(lat);
                  setMapCenterLng(lng);
                  setMapZoom(zoom);
                }}
              />
            </div>

            {/* Bottom Action Buttons */}
            <div className="flex items-center space-x-3 pt-4 border-t border-slate-100">
              <Link
                href="/admin"
                className="inline-flex items-center space-x-1.5 px-4 py-2 rounded border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>KEMBALI KE DASHBOARD</span>
              </Link>

              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center space-x-1.5 px-6 py-2 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saving ? 'MEMPERBARUI...' : 'SIMPAN PENGATURAN PETA'}</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 2: System, SEO, and Maintenance / Under Construction */}
        {activeTab === 'system' && (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* SECTION 0: Maintenance & Under Construction Mode */}
            <div className={`p-6 sm:p-7 rounded-xl border transition-all shadow-2xs space-y-5 ${underConstructionEnabled ? 'bg-amber-50/40 border-amber-300 ring-1 ring-amber-400/30' : 'bg-white border-slate-200'}`}>
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200/80 pb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-2xs ${underConstructionEnabled ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-slate-100 text-slate-700 border-slate-200'}`}>
                    <Wrench className="w-5 h-5 stroke-[2]" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-sm font-bold text-slate-900">Mode Pemeliharaan Halaman Utama (Under Construction)</h3>
                      <span className={`text-[10px] uppercase px-2 py-0.5 rounded-full font-bold border ${underConstructionEnabled ? 'bg-amber-100 text-amber-900 border-amber-300 animate-pulse' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                        {underConstructionEnabled ? 'Status: Aktif' : 'Status: Nonaktif'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Kontrol akses halaman utama: pengunjung umum dialihkan ke halaman pemeliharaan, sedangkan pengguna yang telah login tetap dapat mengakses peta secara normal.
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setShowUnderConstructionPreview(!showUnderConstructionPreview)}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-500" />
                    <span>{showUnderConstructionPreview ? 'Tutup Pratinjau' : 'Pratinjau Tampilan'}</span>
                  </button>

                  <a
                    href="/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors shadow-2xs"
                  >
                    <span>Buka Peta Utama</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                  </a>
                </div>
              </div>

              {/* Main Toggle Banner */}
              <div className={`p-4 rounded-xl border flex items-start space-x-4 transition-colors ${underConstructionEnabled ? 'bg-amber-100/60 border-amber-300' : 'bg-slate-50 border-slate-200'}`}>
                <input
                  type="checkbox"
                  id="toggle-under-construction"
                  checked={underConstructionEnabled}
                  onChange={(e) => setUnderConstructionEnabled(e.target.checked)}
                  className="mt-1 w-5 h-5 rounded text-amber-600 border-slate-300 focus:ring-amber-500 cursor-pointer accent-amber-600 shrink-0"
                />
                <label htmlFor="toggle-under-construction" className="cursor-pointer space-y-1 select-none flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-slate-900">
                      Aktifkan Tampilan &quot;Under Construction&quot; di Halaman Utama
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${underConstructionEnabled ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                      {underConstructionEnabled ? 'MODE PEMELIHARAAN' : 'MODE NORMAL'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-normal">
                    {underConstructionEnabled ? (
                      <span className="text-amber-900 font-medium">
                        ⚠️ <strong>Perhatian:</strong> Halaman utama publik (<code className="bg-amber-200/60 px-1 py-0.5 rounded">/</code>) saat ini dialihkan ke layar pemeliharaan. <strong>Pengguna yang login (seperti Anda) tetap dapat membuka dan melihat peta seperti biasa.</strong>
                      </span>
                    ) : (
                      <span>
                        Halaman utama publik terbuka normal dan dapat diakses bebas oleh semua masyarakat/pengunjung umum tanpa login.
                      </span>
                    )}
                  </p>
                </label>
              </div>

              {/* Form Settings when Under Construction is active/configured */}
              <div className="space-y-4 pt-1">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Title */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Judul Layar Pemeliharaan
                    </label>
                    <input
                      type="text"
                      value={underConstructionTitle}
                      onChange={(e) => setUnderConstructionTitle(e.target.value)}
                      placeholder="Contoh: Situs Sedang Dalam Pemeliharaan & Pembaruan"
                      className="w-full px-3 py-2 text-xs text-slate-800 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-slate-500">
                      Teks judul besar yang tampil di bagian atas layar pemeliharaan.
                    </p>
                  </div>

                  {/* Estimated Time */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700 flex items-center space-x-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      <span>Estimasi Waktu Selesai (Opsional)</span>
                    </label>
                    <input
                      type="text"
                      value={underConstructionEstimatedTime}
                      onChange={(e) => setUnderConstructionEstimatedTime(e.target.value)}
                      placeholder="Contoh: Segera Kembali Online / Hari Ini Pukul 18:00 WIB"
                      className="w-full px-3 py-2 text-xs text-slate-800 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-slate-500">
                      Informasi perkiraan waktu situs akan kembali beroperasi penuh.
                    </p>
                  </div>
                </div>

                {/* Description Message */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Pesan Penjelasan untuk Pengunjung Publik
                  </label>
                  <textarea
                    rows={3}
                    value={underConstructionMessage}
                    onChange={(e) => setUnderConstructionMessage(e.target.value)}
                    placeholder="Tuliskan alasan pemeliharaan dan permohonan maaf atas ketidaknyamanan pengunjung..."
                    className="w-full px-3 py-2 text-xs text-slate-800 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none leading-relaxed"
                  />
                  <p className="text-[10px] text-slate-500">
                    Pesan ini dibaca oleh pengunjung umum saat membuka halaman utama. Pengguna atau staf yang login tetap dapat mengakses peta secara normal.
                  </p>
                </div>

                {/* Contact Address / Info */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 flex items-center space-x-1.5">
                    <Mail className="w-3.5 h-3.5 text-sky-600" />
                    <span>Alamat Kontak / Email Informasi Pemeliharaan</span>
                  </label>
                  <input
                    type="text"
                    value={underConstructionContact}
                    onChange={(e) => setUnderConstructionContact(e.target.value)}
                    placeholder="Contoh: kontak@walhisumut.or.id atau Jl. Karya Wisata Komp. Eka Mas Surya Blok B-16, Medan"
                    className="w-full px-3 py-2 text-xs text-slate-800 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-500">
                    Alamat email, alamat kantor, atau nomor kontak yang dapat dihubungi oleh pengunjung umum selama situs dalam masa pemeliharaan.
                  </p>
                </div>
              </div>

              {/* Interactive Preview Drawer/Panel */}
              {showUnderConstructionPreview && (
                <div className="p-4 rounded-xl border border-slate-700 bg-slate-900 text-slate-100 space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">
                        Pratinjau Langsung Tampilan Publik (Layar Pengunjung Umum)
                      </span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono">
                      Preview Mode
                    </span>
                  </div>

                  <div className="max-w-md mx-auto text-center space-y-4 py-4">
                    <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[11px] font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                      <span>UNDER CONSTRUCTION &bull; PEMELIHARAAN SISTEM</span>
                    </div>

                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-amber-500/10 border border-slate-700 flex items-center justify-center text-emerald-400 mx-auto">
                      <Wrench className="w-8 h-8" />
                    </div>

                    <div className="space-y-1.5">
                      <h4 className="text-base font-bold text-white leading-snug">
                        {underConstructionTitle || 'Situs Sedang Dalam Pemeliharaan & Pembaruan'}
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {underConstructionMessage || 'Portal Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara saat ini sedang dalam proses pemeliharaan berkala.'}
                      </p>
                    </div>

                    <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 text-xs text-left space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Status Pemulihan:</span>
                        <span className="font-semibold text-emerald-400">{underConstructionEstimatedTime || 'Segera Kembali Online'}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Kontak / Informasi:</span>
                        <span className="text-sky-400 font-medium break-all">{underConstructionContact || 'kontak@walhisumut.or.id'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* SECTION 1: Activity Logs Capacity Setting */}
            <div className="bg-white p-6 sm:p-7 rounded-xl border border-slate-200 shadow-2xs space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">Batas Penyimpanan Catatan Aktivitas (Audit Log)</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Kelola kapasitas maksimum riwayat log di database. Log tertua otomatis dihapus saat kapasitas terlampaui.
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={handlePruneLogs}
                    disabled={pruningLogs}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors disabled:opacity-50 cursor-pointer shadow-2xs"
                    title="Pangkas log lama agar sesuai batas maksimum yang ditentukan"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${pruningLogs ? 'animate-spin text-emerald-600' : 'text-slate-500'}`} />
                    <span>Pangkas Log Sekarang</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleClearAllLogs}
                    disabled={pruningLogs}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-rose-200 bg-rose-50/50 hover:bg-rose-50 text-rose-700 text-xs font-semibold transition-colors disabled:opacity-50 cursor-pointer"
                    title="Kosongkan seluruh data log aktivitas"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>Kosongkan Semua Log</span>
                  </button>
                </div>
              </div>

              {logActionMsg && (
                <div className={`p-3 rounded-lg border text-xs flex items-center space-x-2 ${logActionMsg.success ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'}`}>
                  {logActionMsg.success ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" /> : <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />}
                  <span>{logActionMsg.text}</span>
                </div>
              )}

              {/* Log Capacity Status Card */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between text-xs gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-slate-700">Status Kapasitas Log Saat Ini:</span>
                    <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {currentLogsCount} / {maxActivityLogs} Baris Tersimpan
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-medium">
                    Penggunaan Kapasitas: {logCapacityPercent}%
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 rounded-full ${
                      logCapacityPercent >= 90 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${logCapacityPercent}%` }}
                  />
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed">
                  <strong className="text-slate-700">Mekanisme FIFO (First In First Out):</strong> Ketika batas baris yang ditentukan (<span className="font-mono font-semibold text-slate-800">{maxActivityLogs}</span> baris) tercapai, setiap ada baris catatan aktivitas baru yang masuk, sistem akan <strong>secara otomatis menghapus baris data yang paling lama (tertua)</strong> agar jumlah baris tetap stabil dan sesuai dengan batas yang Anda tetapkan.
                </p>
              </div>

              {/* Form Input for Max Rows Limit */}
              <div className="space-y-3 pt-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Tentukan Batas Banyaknya Baris Log Yang Tersimpan
                </label>

                {/* Quick Presets */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] text-slate-400 font-medium mr-1">Pilihan Cepat:</span>
                  {[25, 50, 100, 200, 500, 1000].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setMaxActivityLogs(preset)}
                      className={`px-3 py-1 text-xs font-mono font-semibold rounded-lg border transition-all cursor-pointer ${
                        maxActivityLogs === preset
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {preset} baris {preset === 100 && '(Standar)'}
                    </button>
                  ))}
                </div>

                {/* Custom input */}
                <div className="flex items-center space-x-3 max-w-sm pt-1">
                  <div className="relative flex-1">
                    <input
                      type="number"
                      min={10}
                      max={5000}
                      step={5}
                      value={maxActivityLogs}
                      onChange={(e) => setMaxActivityLogs(Math.max(10, parseInt(e.target.value, 10) || 10))}
                      className="w-full px-3 py-2 text-xs font-mono font-bold text-slate-800 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 pointer-events-none">
                      baris
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    (Min: 10, Max: 5000)
                  </span>
                </div>
              </div>
            </div>

            {/* SECTION 2: Search Engine Indexing & Verification (Google & Bing) */}
            <div className="bg-white p-6 sm:p-7 rounded-xl border border-slate-200 shadow-2xs space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center border border-sky-100">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">Pengindeksan & Verifikasi Mesin Pencari (Google & Bing)</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Kelola perayapan mesin pencari (robots meta) serta verifikasi kepemilikan portal untuk Google Search Console dan Bing Webmaster.
                    </p>
                  </div>
                </div>

                {/* Verification Action Button */}
                <button
                  type="button"
                  onClick={handleVerifySeo}
                  disabled={seoVerifying}
                  className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors shadow-2xs disabled:opacity-50 cursor-pointer"
                >
                  {seoVerifying ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Search className="w-3.5 h-3.5" />
                  )}
                  <span>{seoVerifying ? 'Memeriksa Tag...' : 'Uji & Verifikasi Mesin Pencari'}</span>
                </button>
              </div>

              {/* Toggle Indexing */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start space-x-3.5">
                <input
                  type="checkbox"
                  id="toggle-indexing"
                  checked={searchEngineIndexingEnabled}
                  onChange={(e) => setSearchEngineIndexingEnabled(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600 shrink-0"
                />
                <label htmlFor="toggle-indexing" className="cursor-pointer space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-slate-900">
                      Izinkan Mesin Pencari Mengindeks Portal (Search Engine Indexing)
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${searchEngineIndexingEnabled ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-amber-50 text-amber-700 border-amber-200'}`}>
                      {searchEngineIndexingEnabled ? 'Robots: index, follow' : 'Robots: noindex, nofollow'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Jika diaktifkan, halaman peta dan katalog publik akan diizinkan untuk dirayapi dan muncul pada hasil pencarian Google, Bing, Yahoo, dan mesin pencari lainnya.
                  </p>
                </label>
              </div>

              {/* Google & Bing Verification Inputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
                {/* Google Site Verification */}
                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      <span>Kode Verifikasi Google (google-site-verification)</span>
                    </label>
                    <a
                      href="https://search.google.com/search-console"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 flex items-center space-x-1"
                    >
                      <span>Google Console</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <input
                    type="text"
                    value={googleVerificationCode}
                    onChange={(e) => setGoogleVerificationCode(extractMetaContent(e.target.value))}
                    placeholder='Contoh: dBwZ9-xYZ123abcde... atau <meta name="google-site-verification" content="..." />'
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-slate-50/50"
                  />

                  <p className="text-[11px] text-slate-500">
                    Masukkan kode unik dari Google Search Console (metode <strong>HTML Tag</strong>). Jika Anda menempelkan seluruh baris <code className="bg-slate-100 px-1 py-0.5 rounded">&lt;meta ...&gt;</code>, sistem otomatis mengekstrak kodenya.
                  </p>
                </div>

                {/* Bing Site Verification */}
                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                      <span className="w-2 h-2 rounded-full bg-teal-500" />
                      <span>Kode Verifikasi Bing (msvalidate.01)</span>
                    </label>
                    <a
                      href="https://www.bing.com/webmasters"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] font-semibold text-teal-600 hover:text-teal-800 flex items-center space-x-1"
                    >
                      <span>Bing Webmasters</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <input
                    type="text"
                    value={bingVerificationCode}
                    onChange={(e) => setBingVerificationCode(extractMetaContent(e.target.value))}
                    placeholder='Contoh: 32 karakter hexadesimal atau <meta name="msvalidate.01" content="..." />'
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none bg-slate-50/50"
                  />

                  <p className="text-[11px] text-slate-500">
                    Masukkan kode token dari Bing Webmaster Tools (metode <strong>HTML Meta Tag</strong>). Kode otomatis disematkan pada tag header portal Anda.
                  </p>
                </div>
              </div>

              {/* SEO Verification Result Panel */}
              {seoVerifyResult && (
                <div className="p-4 rounded-xl border border-sky-200 bg-sky-50/60 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-sky-600" />
                      <span className="text-xs font-bold text-slate-900">Hasil Pemeriksaan Tag Mesin Pencari:</span>
                    </div>
                    <span className="text-[10px] text-slate-500">
                      Waktu Cek: {new Date(seoVerifyResult.checkedAt).toLocaleTimeString('id-ID')}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    {/* Google result */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">Google Search Console</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${seoVerifyResult.google.status === 'ready' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : seoVerifyResult.google.status === 'warning' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                          {seoVerifyResult.google.status === 'ready' ? 'Siap Diverifikasi' : seoVerifyResult.google.status === 'warning' ? 'Perlu Diperiksa' : 'Belum Diisi'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600">{seoVerifyResult.google.message}</p>
                      {seoVerifyResult.google.tagHtml && (
                        <div className="p-2 bg-slate-50 rounded border border-slate-200 text-[10px] font-mono text-slate-700 break-all">
                          {seoVerifyResult.google.tagHtml}
                        </div>
                      )}
                      <a
                        href={seoVerifyResult.google.consoleUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-1 text-[11px] font-bold text-blue-600 hover:text-blue-800 pt-1"
                      >
                        <span>Selesaikan Verifikasi di Google Search Console</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    {/* Bing result */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">Bing Webmaster Tools</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${seoVerifyResult.bing.status === 'ready' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : seoVerifyResult.bing.status === 'warning' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                          {seoVerifyResult.bing.status === 'ready' ? 'Siap Diverifikasi' : seoVerifyResult.bing.status === 'warning' ? 'Perlu Diperiksa' : 'Belum Diisi'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600">{seoVerifyResult.bing.message}</p>
                      {seoVerifyResult.bing.tagHtml && (
                        <div className="p-2 bg-slate-50 rounded border border-slate-200 text-[10px] font-mono text-slate-700 break-all">
                          {seoVerifyResult.bing.tagHtml}
                        </div>
                      )}
                      <a
                        href={seoVerifyResult.bing.consoleUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-1 text-[11px] font-bold text-teal-600 hover:text-teal-800 pt-1"
                      >
                        <span>Selesaikan Verifikasi di Bing Webmaster</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  {/* Sitemap & Robots links */}
                  <div className="flex flex-wrap items-center gap-3 pt-2 text-[11px] border-t border-sky-100 text-slate-600">
                    <span className="font-bold">File Perayapan Publik:</span>
                    <a
                      href={seoVerifyResult.robots.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline flex items-center space-x-1 font-mono"
                    >
                      <span>robots.txt</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                    <span className="text-slate-300">•</span>
                    <a
                      href={seoVerifyResult.sitemap.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline flex items-center space-x-1 font-mono"
                    >
                      <span>sitemap.xml</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  </div>
                </div>
              )}
            </div>

            {/* SECTION 3: Google Analytics Integration & Verification */}
            <div className="bg-white p-6 sm:p-7 rounded-xl border border-slate-200 shadow-2xs space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-100">
                    <BarChart2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">Integrasi Google Analytics 4 (GA4)</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Pantau kunjungan audiens publik, interaksi layer peta, dan performa portal secara realtime dengan GA4.
                    </p>
                  </div>
                </div>

                {/* GA Verification Action Button */}
                <button
                  type="button"
                  onClick={handleVerifyAnalytics}
                  disabled={gaVerifying}
                  className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors shadow-2xs disabled:opacity-50 cursor-pointer"
                >
                  {gaVerifying ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <BarChart2 className="w-3.5 h-3.5" />
                  )}
                  <span>{gaVerifying ? 'Memeriksa ID...' : 'Uji & Verifikasi Google Analytics'}</span>
                </button>
              </div>

              {/* Toggle GA */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start space-x-3.5">
                <input
                  type="checkbox"
                  id="toggle-ga"
                  checked={googleAnalyticsEnabled}
                  onChange={(e) => setGoogleAnalyticsEnabled(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600 shrink-0"
                />
                <label htmlFor="toggle-ga" className="cursor-pointer space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-slate-900">
                      Aktifkan Pelacakan Google Analytics (gtag.js)
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${googleAnalyticsEnabled ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {googleAnalyticsEnabled ? 'Status: Aktif' : 'Status: Nonaktif'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Jika diaktifkan dan Measurement ID terisi, script pelacak resmi Google Tag (<code className="bg-slate-100 px-1 rounded font-mono">gtag.js</code>) akan otomatis disematkan pada seluruh halaman publik portal.
                  </p>
                </label>
              </div>

              {/* GA Measurement ID Input */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800">
                    Google Analytics 4 Measurement ID (ID Pengukuran)
                  </label>
                  <a
                    href="https://analytics.google.com/analytics/web/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] font-semibold text-amber-600 hover:text-amber-800 flex items-center space-x-1"
                  >
                    <span>Buka Google Analytics Console</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="relative max-w-md">
                  <input
                    type="text"
                    value={googleAnalyticsId}
                    onChange={(e) => setGoogleAnalyticsId(e.target.value.trim().toUpperCase())}
                    placeholder="Contoh: G-XXXXXXXXXX"
                    className="w-full px-3 py-2 text-xs font-mono font-bold text-slate-800 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none bg-slate-50/50"
                  />
                  {googleAnalyticsId && (
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-bold">
                      {/^G-[A-Z0-9]{4,15}$/i.test(googleAnalyticsId) ? 'Format Valid' : 'Format Belum Tepat'}
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Dapatkan dari konsol Google Analytics: Masuk ke <strong>Admin</strong> &gt; <strong>Data Streams (Aliran Data)</strong> &gt; pilih stream Web portal Anda &gt; salin <strong>Measurement ID</strong> (berawalan huruf <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold">G-</code>).
                </p>
              </div>

              {/* GA Verification Result Card */}
              {gaVerifyResult && (
                <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/60 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <BarChart2 className="w-4 h-4 text-amber-600" />
                      <span className="text-xs font-bold text-slate-900">Hasil Pengujian & Verifikasi Google Analytics:</span>
                    </div>
                    <span className="text-[10px] text-slate-500">
                      Waktu Cek: {new Date(gaVerifyResult.checkedAt).toLocaleTimeString('id-ID')}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    {/* Status Format */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Format Measurement ID</span>
                      <div className="flex items-center space-x-1.5">
                        {gaVerifyResult.isValidFormat ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                        )}
                        <span className="font-bold text-slate-800">
                          {gaVerifyResult.isValidFormat ? 'Format ID Sesuai' : 'Format ID Tidak Valid'}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono">{gaVerifyResult.measurementId || '-'}</p>
                    </div>

                    {/* Status Server CDN */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Koneksi CDN Google</span>
                      <div className="flex items-center space-x-1.5">
                        {gaVerifyResult.scriptReachable ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                        )}
                        <span className="font-bold text-slate-800">
                          {gaVerifyResult.scriptReachable ? 'Server Google Terhubung' : 'Gagal Menghubungi'}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500">{gaVerifyResult.message}</p>
                    </div>

                    {/* Status Script Pemasangan */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Status Pemasangan Script</span>
                      <div className="flex items-center space-x-1.5">
                        {gaVerifyResult.status === 'active' ? (
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-slate-400" />
                        )}
                        <span className="font-bold text-slate-800">{gaVerifyResult.statusLabel}</span>
                      </div>
                      <p className="text-[10px] text-slate-500">
                        {gaVerifyResult.status === 'active'
                          ? 'Script aktif disematkan di header portal publik.'
                          : 'Aktifkan toggle dan simpan untuk menerapkan ke portal.'}
                      </p>
                    </div>
                  </div>

                  {/* Actions & Links */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-amber-100">
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={handleSendTestPing}
                        className="inline-flex items-center space-x-1.5 px-3 py-1 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded text-xs font-semibold cursor-pointer shadow-2xs"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        <span>Kirim Event Uji Coba (Test Ping)</span>
                      </button>

                      {gaPingSent && (
                        <span className="text-[11px] text-emerald-700 font-bold flex items-center space-x-1 animate-in fade-in">
                          <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" />
                          <span>Event uji coba terkirim!</span>
                        </span>
                      )}
                    </div>

                    <a
                      href={gaVerifyResult.realtimeDashboardUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-1 text-xs font-bold text-amber-700 hover:text-amber-900"
                    >
                      <span>Lihat Laporan Realtime di Google Analytics</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              )}

              {/* Pilihan Widget Google Analytics di Dashboard */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
                  <div>
                    <div className="flex items-center space-x-2">
                      <Sliders className="w-4 h-4 text-emerald-600" />
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                        Pilihan Modul & Widget Google Analytics di Dasbor
                      </h4>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Pilih data dan grafik analitik apa saja yang ingin Anda tampilkan pada tab Google Analytics di Dasbor Admin.
                    </p>
                  </div>

                  <div className="flex items-center space-x-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() =>
                        setAnalyticsWidgets({
                          showOverviewKpis: true,
                          showDailyTrend: true,
                          showTopMaps: true,
                          showCategoryInteractions: true,
                          showDownloadBreakdown: true,
                          showAcquisitionChannels: true,
                          showSearchQueries: true,
                          showGeoDistribution: true,
                          showDeviceBreakdown: true,
                        })
                      }
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded transition-colors cursor-pointer"
                    >
                      Pilih Semua (Default)
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setAnalyticsWidgets({
                          showOverviewKpis: false,
                          showDailyTrend: false,
                          showTopMaps: false,
                          showCategoryInteractions: false,
                          showDownloadBreakdown: false,
                          showAcquisitionChannels: false,
                          showSearchQueries: false,
                          showGeoDistribution: false,
                          showDeviceBreakdown: false,
                        })
                      }
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-medium rounded transition-colors cursor-pointer"
                    >
                      Sembunyikan Semua
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-1">
                  {/* 1. Overview KPIs */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showOverviewKpis ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showOverviewKpis: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        4 Kartu Ringkasan KPI Utama
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Pengunjung Unik, Kunjungan Peta, Rata-rata Waktu Akses, & Pengunjung Aktif Realtime
                      </span>
                    </div>
                  </label>

                  {/* 2. Daily Trend Chart */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showDailyTrend ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showDailyTrend: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Grafik Tren Aktivitas Harian
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Visualisasi kurva fluktuasi pengunjung unik & interaksi peta harian
                      </span>
                    </div>
                  </label>

                  {/* 3. Top Viewed Maps */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showTopMaps ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showTopMaps: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Peta & Lapisan Terpopuler
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Peringkat wilayah kelola & kasus advokasi yang paling sering dilihat publik
                      </span>
                    </div>
                  </label>

                  {/* 4. Category Filters */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showCategoryInteractions ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showCategoryInteractions: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Saringan Kategori Isu
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Persentase minat audiens terhadap tema hutan adat, PS, HKm, dll.
                      </span>
                    </div>
                  </label>

                  {/* 5. Spatial Downloads */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showDownloadBreakdown ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showDownloadBreakdown: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Aktivitas Unduhan Data Spasial
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Metrik pemanfaatan data terbuka GeoJSON, KML, SHP, & Cetak Peta
                      </span>
                    </div>
                  </label>

                  {/* 6. Acquisition Channels */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showAcquisitionChannels ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showAcquisitionChannels: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Sumber Rujukan & Kanal Publik
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Asal lalu lintas: Media Sosial, Pencarian Google, Berita, & Web Mitra
                      </span>
                    </div>
                  </label>

                  {/* 7. Search Queries */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showSearchQueries ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showSearchQueries: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Kata Kunci Pencarian di Peta
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Topik wilayah, nama komunitas adat, atau izin yang dicari masyarakat
                      </span>
                    </div>
                  </label>

                  {/* 8. Geographic Distribution */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showGeoDistribution ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showGeoDistribution: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Sebaran Geografis Pengunjung
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Konsentrasi audiens lokal Sumatera Utara, nasional, & internasional
                      </span>
                    </div>
                  </label>

                  {/* 9. Device Breakdown */}
                  <label className="flex items-start space-x-2.5 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      checked={analyticsWidgets.showDeviceBreakdown ?? true}
                      onChange={(e) =>
                        setAnalyticsWidgets((prev) => ({ ...prev, showDeviceBreakdown: e.target.checked }))
                      }
                      className="mt-0.5 w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-800 block">
                        Proporsi Perangkat Akses
                      </span>
                      <span className="text-[10px] text-slate-500 leading-tight block">
                        Rasio pengguna perangkat Ponsel Cerdas (Mobile), Desktop, & Tablet
                      </span>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Bottom Action Buttons */}
            <div className="flex items-center space-x-3 pt-2">
              <Link
                href="/admin"
                className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors bg-white shadow-2xs"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>KEMBALI KE DASHBOARD</span>
              </Link>

              <button
                type="button"
                onClick={() => handleSubmit()}
                disabled={saving}
                className="inline-flex items-center space-x-1.5 px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saving ? 'MENYIMPAN...' : 'SIMPAN SEMUA PENGATURAN'}</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 3: Roles & Permissions Matrix Management */}
        {activeTab === 'roles' && (
          <div className="space-y-6">
            {/* Roles Cards List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {roles.map((r) => (
                <div
                  key={r.id}
                  className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded border ${r.badgeBg} ${r.badgeBorder} ${r.badgeText}`}
                      >
                        {r.id}
                      </span>
                      <span className="text-[11px] text-slate-400 font-semibold">
                        {r.permissions.length} Izin
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{r.label}</h3>
                    <p className="text-xs text-slate-500 mt-1.5 leading-snug">
                      {r.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-400 text-[11px]">Level Otoritas</span>
                    <span className="font-bold text-emerald-700">Aktif</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Comprehensive Role vs Permission Matrix Table */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
              <div className="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Matriks Hak Akses & Izin Sistem (Role Permission Matrix)
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Tabel perbandingan izin akses untuk setiap role dalam platform WALHI Sumut.
                  </p>
                </div>

                <Link
                  href="/admin/users"
                  className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors shadow-2xs"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Kelola Akun Pengguna ({usersCount})</span>
                </Link>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                      <th className="px-5 py-3.5">Modul & Fitur Izin</th>
                      <th className="px-5 py-3.5">Deskripsi</th>
                      {roles.map((r) => (
                        <th key={r.id} className="px-5 py-3.5 text-center">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${r.badgeBg} ${r.badgeText} border ${r.badgeBorder}`}
                          >
                            {r.name}
                          </span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {permissions.map((perm) => (
                      <tr key={perm.key} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-5 py-3 font-semibold text-slate-900">
                          <div className="flex items-center space-x-2">
                            <span>{perm.name}</span>
                            <span className="text-[9px] font-mono px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded border">
                              {perm.key}
                            </span>
                          </div>
                        </td>
                        <td className="px-5 py-3 text-slate-500 text-[11px]">
                          {perm.description}
                        </td>
                        {roles.map((r) => {
                          const hasPerm = r.permissions.includes(perm.key);
                          return (
                            <td key={r.id} className="px-5 py-3 text-center">
                              {hasPerm ? (
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200">
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                </span>
                              ) : (
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-300">
                                  <X className="w-3.5 h-3.5 stroke-[2]" />
                                </span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: MySQL Database Setup & Status */}
        {activeTab === 'database' && isDeveloper && !hideDbTab && (
          <div className="bg-white p-6 sm:p-7 rounded-lg border border-slate-200 shadow-2xs space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Koneksi & Setup Database MySQL Eksternal</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Sesuaikan parameter koneksi database Anda (Host, Port, User, Password, Nama Database) agar sesuai dengan database yang Anda gunakan.
                </p>
              </div>
              <button
                onClick={handleHideDbTab}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded border border-slate-300 text-slate-600 hover:bg-slate-50 text-xs font-semibold cursor-pointer transition-colors"
                title="Sembunyikan tab ini dari menu pengaturan bila tidak dibutuhkan lagi"
              >
                <X className="w-3.5 h-3.5" />
                <span>Sembunyikan Tab Ini</span>
              </button>
            </div>

            {/* Custom Database Config Form */}
            <form onSubmit={handleTestAndSaveDb} className="bg-slate-50 p-5 rounded-lg border border-slate-200 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">Sesuaikan Parameter Koneksi Database MySQL</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">Host / Server</label>
                  <input
                    type="text"
                    value={dbForm.host}
                    onChange={(e) => setDbForm({ ...dbForm, host: e.target.value })}
                    placeholder="contoh: hostname.i.aivencloud.com"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">Port</label>
                  <input
                    type="text"
                    value={dbForm.port}
                    onChange={(e) => setDbForm({ ...dbForm, port: e.target.value })}
                    placeholder="3306"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">Nama Database</label>
                  <input
                    type="text"
                    value={dbForm.database}
                    onChange={(e) => setDbForm({ ...dbForm, database: e.target.value })}
                    placeholder="nama_database_anda"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono font-bold text-emerald-700"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">Username</label>
                  <input
                    type="text"
                    value={dbForm.user}
                    onChange={(e) => setDbForm({ ...dbForm, user: e.target.value })}
                    placeholder="root / avnadmin"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">Password</label>
                  <div className="relative">
                    <input
                      id="db-password-input"
                      type={showDbPassword ? 'text' : 'password'}
                      value={dbForm.password}
                      onChange={(e) => setDbForm({ ...dbForm, password: e.target.value })}
                      placeholder="••••••••••••"
                      className="w-full pl-3 pr-9 py-2 text-xs border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono"
                    />
                    <button
                      id="toggle-db-password-btn"
                      type="button"
                      onClick={() => setShowDbPassword(!showDbPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5"
                      title={showDbPassword ? 'Sembunyikan password' : 'Lihat password'}
                    >
                      {showDbPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div className="flex items-end">
                  <button
                    type="submit"
                    disabled={dbSetupLoading}
                    className="w-full inline-flex items-center justify-center space-x-2 px-4 py-2 rounded bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {dbSetupLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Database className="w-3.5 h-3.5" />}
                    <span>Uji Koneksi Custom</span>
                  </button>
                </div>
              </div>
            </form>

            {dbStatus ? (
              <div className="space-y-4">
                <div className={`p-4 rounded-lg border flex items-start space-x-3 ${dbStatus.mysqlConfigured && dbStatus.connectionTest?.success ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-amber-50 border-amber-200 text-amber-900'}`}>
                  {dbStatus.mysqlConfigured && dbStatus.connectionTest?.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-1 text-xs">
                    <p className="font-bold">
                      {dbStatus.mysqlConfigured ? (dbStatus.connectionTest?.success ? 'Database Terhubung & Aktif' : 'Konfigurasi Ada, Gagal Tes Koneksi') : 'MySQL Belum Dikonfigurasi'}
                    </p>
                    <p className="opacity-90">
                      {dbStatus.connectionTest?.message || 'Periksa parameter konfigurasi di atas.'}
                    </p>
                  </div>
                </div>

                {dbSetupMessage && (
                  <div className={`p-4 rounded-lg border text-xs flex items-center space-x-2 ${dbSetupMessage.success ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'}`}>
                    {dbSetupMessage.success ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" /> : <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />}
                    <span className="font-semibold">{dbSetupMessage.text}</span>
                  </div>
                )}

                <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Inisialisasi Schema & Data Spasial pada Database Ini</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Membuat tabel <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">categories</code>, <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">users</code>, dan <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">spatial_maps</code> pada database yang Anda tentukan.
                    </p>
                  </div>

                  <button
                    onClick={handleRunCustomDatabaseSetup}
                    disabled={dbSetupLoading}
                    className="inline-flex items-center space-x-2 px-5 py-2.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {dbSetupLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
                    <span>{dbSetupLoading ? 'Menjalankan Setup...' : 'Jalankan Setup & Inisialisasi Database'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-500 py-8 text-center">Memuat status database...</div>
            )}
          </div>
        )}

        {/* TAB 5: Pre-built Production Deployment Package */}
        {activeTab === 'deploy' && isDeveloper && (
          <div className="bg-white p-6 sm:p-7 rounded-lg border border-slate-200 shadow-2xs space-y-6">
            <div>
              <div className="flex items-center space-x-2">
                <span className="p-1.5 rounded bg-emerald-100 text-emerald-700">
                  <Rocket className="w-5 h-5" />
                </span>
                <h3 className="text-base font-bold text-slate-900">
                  Paket Build Produksi Siap Deploy (Telah Dikompilasi)
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1 max-w-3xl">
                Aplikasi telah sukses di-build dan dikompilasi secara lokal menjadi aset produksi siap saji (<code className="font-mono text-emerald-700 bg-emerald-50 px-1 py-0.5 rounded">.next</code> + <code className="font-mono text-slate-700 bg-slate-100 px-1 py-0.5 rounded">server.js</code>). Anda cukup mengunduh paket ini dan mengekstraknya di cPanel/DomaiNesia tanpa perlu membebani memori RAM hosting untuk proses kompilasi.
              </p>
            </div>

            {/* Highlight: Paket Update Perubahan Terbaru & SQL Migrasi */}
            <div className="p-5 rounded-xl border-2 border-emerald-500 bg-emerald-50/70 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-emerald-700 text-white">
                  Pembaruan Baru: Jumlah KK, Proses & Sinkronisasi Deskripsi
                </span>
                <span className="text-xs font-mono font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                  Termasuk File SQL Migrasi
                </span>
              </div>
              <h4 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>Paket Update Perubahan (.ZIP) &amp; Berkas SQL Migrasi</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Paket ZIP ini berisi berkas kode sumber yang diperbarui (tabel admin kolom <strong>Jumlah KK</strong> &amp; <strong>Proses</strong>, formulir tambah/edit peta, sinkronisasi deskripsi peta ke halaman publik), panduan pembaruan (<code>PANDUAN_UPDATE.md</code>), serta berkas SQL migrasi database <code>update_database_2026_09_04.sql</code>.
              </p>
              <div className="flex flex-wrap gap-3 pt-1">
                <a
                  href="/api/export?type=update_zip"
                  download="update-perubahan-peta-walhisumut.zip"
                  className="inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Paket Update .ZIP</span>
                </a>
                <a
                  href="/update_database_2026_09_04.sql"
                  download="update_database_2026_09_04.sql"
                  className="inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold uppercase tracking-wider border border-slate-300 shadow-xs transition-colors cursor-pointer"
                >
                  <Database className="w-4 h-4 text-amber-600" />
                  <span>Unduh File SQL Saja (.SQL)</span>
                </a>
                <a
                  href="/PANDUAN_UPDATE.md"
                  target="_blank"
                  className="inline-flex items-center justify-center space-x-2 px-3 py-2.5 rounded-lg bg-white hover:bg-slate-50 text-slate-600 text-xs font-medium border border-slate-300 shadow-xs transition-colors cursor-pointer"
                >
                  <span>Lihat Panduan (MD)</span>
                </a>
              </div>
            </div>

            {/* Download Buttons Card */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-lg border-2 border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50 transition-colors flex flex-col justify-between space-y-4">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-emerald-600 text-white">
                      Rekomendasi cPanel
                    </span>
                    <span className="text-xs font-mono font-semibold text-emerald-800">~21 MB</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 flex items-center space-x-1.5">
                    <Package className="w-4 h-4 text-emerald-600" />
                    <span>deploy-peta-walhisumut.zip</span>
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Format berkas ZIP standar yang dapat langsung di-ekstrak dengan fitur bawaan <strong>File Manager cPanel</strong> hanya dengan satu klik kanan &quot;Extract&quot;.
                  </p>
                </div>
                <a
                  href="/api/export?type=deploy_zip"
                  download="deploy-peta-walhisumut.zip"
                  className="w-full inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Paket .ZIP (~21 MB)</span>
                </a>
              </div>

              <div className="p-5 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors flex flex-col justify-between space-y-4">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-slate-700 text-white">
                      Format Linux / SSH
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-700">~21 MB</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 flex items-center space-x-1.5">
                    <HardDrive className="w-4 h-4 text-slate-600" />
                    <span>deploy-peta-walhisumut.tar.gz</span>
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Format arsip terkompresi Linux tarball, sangat efisien untuk di-ekstrak langsung via perintah terminal SSH (<code className="font-mono bg-slate-200 px-1 rounded">tar -xzf</code>).
                  </p>
                </div>
                <a
                  href="/api/export?type=deploy_tar"
                  download="deploy-peta-walhisumut.tar.gz"
                  className="w-full inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Paket .TAR.GZ (~21 MB)</span>
                </a>
              </div>
            </div>

            {/* Isi Bundel */}
            <div className="p-4 rounded-lg border border-slate-200 bg-white space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Isi Berkas di Dalam Paket Siap Pakai:
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs text-slate-700 font-mono">
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span className="font-semibold text-emerald-800">.next/ (Build)</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>public/</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>server.js</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>ecosystem.config.js</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>next.config.js</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>package.json</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>database.sql</span>
                </div>
                <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>.env.example</span>
                </div>
              </div>
            </div>

            {/* Langkah Eksekusi di Cloud Hosting */}
            <div className="p-5 rounded-lg border border-slate-200 bg-slate-900 text-slate-100 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                    Langkah Eksekusi di Cloud Hosting / cPanel (3 Langkah Saja)
                  </h4>
                </div>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  Tanpa npm run build di server
                </span>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex items-start space-x-3">
                  <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">1</span>
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-200">Upload dan Ekstrak berkas</p>
                    <p className="text-slate-400 text-[11px]">
                      Upload <code className="text-emerald-400 bg-slate-800 px-1 py-0.5 rounded">deploy-peta-walhisumut.zip</code> ke folder domain di cPanel File Manager (misal: <code className="text-slate-300">~/peta.walhisumut.or.id/</code>), lalu klik kanan dan pilih <strong>Extract</strong>.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">2</span>
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-200">Install dependensi runtime produksi (cepat & ringan)</p>
                    <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-emerald-400 text-[11px]">
                      <code>npm install --omit=dev</code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText('npm install --omit=dev');
                          setCopiedSnippet('npm-install');
                          setTimeout(() => setCopiedSnippet(null), 2000);
                        }}
                        className="text-slate-400 hover:text-white cursor-pointer px-1.5 py-0.5 rounded hover:bg-slate-800 transition-colors flex items-center space-x-1"
                        title="Salin perintah"
                      >
                        {copiedSnippet === 'npm-install' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span className="text-[10px]">{copiedSnippet === 'npm-install' ? 'Disalin' : 'Salin'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">3</span>
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-200">Jalankan / Restart aplikasi dengan PM2</p>
                    <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-emerald-400 text-[11px]">
                      <code>npx pm2 restart peta-walhisumut || npx pm2 start ecosystem.config.js</code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText('npx pm2 restart peta-walhisumut || npx pm2 start ecosystem.config.js');
                          setCopiedSnippet('pm2-start');
                          setTimeout(() => setCopiedSnippet(null), 2000);
                        }}
                        className="text-slate-400 hover:text-white cursor-pointer px-1.5 py-0.5 rounded hover:bg-slate-800 transition-colors flex items-center space-x-1"
                        title="Salin perintah"
                      >
                        {copiedSnippet === 'pm2-start' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span className="text-[10px]">{copiedSnippet === 'pm2-start' ? 'Disalin' : 'Salin'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Fallback jika non-developer mencoba mengakses tab database atau deploy via URL */}
        {(activeTab === 'database' || activeTab === 'deploy') && !isDeveloper && (
          <div className="bg-white p-8 rounded-xl border border-slate-200 text-center space-y-3">
            <Shield className="w-12 h-12 text-rose-500 mx-auto" />
            <h3 className="text-base font-bold text-slate-800">Akses Terbatas: Khusus Developer</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Menu Database MySQL dan Paket Deploy Produksi diproteksi dan hanya dapat diakses oleh akun Developer.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('general')}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-2xs"
              >
                Kembali ke Pengaturan Umum
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
