'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AdminNavbar from '@/components/AdminNavbar';
import {
  Code2,
  Copy,
  Check,
  Download,
  ExternalLink,
  Globe,
  Monitor,
  Tablet,
  Smartphone,
  Layers,
  Sparkles,
  Info,
  CheckCircle2,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight,
  Maximize2,
} from 'lucide-react';

function subscribeToOrigin() {
  return () => {};
}

function getOriginSnapshot() {
  return typeof window !== 'undefined' ? window.location.origin : '';
}

function getServerOriginSnapshot() {
  return '';
}

export default function AdminWidgetPage() {
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'iframe' | 'shortcode' | 'plugin' | 'functions'>('iframe');
  const [isDeveloper, setIsDeveloper] = useState<boolean | null>(null);
  const [loadingAuth, setLoadingAuth] = useState<boolean>(true);
  
  // Customization controls
  const [iframeHeight, setIframeHeight] = useState<number>(650);
  const [iframeWidth, setIframeWidth] = useState<string>('100%');
  const [borderRadius, setBorderRadius] = useState<number>(12);
  const [hasShadow, setHasShadow] = useState<boolean>(true);
  const [hasBorder, setHasBorder] = useState<boolean>(false);
  const [devicePreview, setDevicePreview] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [refreshKey, setRefreshKey] = useState<number>(0);

  useEffect(() => {
    fetch('/api/auth')
      .then((res) => res.json())
      .then((data) => {
        const isDev = Boolean(data.isDeveloper || data.user?.isDeveloper || data.user?.username === 'super');
        setIsDeveloper(isDev);
        setLoadingAuth(false);
      })
      .catch(() => {
        setIsDeveloper(false);
        setLoadingAuth(false);
      });
  }, []);

  const currentOrigin = React.useSyncExternalStore(
    subscribeToOrigin,
    getOriginSnapshot,
    getServerOriginSnapshot
  );

  const widgetUrl = `${currentOrigin || ''}/widget`;

  // Generated iframe snippet
  const shadowStyle = hasShadow ? ' box-shadow: 0 4px 20px rgba(0,0,0,0.08);' : '';
  const borderStyle = hasBorder ? 'border: 1px solid #e2e8f0;' : 'border: none;';
  
  const iframeSnippet = `<div class="peta-walhisumut-embed" style="width: ${iframeWidth}; max-width: 100%; margin: 16px auto; position: relative;">
  <iframe
    src="${widgetUrl}"
    width="100%"
    height="${iframeHeight}px"
    style="${borderStyle} width: 100%; height: ${iframeHeight}px; border-radius: ${borderRadius}px;${shadowStyle} display: block; overflow: hidden;"
    title="Peta Interaktif Wilayah Kelola Rakyat (WKR) WALHI Sumatera Utara"
    allow="geolocation"
    allowfullscreen="true"
    loading="lazy">
  </iframe>
</div>`;

  const shortcodeSnippet = `[peta_walhisumut height="${iframeHeight}px"${borderRadius !== 12 ? ` radius="${borderRadius}px"` : ''}${!hasShadow ? ' shadow="false"' : ''}]`;

  const functionsPhpSnippet = `/**
 * Shortcode Peta Interaktif WALHI Sumut untuk functions.php
 * Tempelkan kode ini di bagian paling bawah functions.php tema aktif Anda.
 */
function register_walhi_sumut_map_shortcode($atts) {
    $a = shortcode_atts(array(
        'height' => '${iframeHeight}px',
        'width'  => '100%',
        'radius' => '${borderRadius}px',
        'shadow' => '${hasShadow ? 'true' : 'false'}',
    ), $atts);

    $shadow_css = ($a['shadow'] === 'true') ? 'box-shadow: 0 4px 20px rgba(0,0,0,0.08);' : '';

    return sprintf(
        '<div style="width:%%s; max-width:100%%%%; margin:16px auto;">
            <iframe src="%s" width="100%%%%" height="%%s" style="border:none; width:100%%%%; height:%%s; border-radius:%%s; %%s display:block; overflow:hidden;" allowfullscreen="true" loading="lazy"></iframe>
        </div>',
        esc_attr($a['width']),
        esc_attr($a['height']),
        esc_attr($a['height']),
        esc_attr($a['radius']),
        $shadow_css
    );
}
add_shortcode('peta_walhisumut', 'register_walhi_sumut_map_shortcode');`;

  const handleCopy = (text: string, type: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedType(type);
      setTimeout(() => setCopiedType(null), 3000);
    }
  };

  const getPreviewContainerWidth = () => {
    switch (devicePreview) {
      case 'mobile':
        return 'max-w-[375px]';
      case 'tablet':
        return 'max-w-[768px]';
      default:
        return 'max-w-full';
    }
  };

  if (loadingAuth) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
        <AdminNavbar />
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12 flex items-center justify-center">
          <div className="text-center space-y-3">
            <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
            <p className="text-sm font-medium text-slate-600">Memeriksa hak akses developer...</p>
          </div>
        </main>
      </div>
    );
  }

  if (!isDeveloper) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
        <AdminNavbar />
        <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-12">
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4 shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center mx-auto">
              <Code2 className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h2 className="text-xl font-bold text-slate-900">Akses Terbatas: Menu Khusus Developer</h2>
              <p className="text-sm text-slate-500 max-w-md mx-auto">
                Menu <strong>Widget WordPress</strong> dan konfigurasi integrasi iframe/plugin saat ini hanya dapat diakses oleh pengguna dengan hak akses Developer.
              </p>
            </div>
            <div className="pt-4 flex justify-center gap-3">
              <Link
                href="/admin"
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
              >
                Kembali ke Dashboard
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      <AdminNavbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
        {/* Header Title Section */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 sm:p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2.5">
              <span className="p-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
                <Code2 className="w-5 h-5" />
              </span>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Widget Peta untuk WordPress
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1.5 max-w-2xl leading-relaxed">
              Sematkan peta interaktif spasial Wilayah Kelola Rakyat (WKR) tanpa headbar langsung ke dalam situs WordPress, artikel, maupun halaman portal Anda. Data peta terhubung secara otomatis dan tersinkronisasi realtime.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => setRefreshKey((k) => k + 1)}
              className="px-3 py-2 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors flex items-center space-x-1.5 shadow-2xs cursor-pointer"
              title="Muat ulang pratinjau widget"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
              <span>Refresh Widget</span>
            </button>

            <Link
              href="/widget"
              target="_blank"
              className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center space-x-1.5 shadow-xs cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Buka Widget di Tab Baru</span>
            </Link>
          </div>
        </div>

        {/* Highlight Feature Banner */}
        <div className="bg-gradient-to-r from-emerald-900 to-slate-900 rounded-xl p-4 sm:p-5 text-white shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold uppercase tracking-wider border border-emerald-400/30">
                Fitur Lengkap Tanpa Headbar
              </span>
              <span className="text-xs text-slate-300 font-medium hidden xs:inline">• Terhubung Realtime</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-200">
              Widget mempertahankan seluruh fitur utama: pencarian kelompok floating otomatis, layer switcher, filter basemap satelit/topografi, indikator statistik luas, dan klik modal rincian poligon.
            </p>
          </div>
          <div className="flex items-center space-x-3 shrink-0">
            <div className="text-right hidden md:block">
              <span className="block text-[10px] uppercase text-emerald-400 font-bold">Endpoint Widget</span>
              <code className="text-xs text-white font-mono bg-white/10 px-2 py-0.5 rounded">/widget</code>
            </div>
          </div>
        </div>

        {/* Live Preview and Controls Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Interactive Customizer (4 Cols) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center space-x-2">
                  <SlidersHorizontal className="w-4 h-4 text-emerald-600" />
                  <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
                    Sesuaikan Tampilan
                  </h2>
                </div>
                <span className="text-[11px] text-slate-400">Live Customizer</span>
              </div>

              {/* Tinggi Iframe */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">Tinggi Peta (Height)</label>
                  <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {iframeHeight}px
                  </span>
                </div>
                <input
                  type="range"
                  min="400"
                  max="900"
                  step="25"
                  value={iframeHeight}
                  onChange={(e) => setIframeHeight(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>400px (Kecil)</span>
                  <span>650px (Standar)</span>
                  <span>900px (Layar Penuh)</span>
                </div>
              </div>

              {/* Lebar Iframe */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700">Lebar (Width)</label>
                <div className="grid grid-cols-3 gap-2">
                  {['100%', '900px', '750px'].map((w) => (
                    <button
                      key={w}
                      type="button"
                      onClick={() => setIframeWidth(w)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                        iframeWidth === w
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300 shadow-2xs'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {w === '100%' ? '100% (Responsif)' : w}
                    </button>
                  ))}
                </div>
              </div>

              {/* Kelengkungan Sudut (Border Radius) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">Sudut Melengkung (Radius)</label>
                  <span className="text-xs font-mono text-slate-500">{borderRadius}px</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[0, 8, 12, 16].map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setBorderRadius(r)}
                      className={`px-2 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                        borderRadius === r
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300 shadow-2xs'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {r === 0 ? 'Tegak (0)' : `${r}px`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Efek Bayangan & Garis Tepi */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <label className="flex items-center justify-between cursor-pointer select-none">
                  <span className="text-xs font-medium text-slate-700">Efek Bayangan Lembut (Shadow)</span>
                  <input
                    type="checkbox"
                    checked={hasShadow}
                    onChange={(e) => setHasShadow(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer select-none">
                  <span className="text-xs font-medium text-slate-700">Garis Batas Halus (Border)</span>
                  <input
                    type="checkbox"
                    checked={hasBorder}
                    onChange={(e) => setHasBorder(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
                  />
                </label>
              </div>

              {/* Informasi Integrasi Data */}
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 space-y-1.5">
                <div className="flex items-center space-x-1.5 font-bold text-slate-800">
                  <Info className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Koneksi Data Spasial</span>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-500">
                  Widget di WordPress selalu terhubung langsung dengan database sistem ini. Penambahan polygon baru, perubahan luas, atau pembaruan status akan langsung tampil di website WordPress tanpa perlu mengedit halaman.
                </p>
              </div>
            </div>

            {/* Quick Download Plugin Card */}
            <div className="bg-emerald-900 text-white rounded-xl shadow-xs p-5 space-y-3">
              <div className="flex items-center space-x-2">
                <Download className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">Download Plugin WordPress</h3>
              </div>
              <p className="text-xs text-emerald-100/80 leading-relaxed">
                Pasang plugin resmi di WordPress Anda untuk mengaktifkan shortcode <code className="bg-emerald-950 px-1.5 py-0.5 rounded text-emerald-300 font-mono text-[11px]">[peta_walhisumut]</code> dan widget menu.
              </p>
              <div className="flex flex-col gap-2 pt-1">
                <a
                  href="/peta-walhi-sumut-widget.zip"
                  download="peta-walhi-sumut-widget.zip"
                  className="w-full text-center px-3 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh Paket Plugin (.ZIP)</span>
                </a>
                <a
                  href="/peta-walhi-sumut-widget.php"
                  download="peta-walhi-sumut-widget.php"
                  className="w-full text-center px-3 py-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-950/80 text-emerald-300 text-[11px] font-medium transition-colors flex items-center justify-center space-x-1.5 border border-emerald-700/50 cursor-pointer"
                >
                  <span>Unduh Berkas Tunggal (.PHP)</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Live Interactive Preview & Snippet Generator (8 Cols) */}
          <div className="lg:col-span-8 space-y-6">
            {/* Live Preview Card */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden flex flex-col">
              <div className="px-4 sm:px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Live Preview Widget (Tanpa Headbar)
                  </span>
                </div>

                {/* Device Selector */}
                <div className="flex items-center bg-white rounded-lg p-0.5 border border-slate-200 shadow-2xs">
                  <button
                    type="button"
                    onClick={() => setDevicePreview('desktop')}
                    className={`p-1.5 rounded-md transition-all ${
                      devicePreview === 'desktop'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title="Pratinjau Desktop"
                  >
                    <Monitor className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDevicePreview('tablet')}
                    className={`p-1.5 rounded-md transition-all ${
                      devicePreview === 'tablet'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title="Pratinjau Tablet"
                  >
                    <Tablet className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDevicePreview('mobile')}
                    className={`p-1.5 rounded-md transition-all ${
                      devicePreview === 'mobile'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title="Pratinjau Ponsel / Mobile"
                  >
                    <Smartphone className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Frame Container */}
              <div className="p-4 sm:p-6 bg-slate-100/70 flex items-center justify-center overflow-x-auto min-h-[420px]">
                <div
                  className={`w-full ${getPreviewContainerWidth()} transition-all duration-300`}
                  style={{
                    borderRadius: `${borderRadius}px`,
                    boxShadow: hasShadow ? '0 10px 30px -5px rgba(0, 0, 0, 0.15)' : 'none',
                    border: hasBorder ? '1px solid #cbd5e1' : 'none',
                  }}
                >
                  <iframe
                    key={refreshKey}
                    src={widgetUrl}
                    style={{
                      width: '100%',
                      height: `${iframeHeight}px`,
                      borderRadius: `${borderRadius}px`,
                      border: 'none',
                      display: 'block',
                      backgroundColor: '#f8fafc',
                    }}
                    title="Live Preview Widget Peta WALHI Sumut"
                    loading="lazy"
                  />
                </div>
              </div>

              <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                <span>Pencarian kelompok, filter layer, dan klik modal interaktif berjalan penuh di dalam frame.</span>
                <span className="font-mono text-emerald-700 font-bold">{iframeWidth} × {iframeHeight}px</span>
              </div>
            </div>

            {/* Code Generator Snippets */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
              {/* Tab Navigation */}
              <div className="flex border-b border-slate-200 bg-slate-50 px-2 sm:px-4 overflow-x-auto">
                <button
                  onClick={() => setActiveTab('iframe')}
                  className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'iframe'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Kode HTML Iframe (Gutenberg / Elementor)
                </button>
                <button
                  onClick={() => setActiveTab('shortcode')}
                  className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'shortcode'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  WordPress Shortcode
                </button>
                <button
                  onClick={() => setActiveTab('plugin')}
                  className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'plugin'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Panduan Pasang Plugin
                </button>
                <button
                  onClick={() => setActiveTab('functions')}
                  className={`py-3 px-3 sm:px-4 text-xs font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'functions'
                      ? 'border-emerald-600 text-emerald-700 bg-white'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Kode functions.php
                </button>
              </div>

              {/* Tab 1: HTML Iframe */}
              {activeTab === 'iframe' && (
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Kode HTML Embed / Iframe
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Salin dan tempelkan kode ini ke dalam blok <strong>HTML Khusus</strong> di Gutenberg atau widget <strong>HTML</strong> di Elementor.
                      </p>
                    </div>
                    <button
                      onClick={() => handleCopy(iframeSnippet, 'iframe')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer shadow-2xs ${
                        copiedType === 'iframe'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      {copiedType === 'iframe' ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Berhasil Disalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Salin Kode Iframe</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="relative">
                    <pre className="p-4 bg-slate-950 text-slate-200 rounded-xl text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                      <code>{iframeSnippet}</code>
                    </pre>
                  </div>

                  {/* Step-by-step for Gutenberg & Elementor */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-1.5">
                      <h4 className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                        <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold">1</span>
                        <span>Di Gutenberg (Block Editor)</span>
                      </h4>
                      <ol className="text-[11px] text-slate-600 list-decimal list-inside space-y-1 pl-1">
                        <li>Buka halaman/postingan yang ingin disisipkan peta di WordPress.</li>
                        <li>Klik tanda tambah <strong>(+)</strong> lalu cari blok <strong>HTML Khusus</strong> (Custom HTML).</li>
                        <li>Tempelkan kode di atas, lalu klik <strong>Perbarui / Terbitkan</strong>.</li>
                      </ol>
                    </div>

                    <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 space-y-1.5">
                      <h4 className="text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                        <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold">2</span>
                        <span>Di Elementor Page Builder</span>
                      </h4>
                      <ol className="text-[11px] text-slate-600 list-decimal list-inside space-y-1 pl-1">
                        <li>Buka halaman dengan <strong>Edit with Elementor</strong>.</li>
                        <li>Tarik elemen <strong>HTML</strong> ke kolom halaman yang diinginkan.</li>
                        <li>Tempelkan kode di atas ke kolom HTML Code, lalu klik <strong>Update</strong>.</li>
                      </ol>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: WordPress Shortcode */}
              {activeTab === 'shortcode' && (
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        WordPress Shortcode
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Dapat langsung disematkan menggunakan blok <strong>Shortcode</strong> di WordPress (setelah plugin diaktifkan).
                      </p>
                    </div>
                    <button
                      onClick={() => handleCopy(shortcodeSnippet, 'shortcode')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer shadow-2xs ${
                        copiedType === 'shortcode'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      {copiedType === 'shortcode' ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Berhasil Disalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Salin Shortcode</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="p-4 bg-slate-950 text-emerald-400 rounded-xl text-sm font-mono flex items-center justify-between border border-slate-800">
                    <code>{shortcodeSnippet}</code>
                  </div>

                  <div className="space-y-2 pt-2">
                    <h4 className="text-xs font-bold text-slate-800">Parameter Tambahan Shortcode:</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600 font-mono">
                      <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                        <span className="font-bold text-emerald-700">height=&quot;650px&quot;</span>
                        <p className="text-[11px] text-slate-500 font-sans mt-0.5">Menentukan tinggi kotak peta</p>
                      </div>
                      <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                        <span className="font-bold text-emerald-700">width=&quot;100%&quot;</span>
                        <p className="text-[11px] text-slate-500 font-sans mt-0.5">Menentukan lebar kontainer peta</p>
                      </div>
                      <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                        <span className="font-bold text-emerald-700">radius=&quot;12px&quot;</span>
                        <p className="text-[11px] text-slate-500 font-sans mt-0.5">Kelengkungan sudut bingkai peta</p>
                      </div>
                      <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                        <span className="font-bold text-emerald-700">shadow=&quot;true|false&quot;</span>
                        <p className="text-[11px] text-slate-500 font-sans mt-0.5">Aktifkan atau matikan bayangan lembut</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Panduan Pasang Plugin */}
              {activeTab === 'plugin' && (
                <div className="p-5 space-y-4">
                  <div>
                    <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      Langkah Pemasangan Plugin di WordPress
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Cara paling praktis dan rapi untuk menghubungkan peta ke WordPress Anda.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-start space-x-3 p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">Unduh Paket Plugin</h4>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Klik tombol download di samping kiri untuk mengunduh <code className="text-emerald-700 font-bold">peta-walhi-sumut-widget.zip</code>.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3 p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">Buka Dashboard WordPress</h4>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Masuk ke Dashboard WordPress admin Anda, navigasikan ke menu <strong>Plugins (Plugin) &gt; Tambah Baru (Add New)</strong>.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3 p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">Unggah dan Aktifkan Plugin</h4>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Klik tombol <strong>Unggah Plugin (Upload Plugin)</strong> di bagian atas, pilih file <code className="text-emerald-700 font-bold">peta-walhi-sumut-widget.zip</code>, lalu klik <strong>Instal Sekarang</strong> kemudian <strong>Aktifkan</strong>.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3 p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">4</span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">Peta Siap Digunakan</h4>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Sekarang Anda cukup menyisipkan shortcode <code className="text-emerald-700 font-bold">[peta_walhisumut]</code> di artikel/halaman mana saja, atau menambahkan widget di menu <strong>Tampilan (Appearance) &gt; Widget</strong>!
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: functions.php */}
              {activeTab === 'functions' && (
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Kode PHP Tema (functions.php)
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Gunakan kode ini jika Anda tidak ingin menginstal plugin tambahan dan ingin mendaftarkan shortcode langsung di tema aktif.
                      </p>
                    </div>
                    <button
                      onClick={() => handleCopy(functionsPhpSnippet, 'functions')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer shadow-2xs ${
                        copiedType === 'functions'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      {copiedType === 'functions' ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Berhasil Disalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Salin Kode PHP</span>
                        </>
                      )}
                    </button>
                  </div>

                  <pre className="p-4 bg-slate-950 text-slate-200 rounded-xl text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                    <code>{functionsPhpSnippet}</code>
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
