'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AdminNavbar from '@/components/AdminNavbar';
import MapExportModal from '@/components/MapExportModal';
import CircularLoading from '@/components/CircularLoading';
import { MapRecord, Category } from '@/lib/types';
import {
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  MapPin,
  ExternalLink,
  Layers,
  CheckCircle2,
  Download,
  CheckSquare,
  Square,
  GripVertical,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

export default function MapsListPage() {
  const [maps, setMaps] = useState<MapRecord[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(15);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedMapIds, setSelectedMapIds] = useState<string[]>([]);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Pagination & Drag and Drop state
  const [currentPage, setCurrentPage] = useState(1);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const itemsPerPage = 10;

  useEffect(() => {
    let isMounted = true;
    let timer = setInterval(() => {
      setLoadingProgress((prev) => (prev < 90 ? prev + Math.floor(Math.random() * 15) + 5 : prev));
    }, 120);

    const init = async () => {
      try {
        const [mapsRes, catsRes] = await Promise.all([
          fetch('/api/maps'),
          fetch('/api/categories'),
        ]);
        const mapsData = await mapsRes.json();
        const catsData = await catsRes.json();
        if (isMounted) {
          if (mapsData.data) setMaps(mapsData.data);
          if (catsData.data) setCategories(catsData.data);
          setLoadingProgress(100);
        }
      } catch (err) {
        console.error(err);
        if (isMounted) setLoadingProgress(100);
      } finally {
        if (isMounted) {
          setTimeout(() => setLoading(false), 250);
        }
      }
    };
    init();
    return () => {
      isMounted = false;
      clearInterval(timer);
    };
  }, []);

  const handleRefresh = async () => {
    setLoadingProgress(25);
    setLoading(true);
    let timer = setInterval(() => {
      setLoadingProgress((prev) => (prev < 90 ? prev + Math.floor(Math.random() * 15) + 5 : prev));
    }, 120);
    try {
      const [mapsRes, catsRes] = await Promise.all([
        fetch('/api/maps'),
        fetch('/api/categories'),
      ]);
      const mapsData = await mapsRes.json();
      const catsData = await catsRes.json();
      if (mapsData.data) setMaps(mapsData.data);
      if (catsData.data) setCategories(catsData.data);
      setLoadingProgress(100);
    } catch (err) {
      console.error(err);
      setLoadingProgress(100);
    } finally {
      clearInterval(timer);
      setTimeout(() => setLoading(false), 250);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Hapus data kelompok "${name}"?`)) return;

    try {
      const res = await fetch(`/api/maps/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setMaps((prev) => prev.filter((m) => m.id !== id));
        setSelectedMapIds((prev) => prev.filter((i) => i !== id));
      }
    } catch (err) {
      alert('Gagal menghapus data');
    }
  };

  const filteredMaps = maps.filter((m) => {
    if (selectedCategory !== 'all' && m.categoryId !== selectedCategory) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        m.name.toLowerCase().includes(q) ||
        m.address.toLowerCase().includes(q) ||
        m.desa?.toLowerCase().includes(q) ||
        m.kecamatan?.toLowerCase().includes(q) ||
        m.kabupaten?.toLowerCase().includes(q) ||
        m.proses?.toLowerCase().includes(q) ||
        (m.kkCount && String(m.kkCount).includes(q)) ||
        (m.jumlahKk && String(m.jumlahKk).includes(q)) ||
        m.komoditi?.toLowerCase().includes(q) ||
        m.pendamping?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleToggleSelectAll = () => {
    const filteredIds = filteredMaps.map((m) => m.id);
    const isAllFilteredSelected =
      filteredIds.length > 0 && filteredIds.every((id) => selectedMapIds.includes(id));

    if (isAllFilteredSelected) {
      setSelectedMapIds((prev) => prev.filter((id) => !filteredIds.includes(id)));
    } else {
      const newSet = new Set([...selectedMapIds, ...filteredIds]);
      setSelectedMapIds(Array.from(newSet));
    }
  };

  const handleToggleOne = (id: string) => {
    setSelectedMapIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const isAllSelected =
    filteredMaps.length > 0 &&
    filteredMaps.every((m) => selectedMapIds.includes(m.id));

  // Pagination calculations
  const totalItems = filteredMaps.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedMaps = filteredMaps.slice(startIndex, endIndex);

  // Drag and drop event handlers
  const handleDragStart = (e: React.DragEvent, index: number) => {
    const absoluteIndex = maps.findIndex((m) => m.id === paginatedMaps[index].id);
    setDraggedIndex(absoluteIndex);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex === null) return;
    const targetAbsoluteIndex = maps.findIndex((m) => m.id === paginatedMaps[index].id);
    if (draggedIndex !== targetAbsoluteIndex) {
      const updated = [...maps];
      const draggedItem = updated[draggedIndex];
      updated.splice(draggedIndex, 1);
      updated.splice(targetAbsoluteIndex, 0, draggedItem);
      setMaps(updated);
      setDraggedIndex(targetAbsoluteIndex);
    }
  };

  const handleDragEnd = async () => {
    setDraggedIndex(null);
    try {
      const ids = maps.map((m) => m.id);
      await fetch('/api/maps/reorder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids }),
      });
    } catch (err) {
      console.error('Failed to save maps order:', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] font-sans pb-16 text-slate-800">
      <AdminNavbar />

      {loading && (
        <CircularLoading
          progress={loadingProgress}
        />
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Maps Management</h2>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <Layers className="w-3.5 h-3.5" />
                Total Data ({maps.length})
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                if (selectedMapIds.length > 0) {
                  setIsExportModalOpen(true);
                }
              }}
              disabled={selectedMapIds.length === 0}
              className={`inline-flex items-center space-x-1.5 px-3.5 py-2 rounded text-white text-xs font-bold shadow-xs transition-colors ${
                selectedMapIds.length > 0
                  ? 'bg-blue-600 hover:bg-blue-700 cursor-pointer'
                  : 'bg-slate-300 dark:bg-slate-700 text-slate-400 cursor-not-allowed opacity-60'
              }`}
              title={
                selectedMapIds.length > 0
                  ? `Download ${selectedMapIds.length} data spasial (.SHP / .ZIP / GeoJSON / KMZ)`
                  : 'Silakan pilih data peta terlebih dahulu untuk mengunduh'
              }
            >
              <Download className="w-3.5 h-3.5" />
              <span>
                {selectedMapIds.length > 0
                  ? `Download (${selectedMapIds.length})`
                  : 'Download'}
              </span>
            </button>

            <Link
              href="/admin/maps/create"
              className="inline-flex items-center space-x-1.5 px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>TAMBAH DATA</span>
            </Link>
          </div>
        </div>

        {/* Filter & Selection Bar */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Cari nama kelompok, desa, kecamatan, kabupaten, komoditi..."
              className="w-full bg-transparent text-xs text-slate-900 focus:outline-hidden font-medium placeholder-slate-400"
            />
          </div>

          <div className="flex items-center space-x-3">
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs text-slate-700 font-semibold focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">Semua Kategori</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600 font-sans">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-4 py-3.5 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      onChange={handleToggleSelectAll}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                      title="Pilih / Batalkan semua item pada tabel"
                    />
                  </th>
                  <th className="px-4 py-3.5 w-10 text-center">Urut</th>
                  <th className="px-4 py-3.5">Nama Kelompok</th>
                  <th className="px-4 py-3.5">Kategori</th>
                  <th className="px-4 py-3.5">Lokasi (Desa, Kec, Kab)</th>
                  <th className="px-4 py-3.5 text-center">Jumlah KK</th>
                  <th className="px-4 py-3.5">Proses</th>
                  <th className="px-4 py-3.5">Komoditi & Pendamping</th>
                  <th className="px-4 py-3.5">Luas (Ha)</th>
                  <th className="px-4 py-3.5 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedMaps.map((map, index) => {
                  const isChecked = selectedMapIds.includes(map.id);
                  const absoluteIndex = maps.findIndex((m) => m.id === map.id);
                  const isDragged = draggedIndex === absoluteIndex;

                  return (
                    <tr
                      key={map.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, index)}
                      onDragOver={(e) => handleDragOver(e, index)}
                      onDragEnd={handleDragEnd}
                      className={`hover:bg-slate-50/80 transition-all select-none ${
                        isChecked ? 'bg-blue-50/30' : ''
                      } ${isDragged ? 'opacity-40 bg-slate-100 scale-[0.99]' : ''}`}
                    >
                      <td className="px-4 py-3 text-center">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleOne(map.id)}
                          className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-3 text-center cursor-grab active:cursor-grabbing text-slate-400 hover:text-slate-600">
                        <GripVertical className="w-4 h-4 mx-auto" />
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-900">
                        <div className="font-bold text-slate-900 text-xs">{map.name}</div>
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-700">
                        <div className="flex flex-col gap-1.5 items-start">
                          <span
                            className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider"
                            style={{
                              backgroundColor: (map.categoryColor || '#10b981') + '20',
                              color: map.categoryColor || '#059669',
                            }}
                          >
                            {map.categoryName}
                          </span>
                          {map.subcategoryName && (
                            <span className="text-[10px] font-normal text-slate-500 italic leading-none">
                              {map.subcategoryName}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600">
                        <div className="font-semibold text-slate-800">
                          {map.desa ? `Desa ${map.desa}` : (map.kabupaten || 'Sumatera Utara')}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate max-w-[200px]">
                          {map.address}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className="font-mono font-bold text-slate-800 text-xs bg-slate-100 px-2 py-1 rounded">
                          {(map.jumlahKk !== undefined && map.jumlahKk !== null && map.jumlahKk > 0)
                            ? `${map.jumlahKk.toLocaleString('id-ID')} KK`
                            : (map.kkCount !== undefined && map.kkCount !== null && map.kkCount > 0)
                            ? `${map.kkCount.toLocaleString('id-ID')} KK`
                            : '-'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-700">
                        <div className="text-xs font-medium max-w-[180px] truncate" title={map.proses || '-'}>
                          {map.proses || '-'}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600">
                        <div className="font-medium text-slate-800 text-[11px] truncate max-w-[180px]" title={map.komoditi}>
                          🌱 {map.komoditi || '-'}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[180px]" title={map.pendamping}>
                          🤝 {map.pendamping || '-'}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono font-semibold text-slate-800 whitespace-nowrap">
                        {map.areaHa ? `${map.areaHa.toLocaleString('id-ID')} Ha` : '-'}
                      </td>
                      <td className="px-4 py-3 text-right space-x-2 whitespace-nowrap text-xs">
                        <Link
                          href={`/admin/maps/${map.id}/edit`}
                          className="inline-flex items-center space-x-1 text-emerald-600 hover:text-emerald-800 font-bold"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </Link>
                        <button
                          onClick={() => handleDelete(map.id, map.name)}
                          className="inline-flex items-center space-x-1 text-rose-600 hover:text-rose-800 font-bold cursor-pointer ml-2"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Hapus</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {filteredMaps.length === 0 && (
                  <tr>
                    <td colSpan={10} className="px-5 py-8 text-center text-slate-400">
                      {loading ? 'Memuat data peta...' : 'Tidak ada data kelompok yang cocok.'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-5 py-4 border-t border-slate-200 bg-slate-50/50 text-xs text-slate-500 font-medium">
              <div>
                Menampilkan <span className="text-slate-800 font-bold">{startIndex + 1}</span> - <span className="text-slate-800 font-bold">{Math.min(endIndex, totalItems)}</span> dari <span className="text-slate-800 font-bold">{totalItems}</span> data peta
              </div>
              <div className="flex items-center space-x-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                  className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white text-slate-600 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                {Array.from({ length: totalPages }).map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setCurrentPage(i + 1)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      currentPage === i + 1
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'border border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                  className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white text-slate-600 transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      <MapExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        selectedIds={selectedMapIds}
        totalSelectedCount={selectedMapIds.length}
        maps={maps}
      />
    </div>
  );
}
