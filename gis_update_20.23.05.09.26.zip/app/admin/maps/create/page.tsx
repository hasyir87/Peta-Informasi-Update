'use client';

import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import AdminNavbar from '@/components/AdminNavbar';
import { Category, GeometryType, GeoJSONGeometry } from '@/lib/types';
import { Save, ArrowLeft, AlertCircle, Loader2 } from 'lucide-react';

const LeafletMapEditor = dynamic(() => import('@/components/LeafletMapEditor'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full min-h-[400px] flex items-center justify-center bg-slate-900 text-slate-100 rounded-lg">
      <div className="flex items-center space-x-2">
        <Loader2 className="w-5 h-5 animate-spin text-emerald-500" />
        <span className="text-xs text-slate-300">Memuat Map Editor...</span>
      </div>
    </div>
  ),
});

export default function CreateMapPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [name, setName] = useState('');
  const [desa, setDesa] = useState('');
  const [kecamatan, setKecamatan] = useState('');
  const [kabupaten, setKabupaten] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [subcategoryId, setSubcategoryId] = useState('');
  const [type] = useState<GeometryType>('Polygon');
  const [latitude, setLatitude] = useState<number>(2.8654);
  const [longitude, setLongitude] = useState<number>(98.9234);
  const [areaHa, setAreaHa] = useState<number>(150);
  const [jumlahKk, setJumlahKk] = useState<number | ''>('');
  const [proses, setProses] = useState('');
  const [description, setDescription] = useState('');
  const [komoditi, setKomoditi] = useState('');
  const [pendamping, setPendamping] = useState('');
  const [skLegalitas, setSkLegalitas] = useState('');
  const [tahun, setTahun] = useState<number>(new Date().getFullYear());

  // Geometry state
  const [geometry, setGeometry] = useState<GeoJSONGeometry>({
    type: 'Polygon',
    coordinates: [[
      [98.8800, 2.8900],
      [98.9400, 2.8950],
      [98.9500, 2.8450],
      [98.8750, 2.8400],
      [98.8800, 2.8900],
    ]],
  });

  useEffect(() => {
    fetch('/api/categories')
      .then((res) => res.json())
      .then((data) => {
        if (data.data && data.data.length > 0) {
          setCategories(data.data);
        }
      });
  }, []);

  const handleGeometryChange = (geom: GeoJSONGeometry) => {
    setGeometry(geom);
  };

  const handleSHPUploaded = (info: {
    fileName: string;
    areaHa?: number;
    desa?: string;
    kecamatan?: string;
    kabupaten?: string;
    name?: string;
  }) => {
    if (info.areaHa && info.areaHa > 0) setAreaHa(info.areaHa);
    if (info.desa && !desa) setDesa(info.desa);
    if (info.kecamatan && !kecamatan) setKecamatan(info.kecamatan);
    if (info.kabupaten && !kabupaten) setKabupaten(info.kabupaten);
    if (info.name && !name) setName(info.name);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Nama peta/wilayah wajib diisi');
      return;
    }
    if (!categoryId) {
      setError('Kategori peta wajib dipilih');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const selectedCatObj = categories.find((c) => c.id === categoryId);
      if (selectedCatObj?.subcategories?.length && !subcategoryId) {
        throw new Error('Sub-Kategori peta wajib dipilih');
      }
      const constructedAddress = [
        desa ? `Desa ${desa}` : '',
        kecamatan ? `Kec. ${kecamatan}` : '',
        kabupaten ? `Kab. ${kabupaten}` : '',
        'Sumatera Utara',
      ].filter(Boolean).join(', ');

      const payload = {
        name,
        desa,
        kecamatan,
        kabupaten,
        address: constructedAddress,
        categoryId,
        subcategoryId: selectedCatObj?.subcategories?.length ? subcategoryId : undefined,
        type: geometry.type as GeometryType || type,
        latitude,
        longitude,
        status: 'Active',
        areaHa: Number(areaHa),
        jumlahKk: jumlahKk === '' ? 0 : Number(jumlahKk),
        kkCount: jumlahKk === '' ? 0 : Number(jumlahKk),
        proses,
        description,
        komoditi,
        pendamping,
        skLegalitas,
        tahun: Number(tahun),
        geometry,
      };

      const res = await fetch('/api/maps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || 'Gagal menyimpan');

      router.push('/admin/maps');
      router.refresh();
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan saat menyimpan');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] font-sans pb-16 text-slate-800">
      <AdminNavbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-6">
        {/* Title */}
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Tambah Data</h2>
          </div>
        </div>

        {error && (
          <div className="p-4 rounded bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Form Fields */}
            <div className="lg:col-span-6 bg-white p-5 rounded-lg border border-slate-200 shadow-2xs space-y-4">
              {/* Name */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Nama Kelompok <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Kelompok Tani Hutan Adat Sihaporas"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:outline-hidden font-bold"
                />
              </div>

              {/* Alamat Wilayah Pecah 3: Desa, Kecamatan, Kabupaten */}
              <div className="space-y-2 p-3.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-800 mb-1">
                  Alamat Lokasi Desa
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                      Nama Desa / Nagori
                    </label>
                    <input
                      type="text"
                      value={desa}
                      onChange={(e) => setDesa(e.target.value)}
                      placeholder="Contoh: Sihaporas"
                      className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                      Kecamatan
                    </label>
                    <input
                      type="text"
                      value={kecamatan}
                      onChange={(e) => setKecamatan(e.target.value)}
                      placeholder="Contoh: Pematang Sidamanik"
                      className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                      Kabupaten / Kota
                    </label>
                    <input
                      type="text"
                      value={kabupaten}
                      onChange={(e) => setKabupaten(e.target.value)}
                      placeholder="Contoh: Simalungun"
                      className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Category & Subcategory */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Kategori Peta <span className="text-rose-500">*</span>
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => {
                    const catId = e.target.value;
                    setCategoryId(catId);
                    setSubcategoryId('');
                  }}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value="">-- Pilih Kategori --</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Sub-Category (if present) */}
              {(() => {
                const selectedCat = categories.find((c) => c.id === categoryId);
                if (selectedCat?.subcategories && selectedCat.subcategories.length > 0) {
                  const activeSub = selectedCat.subcategories.find((s) => s.id === subcategoryId);
                  const subColor = activeSub?.color || selectedCat.color;
                  return (
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-2">
                        <span>Sub-Kategori ({selectedCat.name}) <span className="text-rose-500">*</span></span>
                        <span
                          className="w-3 h-3 rounded-full inline-block border border-black/10 shadow-2xs shrink-0"
                          style={{ backgroundColor: subColor || '#cbd5e1' }}
                          title="Warna Peta Sub-Kategori"
                        />
                      </label>
                      <select
                        value={subcategoryId}
                        onChange={(e) => setSubcategoryId(e.target.value)}
                        className="w-full px-3.5 py-2 bg-blue-50/60 border border-blue-200 rounded text-xs text-blue-950 font-semibold focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      >
                        <option value="">-- Pilih Sub-Kategori --</option>
                        {selectedCat.subcategories.map((sub) => (
                          <option key={sub.id} value={sub.id}>
                            {sub.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  );
                }
                return null;
              })()}

              {/* Komoditi & Pendamping */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Komoditi Utama / Unggulan
                  </label>
                  <input
                    type="text"
                    value={komoditi}
                    onChange={(e) => setKomoditi(e.target.value)}
                    placeholder="Contoh: Kemenyan, Kopi, Andaliman"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Pendamping
                  </label>
                  <input
                    type="text"
                    value={pendamping}
                    onChange={(e) => setPendamping(e.target.value)}
                    placeholder="Contoh: WALHI Sumut, KSPPM"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              {/* Jumlah KK & Proses (User Requests #8 & #9) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Jumlah KK
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={jumlahKk}
                    onChange={(e) => setJumlahKk(e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value, 10) || 0))}
                    placeholder="Contoh: 120"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Proses
                  </label>
                  <input
                    type="text"
                    value={proses}
                    onChange={(e) => setProses(e.target.value)}
                    placeholder="Contoh: Usulan SK Penetapan / Penetapan Definitif"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              {/* SK Legalitas */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  SK Penetapan / Legalitas
                </label>
                <input
                  type="text"
                  value={skLegalitas}
                  onChange={(e) => setSkLegalitas(e.target.value)}
                  placeholder="Contoh: SK.4522/MENLHK/2019"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>

              {/* Luas Ha & Tahun */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Luas Wilayah (Ha)
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={areaHa}
                    onChange={(e) => setAreaHa(parseFloat(e.target.value) || 0)}
                    placeholder="1200"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Tahun
                  </label>
                  <input
                    type="number"
                    value={tahun}
                    onChange={(e) => setTahun(parseInt(e.target.value) || 2024)}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>
              </div>

              {/* Buttons */}
              <div className="flex items-center space-x-3 pt-3 border-t border-slate-100">
                <Link
                  href="/admin/maps"
                  className="inline-flex items-center space-x-1.5 px-4 py-2 rounded border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>BATAL</span>
                </Link>

                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center space-x-1.5 px-5 py-2 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{loading ? 'MENYIMPAN...' : 'SIMPAN DATA'}</span>
                </button>
              </div>
            </div>

            {/* Right Column: Interactive Polygon Editor via SHP Upload */}
            <div className="lg:col-span-6 bg-white p-5 rounded-lg border border-slate-200 shadow-2xs space-y-4">
              <LeafletMapEditor
                geomType={type}
                latitude={latitude}
                longitude={longitude}
                initialGeometry={geometry}
                onGeometryChange={handleGeometryChange}
                onCoordinatesChange={(lat, lng) => {
                  setLatitude(lat);
                  setLongitude(lng);
                }}
                onSHPUploaded={handleSHPUploaded}
              />
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
