import WidgetPage, { metadata, dynamic } from '../widget/page';

export { metadata, dynamic };
export default WidgetPage;
