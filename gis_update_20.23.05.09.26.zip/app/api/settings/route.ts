import { NextRequest, NextResponse } from 'next/server';
import { getSettingsAsync, updateSettingsAsync } from '@/lib/db';
import { extractMetaContent } from '@/lib/utils';

export async function GET() {
  try {
    const settings = await getSettingsAsync();
    return NextResponse.json(
      { success: true, data: settings },
      {
        headers: {
          'Cache-Control': 'public, max-age=10, s-maxage=20, stale-while-revalidate=40',
        },
      }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();

    // Sanitize search engine verification codes
    if (typeof body.googleVerificationCode === 'string') {
      body.googleVerificationCode = extractMetaContent(body.googleVerificationCode);
    }
    if (typeof body.bingVerificationCode === 'string') {
      body.bingVerificationCode = extractMetaContent(body.bingVerificationCode);
    }

    // Sanitize Google Analytics ID
    if (typeof body.googleAnalyticsId === 'string') {
      body.googleAnalyticsId = body.googleAnalyticsId.trim().toUpperCase();
    }

    // Sanitize maxActivityLogs
    if (body.maxActivityLogs !== undefined) {
      const parsed = parseInt(String(body.maxActivityLogs), 10);
      body.maxActivityLogs = isNaN(parsed) || parsed < 5 ? 50 : parsed;
    }

    // Sanitize underConstruction settings
    if (body.underConstructionEnabled !== undefined) {
      body.underConstructionEnabled = Boolean(body.underConstructionEnabled);
    }
    if (typeof body.underConstructionTitle === 'string') {
      body.underConstructionTitle = body.underConstructionTitle.trim();
    }
    if (typeof body.underConstructionMessage === 'string') {
      body.underConstructionMessage = body.underConstructionMessage.trim();
    }
    if (typeof body.underConstructionEstimatedTime === 'string') {
      body.underConstructionEstimatedTime = body.underConstructionEstimatedTime.trim();
    }
    if (typeof body.underConstructionContact === 'string') {
      body.underConstructionContact = body.underConstructionContact.trim();
    }

    const updated = await updateSettingsAsync(body);
    return NextResponse.json({ success: true, data: updated, message: 'Pengaturan berhasil diperbarui' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
