import { NextRequest, NextResponse } from 'next/server';
import { getMapsAsync, createMapAsync, exportAllAsGeoJSON, getUserById } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const format = searchParams.get('format');
    const category = searchParams.get('category');
    const status = searchParams.get('status');
    const kabupaten = searchParams.get('kabupaten');
    const search = searchParams.get('search');

    if (format === 'geojson') {
      return NextResponse.json(exportAllAsGeoJSON());
    }

    let maps = await getMapsAsync();


    if (category) {
      maps = maps.filter((m) => m.categoryId === category);
    }
    if (status) {
      maps = maps.filter((m) => m.status?.toLowerCase() === status.toLowerCase());
    }
    if (kabupaten) {
      maps = maps.filter((m) => m.kabupaten?.toLowerCase().includes(kabupaten.toLowerCase()));
    }
    if (search) {
      const q = search.toLowerCase();
      maps = maps.filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.description?.toLowerCase().includes(q) ||
          m.address.toLowerCase().includes(q) ||
          m.desa?.toLowerCase().includes(q) ||
          m.kecamatan?.toLowerCase().includes(q) ||
          m.kabupaten?.toLowerCase().includes(q) ||
          m.proses?.toLowerCase().includes(q) ||
          m.pengelola?.toLowerCase().includes(q) ||
          m.komoditi?.toLowerCase().includes(q) ||
          m.pendamping?.toLowerCase().includes(q)
      );
    }

    return NextResponse.json(
      { success: true, data: maps, total: maps.length },
      {
        headers: {
          'Cache-Control': 'public, max-age=5, s-maxage=15, stale-while-revalidate=30',
        },
      }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body.name) {
      return NextResponse.json({ error: 'Nama peta/wilayah wajib diisi' }, { status: 400 });
    }

    const userId = req.cookies.get('wkr_user_id')?.value;
    let userName = req.headers.get('x-user-name') || body.userName;
    if (!userName && userId) {
      const u = getUserById(userId);
      if (u) userName = u.fullName || u.username;
    }

    const newMap = await createMapAsync(body, userName || undefined);
    return NextResponse.json({ success: true, data: newMap, message: 'Data peta berhasil disimpan' }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
