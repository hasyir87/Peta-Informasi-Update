import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getUserById } from '@/lib/db';
import {
  createDatabaseBackup,
  listDatabaseBackups,
  getDatabaseStats,
  getDatabaseBackupFile,
  deleteDatabaseBackup,
  restoreDatabaseFromBackup,
} from '@/lib/databaseBackup';

export const dynamic = 'force-dynamic';

// Helper verifikasi hak akses developer
async function verifyDeveloperAccess() {
  const cookieStore = await cookies();
  const userId = cookieStore.get('wkr_user_id')?.value;
  const authToken = cookieStore.get('wkr_auth_token')?.value;

  if (!userId || !authToken) {
    return { authorized: false, error: 'Sesi login tidak ditemukan' };
  }

  const user = await getUserById(userId);
  if (!user) {
    return { authorized: false, error: 'Pengguna tidak ditemukan' };
  }

  const isDev = Boolean(user.isDeveloper || user.username === 'super');
  if (!isDev) {
    return { authorized: false, error: 'Akses ditolak: Hanya akun Developer yang diizinkan' };
  }

  return { authorized: true, user };
}

/**
 * GET: Mengambil daftar berkas cadangan database, statistik tabel, atau mengunduh berkas SQL
 */
export async function GET(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const downloadFile = searchParams.get('download');

  // Jika permintaan download file .sql
  if (downloadFile) {
    try {
      const { content } = getDatabaseBackupFile(downloadFile);
      return new NextResponse(content, {
        status: 200,
        headers: {
          'Content-Type': 'application/sql',
          'Content-Disposition': `attachment; filename="${downloadFile}"`,
          'Content-Length': content.length.toString(),
        },
      });
    } catch (err: any) {
      return NextResponse.json({ success: false, error: err.message }, { status: 404 });
    }
  }

  try {
    const [backups, stats] = await Promise.all([
      Promise.resolve(listDatabaseBackups()),
      getDatabaseStats(),
    ]);

    return NextResponse.json({
      success: true,
      backups,
      stats,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: `Gagal memuat data backup: ${err.message}` },
      { status: 500 }
    );
  }
}

/**
 * POST: Membuat berkas cadangan database (.SQL) baru
 */
export async function POST(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const notes = body.notes || `Backup database manual oleh ${auth.user.fullName || auth.user.username}`;

    const backup = await createDatabaseBackup(notes);
    return NextResponse.json({
      success: true,
      message: `Berkas cadangan database ${backup.fileName} berhasil dibuat.`,
      backup,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: `Gagal membuat backup database: ${err.message}` },
      { status: 500 }
    );
  }
}

/**
 * PUT: Memulihkan database dari berkas backup yang dipilih
 */
export async function PUT(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { fileName } = body;

    if (!fileName) {
      return NextResponse.json({ success: false, error: 'Parameter fileName wajib disertakan' }, { status: 400 });
    }

    const result = await restoreDatabaseFromBackup(fileName);
    return NextResponse.json({
      success: true,
      message: result.message,
      executedQueries: result.executedQueries,
      tablesRestored: result.tablesRestored,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: `Gagal memulihkan database: ${err.message}` },
      { status: 500 }
    );
  }
}

/**
 * DELETE: Menghapus berkas cadangan database
 */
export async function DELETE(req: NextRequest) {
  const auth = await verifyDeveloperAccess();
  if (!auth.authorized) {
    return NextResponse.json({ success: false, error: auth.error }, { status: 403 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const fileName = searchParams.get('fileName');

    if (!fileName) {
      return NextResponse.json({ success: false, error: 'Parameter fileName wajib disertakan' }, { status: 400 });
    }

    deleteDatabaseBackup(fileName);
    return NextResponse.json({
      success: true,
      message: `Berkas cadangan ${fileName} berhasil dihapus.`,
    });
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: `Gagal menghapus file cadangan: ${err.message}` },
      { status: 500 }
    );
  }
}
