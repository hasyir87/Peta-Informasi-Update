import React from 'react';
import { cookies } from 'next/headers';
import MapViewWrapper from '@/components/MapViewWrapper';
import { getMapsAsync, getCategoriesAsync, getSettingsAsync } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const maps = await getMapsAsync();
  const categories = await getCategoriesAsync();
  const settings = await getSettingsAsync();

  let isLoggedInServer = false;
  try {
    const cookieStore = await cookies();
    const authToken = cookieStore.get('wkr_auth_token')?.value;
    const userId = cookieStore.get('wkr_user_id')?.value;
    isLoggedInServer = Boolean(authToken && userId);
  } catch {
    // Ignore cookie read error during static generation
  }

  return (
    <main className="w-full h-[100dvh] min-h-[100dvh] max-h-[100dvh] overflow-hidden">
      <MapViewWrapper
        initialMaps={maps}
        initialCategories={categories}
        initialSettings={settings}
        isLoggedInServer={isLoggedInServer}
      />
    </main>
  );
}

