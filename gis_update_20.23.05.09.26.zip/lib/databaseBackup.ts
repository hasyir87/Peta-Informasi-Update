import fs from 'fs';
import path from 'path';
import {
  isMySQLAvailable,
  isMySQLConfigured,
  queryMySQL,
  execMySQL,
  getMySQLConfig,
} from './mysql';
import {
  getCategoriesAsync,
  getMapsAsync,
  getUsersAsync,
  getSettingsAsync,
  getActivityLogs,
} from './db';
import { getAppVersion } from './version';

export interface DatabaseBackupMeta {
  fileName: string;
  filePath: string;
  createdAt: string;
  formattedDate: string;
  sizeBytes: number;
  formattedSize: string;
  version: string;
  source: 'mysql' | 'active_store';
  sourceLabel: string;
  records: {
    categories: number;
    maps: number;
    users: number;
    settings: number;
    logs: number;
    total: number;
  };
  notes?: string;
}

const BACKUP_DIR = path.join(process.cwd(), 'backups', 'database');

function ensureBackupDir(): string {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
  return BACKUP_DIR;
}

function escapeSqlValue(val: any): string {
  if (val === null || val === undefined) return 'NULL';
  if (typeof val === 'number') return isFinite(val) ? String(val) : 'NULL';
  if (typeof val === 'boolean') return val ? '1' : '0';
  if (val instanceof Date) {
    return `'${val.toISOString().slice(0, 19).replace('T', ' ')}'`;
  }
  let str: string;
  if (typeof val === 'object') {
    str = JSON.stringify(val);
  } else {
    str = String(val);
  }
  str = str
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\0/g, '\\0')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r');
  return `'${str}'`;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function getFormattedCurrentDate(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${day} ${month} ${year}, ${hours}:${minutes}:${seconds} WIB`;
}

/**
 * Mengambil ringkasan statistik database saat ini
 */
export async function getDatabaseStats(): Promise<{
  configured: boolean;
  available: boolean;
  modeLabel: string;
  host?: string;
  databaseName?: string;
  counts: {
    categories: number;
    maps: number;
    users: number;
    settings: number;
    logs: number;
    total: number;
  };
}> {
  const configured = isMySQLConfigured();
  const available = isMySQLAvailable();
  const config = getMySQLConfig();

  let categoriesCount = 0;
  let mapsCount = 0;
  let usersCount = 0;
  let settingsCount = 0;
  let logsCount = 0;

  if (available) {
    try {
      const [rCat, rMap, rUser, rSet, rLog] = await Promise.all([
        queryMySQL<{ cnt: number }>('SELECT COUNT(*) as cnt FROM categories').catch(() => [{ cnt: 0 }]),
        queryMySQL<{ cnt: number }>('SELECT COUNT(*) as cnt FROM spatial_maps').catch(() => [{ cnt: 0 }]),
        queryMySQL<{ cnt: number }>('SELECT COUNT(*) as cnt FROM users').catch(() => [{ cnt: 0 }]),
        queryMySQL<{ cnt: number }>('SELECT COUNT(*) as cnt FROM site_settings').catch(() => [{ cnt: 0 }]),
        queryMySQL<{ cnt: number }>('SELECT COUNT(*) as cnt FROM activity_logs').catch(() => [{ cnt: 0 }]),
      ]);
      categoriesCount = Number(rCat[0]?.cnt || 0);
      mapsCount = Number(rMap[0]?.cnt || 0);
      usersCount = Number(rUser[0]?.cnt || 0);
      settingsCount = Number(rSet[0]?.cnt || 0);
      logsCount = Number(rLog[0]?.cnt || 0);
    } catch {
      // fallback to async stores
      const [c, m, u, s, l] = await Promise.all([
        getCategoriesAsync(),
        getMapsAsync(),
        getUsersAsync(true),
        getSettingsAsync(),
        getActivityLogs(1000),
      ]);
      categoriesCount = c.length;
      mapsCount = m.length;
      usersCount = u.length;
      settingsCount = Object.keys(s).length;
      logsCount = l.length;
    }
  } else {
    const [c, m, u, s, l] = await Promise.all([
      getCategoriesAsync(),
      getMapsAsync(),
      getUsersAsync(true),
      getSettingsAsync(),
      getActivityLogs(1000),
    ]);
    categoriesCount = c.length;
    mapsCount = m.length;
    usersCount = u.length;
    settingsCount = Object.keys(s).length;
    logsCount = l.length;
  }

  return {
    configured,
    available,
    modeLabel: available ? 'MySQL Server Terhubung (Online)' : 'In-Memory / Failover Active Store',
    host: config?.host || (config?.uri ? 'Database URI' : 'Local Host'),
    databaseName: config?.database || 'walhisum_gis',
    counts: {
      categories: categoriesCount,
      maps: mapsCount,
      users: usersCount,
      settings: settingsCount,
      logs: logsCount,
      total: categoriesCount + mapsCount + usersCount + settingsCount + logsCount,
    },
  };
}

/**
 * Membuat file dump SQL cadangan database (.SQL)
 */
export async function createDatabaseBackup(notes: string = 'Cadangan database manual dari Konsol Developer'): Promise<DatabaseBackupMeta> {
  const dir = ensureBackupDir();
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10);
  const timeStr = now.toTimeString().slice(0, 8).replace(/:/g, '-');
  const appVer = getAppVersion();

  const fileName = `backup_db_walhisumut_${dateStr}_${timeStr}.sql`;
  const filePath = path.join(dir, fileName);
  const metaFileName = `${fileName}.meta.json`;
  const metaFilePath = path.join(dir, metaFileName);

  const available = isMySQLAvailable();
  let categoriesData: any[] = [];
  let mapsData: any[] = [];
  let usersData: any[] = [];
  let settingsData: any[] = [];
  let logsData: any[] = [];

  if (available) {
    try {
      categoriesData = await queryMySQL('SELECT * FROM categories ORDER BY sort_order ASC, created_at ASC').catch(() => []);
      mapsData = await queryMySQL('SELECT * FROM spatial_maps ORDER BY sort_order ASC, created_at ASC').catch(() => []);
      usersData = await queryMySQL('SELECT * FROM users ORDER BY created_at ASC').catch(() => []);
      settingsData = await queryMySQL('SELECT * FROM site_settings ORDER BY setting_key ASC').catch(() => []);
      logsData = await queryMySQL('SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 500').catch(() => []);
    } catch {
      // fallback
    }
  }

  // Jika MySQL kosong atau offline, ambil dari active memory store
  if (categoriesData.length === 0) {
    const cats = await getCategoriesAsync();
    categoriesData = cats.map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      description: c.description,
      color: c.color,
      stroke_color: c.strokeColor,
      fill_opacity: c.fillOpacity,
      icon: c.icon,
      subcategories_json: JSON.stringify(c.subcategories || []),
      sort_order: 0,
      created_at: new Date(),
      updated_at: new Date(),
    }));
  }

  if (mapsData.length === 0) {
    const maps = await getMapsAsync();
    mapsData = maps.map((m) => ({
      id: m.id,
      name: m.name,
      description: m.description,
      address: m.address,
      desa: m.desa,
      kecamatan: m.kecamatan,
      kabupaten: m.kabupaten,
      category_id: m.categoryId,
      subcategory_id: m.subcategoryId,
      geom_type: m.type || 'Polygon',
      latitude: m.latitude,
      longitude: m.longitude,
      area_ha: m.areaHa,
      kk_count: m.kkCount,
      proses: m.proses,
      pengelola: m.pengelola,
      komoditi: m.komoditi,
      pendamping: m.pendamping,
      sk_legalitas: m.skLegalitas,
      sk_nomor: m.skNomor,
      tahun: m.tahun,
      tahun_penetapan: m.tahunPenetapan,
      status: m.status,
      image_url: m.imageUrl,
      kontak: m.kontak,
      raw_geojson: JSON.stringify(m.geometry || {}),
      geojson_data: JSON.stringify(m.geometry || {}),
      created_at: m.createdAt || new Date(),
      updated_at: m.updatedAt || new Date(),
    }));
  }

  if (usersData.length === 0) {
    const users = await getUsersAsync(true);
    usersData = users.map((u) => ({
      id: u.id,
      full_name: u.fullName,
      username: u.username,
      email: u.email,
      password_hash: (u as any).passwordHash || '$2a$10$rN7x7Yd27Z3sRzLKnZfNneW4.rG0LdO6YtqJpLg4bW9D.Qj1C5Mla',
      roles: JSON.stringify(u.roles || ['user']),
      role: u.roles?.[0] || 'user',
      is_active: u.isActive !== false ? 1 : 0,
      avatar: u.avatar || null,
      created_at: u.createdAt || new Date(),
      updated_at: u.updatedAt || new Date(),
    }));
  }

  if (settingsData.length === 0) {
    const settings = await getSettingsAsync();
    settingsData = Object.entries(settings).map(([k, v]) => ({
      setting_key: k,
      setting_value: typeof v === 'string' ? JSON.stringify(v) : JSON.stringify(v),
      updated_at: new Date(),
    }));
  }

  if (logsData.length === 0) {
    const logs = getActivityLogs(200);
    logsData = logs.map((l) => ({
      id: l.id,
      user_name: l.userName,
      user_email: l.userEmail,
      action: l.action,
      entity: l.entity,
      entity_id: l.entityId,
      description: l.description,
      details: l.details,
      created_at: l.createdAt,
    }));
  }

  // Bangun konten SQL DUMP
  const sqlLines: string[] = [
    '-- =========================================================================',
    '-- CADANGAN BASIS DATA SIG WILAYAH KELOLA RAKYAT (WKR) WALHI SUMATERA UTARA',
    `-- Tanggal Pembuatan  : ${getFormattedCurrentDate(now)}`,
    `-- Versi Aplikasi     : ${appVer.version} (${appVer.versionName})`,
    `-- Sumber Data       : ${available ? 'MySQL Database Live Server' : 'Active Store Memory / Sync Cache'}`,
    `-- Catatan Cadangan   : ${notes}`,
    '-- =========================================================================',
    '',
    'SET FOREIGN_KEY_CHECKS = 0;',
    'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";',
    'SET AUTOCOMMIT = 0;',
    'START TRANSACTION;',
    'SET time_zone = "+07:00";',
    '/*!40101 SET NAMES utf8mb4 */;',
    '',
  ];

  // 1. Categories
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('-- TABEL: categories');
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('CREATE TABLE IF NOT EXISTS `categories` (');
  sqlLines.push('  `id` VARCHAR(50) NOT NULL,');
  sqlLines.push('  `name` VARCHAR(100) NOT NULL,');
  sqlLines.push('  `slug` VARCHAR(100) NOT NULL,');
  sqlLines.push('  `description` TEXT DEFAULT NULL,');
  sqlLines.push('  `color` VARCHAR(20) NOT NULL DEFAULT "#0d6efd",');
  sqlLines.push('  `stroke_color` VARCHAR(20) DEFAULT "#0a58ca",');
  sqlLines.push('  `fill_opacity` DECIMAL(3,2) DEFAULT 0.60,');
  sqlLines.push('  `icon` VARCHAR(50) DEFAULT "MapPin",');
  sqlLines.push('  `subcategories_json` LONGTEXT DEFAULT NULL,');
  sqlLines.push('  `sort_order` INT(11) DEFAULT 0,');
  sqlLines.push('  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,');
  sqlLines.push('  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,');
  sqlLines.push('  PRIMARY KEY (`id`),');
  sqlLines.push('  UNIQUE KEY `uk_categories_slug` (`slug`)');
  sqlLines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  sqlLines.push('');

  if (categoriesData.length > 0) {
    sqlLines.push('INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `color`, `stroke_color`, `fill_opacity`, `icon`, `subcategories_json`, `sort_order`) VALUES');
    const catRows = categoriesData.map((c) => {
      return `(${escapeSqlValue(c.id)}, ${escapeSqlValue(c.name)}, ${escapeSqlValue(c.slug)}, ${escapeSqlValue(c.description)}, ${escapeSqlValue(c.color)}, ${escapeSqlValue(c.stroke_color)}, ${c.fill_opacity !== undefined ? Number(c.fill_opacity) : 0.6}, ${escapeSqlValue(c.icon)}, ${escapeSqlValue(c.subcategories_json)}, ${c.sort_order || 0})`;
    });
    sqlLines.push(catRows.join(',\n') + ';');
  }
  sqlLines.push('');

  // 2. Users
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('-- TABEL: users');
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('CREATE TABLE IF NOT EXISTS `users` (');
  sqlLines.push('  `id` VARCHAR(50) NOT NULL,');
  sqlLines.push('  `full_name` VARCHAR(150) NOT NULL,');
  sqlLines.push('  `username` VARCHAR(80) NOT NULL,');
  sqlLines.push('  `email` VARCHAR(150) NOT NULL,');
  sqlLines.push('  `password_hash` VARCHAR(255) NOT NULL,');
  sqlLines.push('  `roles` JSON NOT NULL,');
  sqlLines.push('  `role` VARCHAR(50) DEFAULT "admin",');
  sqlLines.push('  `is_active` TINYINT(1) DEFAULT 1,');
  sqlLines.push('  `avatar` VARCHAR(255) DEFAULT NULL,');
  sqlLines.push('  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,');
  sqlLines.push('  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,');
  sqlLines.push('  PRIMARY KEY (`id`),');
  sqlLines.push('  UNIQUE KEY `uk_users_username` (`username`),');
  sqlLines.push('  UNIQUE KEY `uk_users_email` (`email`)');
  sqlLines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  sqlLines.push('');

  if (usersData.length > 0) {
    sqlLines.push('INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `password_hash`, `roles`, `role`, `is_active`, `avatar`) VALUES');
    const uRows = usersData.map((u) => {
      const rolesJson = typeof u.roles === 'string' ? u.roles : JSON.stringify(u.roles || ['user']);
      return `(${escapeSqlValue(u.id)}, ${escapeSqlValue(u.full_name)}, ${escapeSqlValue(u.username)}, ${escapeSqlValue(u.email)}, ${escapeSqlValue(u.password_hash)}, ${escapeSqlValue(rolesJson)}, ${escapeSqlValue(u.role || 'user')}, ${u.is_active ? 1 : 0}, ${escapeSqlValue(u.avatar)})`;
    });
    sqlLines.push(uRows.join(',\n') + ';');
  }
  sqlLines.push('');

  // 3. Spatial Maps
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('-- TABEL: spatial_maps');
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('CREATE TABLE IF NOT EXISTS `spatial_maps` (');
  sqlLines.push('  `id` VARCHAR(50) NOT NULL,');
  sqlLines.push('  `name` VARCHAR(200) NOT NULL,');
  sqlLines.push('  `description` TEXT DEFAULT NULL,');
  sqlLines.push('  `address` TEXT DEFAULT NULL,');
  sqlLines.push('  `desa` VARCHAR(100) DEFAULT NULL,');
  sqlLines.push('  `kecamatan` VARCHAR(100) DEFAULT NULL,');
  sqlLines.push('  `kabupaten` VARCHAR(100) DEFAULT NULL,');
  sqlLines.push('  `category_id` VARCHAR(50) DEFAULT NULL,');
  sqlLines.push('  `subcategory_id` VARCHAR(50) DEFAULT NULL,');
  sqlLines.push('  `geom_type` VARCHAR(30) NOT NULL DEFAULT "Polygon",');
  sqlLines.push('  `latitude` DECIMAL(10, 6) DEFAULT NULL,');
  sqlLines.push('  `longitude` DECIMAL(10, 6) DEFAULT NULL,');
  sqlLines.push('  `area_ha` DECIMAL(12, 2) DEFAULT 0.00,');
  sqlLines.push('  `kk_count` INT(11) DEFAULT 0,');
  sqlLines.push('  `proses` TEXT DEFAULT NULL,');
  sqlLines.push('  `pengelola` VARCHAR(200) DEFAULT NULL,');
  sqlLines.push('  `komoditi` VARCHAR(255) DEFAULT NULL,');
  sqlLines.push('  `pendamping` VARCHAR(255) DEFAULT NULL,');
  sqlLines.push('  `sk_legalitas` VARCHAR(200) DEFAULT NULL,');
  sqlLines.push('  `sk_nomor` VARCHAR(128) DEFAULT NULL,');
  sqlLines.push('  `tahun` INT(11) DEFAULT NULL,');
  sqlLines.push('  `tahun_penetapan` VARCHAR(32) DEFAULT NULL,');
  sqlLines.push('  `status` VARCHAR(20) NOT NULL DEFAULT "Active",');
  sqlLines.push('  `image_url` TEXT DEFAULT NULL,');
  sqlLines.push('  `kontak` VARCHAR(255) DEFAULT NULL,');
  sqlLines.push('  `raw_geojson` LONGTEXT DEFAULT NULL,');
  sqlLines.push('  `geojson_data` LONGTEXT DEFAULT NULL,');
  sqlLines.push('  `sort_order` INT(11) DEFAULT 0,');
  sqlLines.push('  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,');
  sqlLines.push('  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,');
  sqlLines.push('  PRIMARY KEY (`id`),');
  sqlLines.push('  KEY `idx_spatial_category` (`category_id`),');
  sqlLines.push('  KEY `idx_spatial_kabupaten` (`kabupaten`),');
  sqlLines.push('  KEY `idx_spatial_status` (`status`)');
  sqlLines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  sqlLines.push('');

  if (mapsData.length > 0) {
    sqlLines.push('INSERT INTO `spatial_maps` (');
    sqlLines.push('  `id`, `name`, `description`, `address`, `desa`, `kecamatan`, `kabupaten`,');
    sqlLines.push('  `category_id`, `subcategory_id`, `geom_type`, `latitude`, `longitude`, `area_ha`,');
    sqlLines.push('  `kk_count`, `proses`, `pengelola`, `komoditi`, `pendamping`, `sk_legalitas`, `sk_nomor`,');
    sqlLines.push('  `tahun`, `tahun_penetapan`, `status`, `image_url`, `kontak`, `raw_geojson`, `geojson_data`');
    sqlLines.push(') VALUES');

    const mRows = mapsData.map((m) => {
      return `(${escapeSqlValue(m.id)}, ${escapeSqlValue(m.name)}, ${escapeSqlValue(m.description)}, ${escapeSqlValue(m.address)}, ${escapeSqlValue(m.desa)}, ${escapeSqlValue(m.kecamatan)}, ${escapeSqlValue(m.kabupaten)}, ${escapeSqlValue(m.category_id)}, ${escapeSqlValue(m.subcategory_id)}, ${escapeSqlValue(m.geom_type || 'Polygon')}, ${m.latitude ? Number(m.latitude) : 'NULL'}, ${m.longitude ? Number(m.longitude) : 'NULL'}, ${m.area_ha ? Number(m.area_ha) : 0}, ${m.kk_count ? Number(m.kk_count) : 0}, ${escapeSqlValue(m.proses)}, ${escapeSqlValue(m.pengelola)}, ${escapeSqlValue(m.komoditi)}, ${escapeSqlValue(m.pendamping)}, ${escapeSqlValue(m.sk_legalitas)}, ${escapeSqlValue(m.sk_nomor)}, ${m.tahun ? Number(m.tahun) : 'NULL'}, ${escapeSqlValue(m.tahun_penetapan)}, ${escapeSqlValue(m.status || 'Active')}, ${escapeSqlValue(m.image_url)}, ${escapeSqlValue(m.kontak)}, ${escapeSqlValue(m.raw_geojson)}, ${escapeSqlValue(m.geojson_data)})`;
    });
    sqlLines.push(mRows.join(',\n') + ';');
  }
  sqlLines.push('');

  // 4. Site Settings
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('-- TABEL: site_settings');
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('CREATE TABLE IF NOT EXISTS `site_settings` (');
  sqlLines.push('  `setting_key` VARCHAR(100) NOT NULL,');
  sqlLines.push('  `setting_value` LONGTEXT NOT NULL,');
  sqlLines.push('  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,');
  sqlLines.push('  PRIMARY KEY (`setting_key`)');
  sqlLines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  sqlLines.push('');

  if (settingsData.length > 0) {
    sqlLines.push('INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES');
    const sRows = settingsData.map((s) => {
      const val = typeof s.setting_value === 'string' ? s.setting_value : JSON.stringify(s.setting_value);
      return `(${escapeSqlValue(s.setting_key)}, ${escapeSqlValue(val)})`;
    });
    sqlLines.push(sRows.join(',\n') + ';');
  }
  sqlLines.push('');

  // 5. Activity Logs
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('-- TABEL: activity_logs');
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('CREATE TABLE IF NOT EXISTS `activity_logs` (');
  sqlLines.push('  `id` VARCHAR(50) NOT NULL,');
  sqlLines.push('  `user_name` VARCHAR(150) NOT NULL,');
  sqlLines.push('  `user_email` VARCHAR(150) DEFAULT NULL,');
  sqlLines.push('  `action` VARCHAR(30) NOT NULL,');
  sqlLines.push('  `entity` VARCHAR(50) NOT NULL DEFAULT "system",');
  sqlLines.push('  `entity_id` VARCHAR(50) DEFAULT NULL,');
  sqlLines.push('  `description` TEXT NOT NULL,');
  sqlLines.push('  `details` TEXT DEFAULT NULL,');
  sqlLines.push('  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,');
  sqlLines.push('  PRIMARY KEY (`id`),');
  sqlLines.push('  KEY `idx_activity_created` (`created_at`),');
  sqlLines.push('  KEY `idx_activity_user` (`user_name`)');
  sqlLines.push(') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
  sqlLines.push('');

  if (logsData.length > 0) {
    sqlLines.push('INSERT INTO `activity_logs` (`id`, `user_name`, `user_email`, `action`, `entity`, `entity_id`, `description`, `details`, `created_at`) VALUES');
    const lRows = logsData.map((l) => {
      const dt = l.created_at ? new Date(l.created_at).toISOString().slice(0, 19).replace('T', ' ') : new Date().toISOString().slice(0, 19).replace('T', ' ');
      return `(${escapeSqlValue(l.id)}, ${escapeSqlValue(l.user_name)}, ${escapeSqlValue(l.user_email)}, ${escapeSqlValue(l.action)}, ${escapeSqlValue(l.entity || 'system')}, ${escapeSqlValue(l.entity_id)}, ${escapeSqlValue(l.description)}, ${escapeSqlValue(l.details)}, '${dt}')`;
    });
    sqlLines.push(lRows.join(',\n') + ';');
  }
  sqlLines.push('');

  // 6. Views
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('-- VIEW: wkr_areas & app_settings');
  sqlLines.push('-- ---------------------------------------------------------');
  sqlLines.push('CREATE OR REPLACE VIEW `wkr_areas` AS');
  sqlLines.push('SELECT `id`, `name` AS `nama_kawasan`, `category_id`, `kabupaten`, `kecamatan`, `desa`,');
  sqlLines.push('  `area_ha` AS `luas_ha`, `kk_count` AS `jumlah_kk`, `proses`, `komoditi` AS `komoditas_utama`,');
  sqlLines.push('  `sk_legalitas` AS `sk_hukum`, `sk_nomor` AS `nomor_sk`, `tahun`, `description` AS `deskripsi`,');
  sqlLines.push('  `latitude`, `longitude`, `geojson_data` AS `geojson`, `image_url` AS `foto_kawasan`, `status`');
  sqlLines.push('FROM `spatial_maps`;');
  sqlLines.push('');
  sqlLines.push('CREATE OR REPLACE VIEW `app_settings` AS');
  sqlLines.push('SELECT `setting_key` AS `key_name`, `setting_value` AS `value_json`, `updated_at`');
  sqlLines.push('FROM `site_settings`;');
  sqlLines.push('');

  sqlLines.push('COMMIT;');
  sqlLines.push('SET FOREIGN_KEY_CHECKS = 1;');
  sqlLines.push('');

  const sqlContent = sqlLines.join('\n');
  fs.writeFileSync(filePath, sqlContent, 'utf-8');

  const stat = fs.statSync(filePath);
  const metadata: DatabaseBackupMeta = {
    fileName,
    filePath,
    createdAt: now.toISOString(),
    formattedDate: getFormattedCurrentDate(now),
    sizeBytes: stat.size,
    formattedSize: formatBytes(stat.size),
    version: appVer.version,
    source: available ? 'mysql' : 'active_store',
    sourceLabel: available ? 'MySQL Server Live' : 'Active Store Sync',
    records: {
      categories: categoriesData.length,
      maps: mapsData.length,
      users: usersData.length,
      settings: settingsData.length,
      logs: logsData.length,
      total: categoriesData.length + mapsData.length + usersData.length + settingsData.length + logsData.length,
    },
    notes,
  };

  fs.writeFileSync(metaFilePath, JSON.stringify(metadata, null, 2), 'utf-8');
  return metadata;
}

/**
 * Mendapatkan daftar seluruh file backup database yang tersimpan
 */
export function listDatabaseBackups(): DatabaseBackupMeta[] {
  const dir = ensureBackupDir();
  const files = fs.readdirSync(dir);
  const backups: DatabaseBackupMeta[] = [];

  for (const f of files) {
    if (f.endsWith('.sql')) {
      const fullPath = path.join(dir, f);
      const metaPath = path.join(dir, `${f}.meta.json`);
      let meta: Partial<DatabaseBackupMeta> = {};

      if (fs.existsSync(metaPath)) {
        try {
          meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
        } catch {}
      }

      const stat = fs.statSync(fullPath);
      const birth = stat.birthtime || stat.mtime;

      backups.push({
        fileName: f,
        filePath: fullPath,
        createdAt: meta.createdAt || birth.toISOString(),
        formattedDate: meta.formattedDate || getFormattedCurrentDate(birth),
        sizeBytes: stat.size,
        formattedSize: formatBytes(stat.size),
        version: meta.version || 'v05.09.2026',
        source: meta.source || 'mysql',
        sourceLabel: meta.sourceLabel || (meta.source === 'mysql' ? 'MySQL Server Live' : 'Active Store Sync'),
        records: meta.records || {
          categories: 0,
          maps: 0,
          users: 0,
          settings: 0,
          logs: 0,
          total: 0,
        },
        notes: meta.notes,
      });
    }
  }

  // Urutkan dari yang terbaru ke terlama
  return backups.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

/**
 * Membaca isi file backup database (untuk download/stream)
 */
export function getDatabaseBackupFile(fileName: string): { content: Buffer; meta: DatabaseBackupMeta | null } {
  const safeName = path.basename(fileName);
  const dir = ensureBackupDir();
  const filePath = path.join(dir, safeName);

  if (!fs.existsSync(filePath)) {
    throw new Error(`Berkas cadangan tidak ditemukan: ${safeName}`);
  }

  const content = fs.readFileSync(filePath);
  const metaPath = path.join(dir, `${safeName}.meta.json`);
  let meta: DatabaseBackupMeta | null = null;
  if (fs.existsSync(metaPath)) {
    try {
      meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
    } catch {}
  }

  return { content, meta };
}

/**
 * Menghapus file backup database
 */
export function deleteDatabaseBackup(fileName: string): boolean {
  const safeName = path.basename(fileName);
  const dir = ensureBackupDir();
  const filePath = path.join(dir, safeName);
  const metaPath = path.join(dir, `${safeName}.meta.json`);

  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
  if (fs.existsSync(metaPath)) {
    fs.unlinkSync(metaPath);
  }
  return true;
}

/**
 * Memulihkan database dari file backup SQL yang dipilih
 */
export async function restoreDatabaseFromBackup(fileName: string): Promise<{
  success: boolean;
  message: string;
  executedQueries: number;
  tablesRestored: string[];
}> {
  const safeName = path.basename(fileName);
  const dir = ensureBackupDir();
  const filePath = path.join(dir, safeName);

  if (!fs.existsSync(filePath)) {
    throw new Error(`Berkas cadangan database tidak ditemukan: ${safeName}`);
  }

  const sqlContent = fs.readFileSync(filePath, 'utf-8');

  // Bersihkan komentar dan bagi menjadi statements
  const statements: string[] = [];
  const lines = sqlContent.split(/\r?\n/);
  let currentStmt = '';

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('--') || trimmed.startsWith('/*')) {
      continue;
    }
    currentStmt += ' ' + line;
    if (trimmed.endsWith(';')) {
      statements.push(currentStmt.trim());
      currentStmt = '';
    }
  }
  if (currentStmt.trim()) {
    statements.push(currentStmt.trim());
  }

  const available = isMySQLAvailable();
  let executedCount = 0;
  const tables = ['categories', 'users', 'spatial_maps', 'site_settings', 'activity_logs'];

  if (available) {
    for (const stmt of statements) {
      if (!stmt) continue;
      try {
        await execMySQL(stmt);
        executedCount++;
      } catch (err: any) {
        console.warn(`[restore] Warning executing statement: ${stmt.slice(0, 60)}... (${err.message})`);
      }
    }
  }

  // Refresh in-memory stores agar perubahan langsung tercermin tanpa restart server
  try {
    await Promise.all([
      getCategoriesAsync(),
      getMapsAsync(),
      getUsersAsync(true),
      getSettingsAsync(),
    ]);
  } catch {}

  return {
    success: true,
    message: `Database berhasil dipulihkan dari ${safeName}. ${executedCount > 0 ? `${executedCount} query SQL berhasil dieksekusi ke MySQL.` : 'Data aktif berhasil dimuat ke cache memori.'}`,
    executedQueries: executedCount,
    tablesRestored: tables,
  };
}
