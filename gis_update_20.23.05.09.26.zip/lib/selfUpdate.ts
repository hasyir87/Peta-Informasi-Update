import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import {
  getAppVersion,
  recordNewVersion,
  recordRollbackVersion,
  formatVersionFromDate,
  formatFriendlyDate,
} from './version';
import { isMySQLConfigured, isMySQLAvailable, execMySQL } from './mysql';

export interface InspectionResult {
  isValid: boolean;
  error?: string;
  files: string[];
  sqlFiles: string[];
  targetVersion: string;
  targetVersionName: string;
  totalSize: number;
  notes?: string;
}

export interface UpdateExecutionResult {
  success: boolean;
  message: string;
  previousVersion: string;
  newVersion: string;
  backupFile: string;
  updatedFiles: string[];
  executedSql: string[];
  error?: string;
}

const BACKUP_DIR_NAME = 'backups';

function getBackupDir(): string {
  const dir = path.join(process.cwd(), BACKUP_DIR_NAME);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

/**
 * Memeriksa apakah path aman dan tidak melakukan Zip-Slip (Directory Traversal)
 */
function isSafePath(rootPath: string, targetPath: string): boolean {
  const resolved = path.resolve(rootPath, targetPath);
  return resolved.startsWith(rootPath);
}

/**
 * 1. Inspeksi isi paket ZIP pembaruan sebelum dieksekusi
 */
export async function inspectUpdateZip(
  zipBuffer: Buffer,
  explicitVersion?: string
): Promise<InspectionResult> {
  try {
    const zip = await JSZip.loadAsync(zipBuffer);
    const files: string[] = [];
    const sqlFiles: string[] = [];
    let totalSize = 0;
    let detectedNotes = '';
    let detectedVersion = explicitVersion || '';
    let detectedVersionName = '';

    const rootPath = process.cwd();

    for (const [relPath, entry] of Object.entries(zip.files)) {
      // Abaikan folder, mac metadata, dan file terlarang
      if (entry.dir) continue;
      if (relPath.includes('__MACOSX') || relPath.includes('.DS_Store')) continue;
      if (relPath.startsWith('/') || relPath.startsWith('\\')) continue;

      if (!isSafePath(rootPath, relPath)) {
        return {
          isValid: false,
          error: `Keamanan ditolak: File ${relPath} mencoba keluar dari direktori root.`,
          files: [],
          sqlFiles: [],
          targetVersion: '',
          targetVersionName: '',
          totalSize: 0,
        };
      }

      files.push(relPath);

      // Cek apakah ada file SQL migrasi
      if (relPath.endsWith('.sql')) {
        sqlFiles.push(relPath);
      }

      // Baca data versi dari version.json di dalam zip jika ada
      if (relPath === 'version.json') {
        try {
          const txt = await entry.async('string');
          const parsed = JSON.parse(txt);
          if (parsed && parsed.version && !detectedVersion) {
            detectedVersion = parsed.version;
          }
          if (parsed && parsed.versionName) {
            detectedVersionName = parsed.versionName;
          }
          if (parsed && parsed.notes && !detectedNotes) {
            detectedNotes = parsed.notes;
          }
        } catch {}
      }

      // Baca catatan dari PANDUAN_UPDATE.md atau README.md jika ada
      if (relPath === 'PANDUAN_UPDATE.md' || relPath === 'README.md') {
        try {
          const txt = await entry.async('string');
          const firstLine = txt.split('\n')[0]?.replace(/[#*`]/g, '').trim();
          if (firstLine && !detectedNotes) detectedNotes = firstLine;
        } catch {}
      }
    }

    if (files.length === 0) {
      return {
        isValid: false,
        error: 'Berkas ZIP kosong atau tidak berisi file pembaruan yang valid.',
        files: [],
        sqlFiles: [],
        targetVersion: '',
        targetVersionName: '',
        totalSize: 0,
      };
    }

    const now = new Date();
    const finalVersion = detectedVersion || formatVersionFromDate(now);
    const finalVersionName = detectedVersionName || formatFriendlyDate(now, finalVersion);

    return {
      isValid: true,
      files,
      sqlFiles,
      targetVersion: finalVersion,
      targetVersionName: finalVersionName,
      totalSize: zipBuffer.length,
      notes: detectedNotes || `Pembaruan sistem versi ${finalVersion}`,
    };
  } catch (err: any) {
    return {
      isValid: false,
      error: `Gagal membaca arsip ZIP: ${err.message}`,
      files: [],
      sqlFiles: [],
      targetVersion: '',
      targetVersionName: '',
      totalSize: 0,
    };
  }
}

/**
 * 2. Membuat file cadangan (backup) otomatis sebelum file ditimpa
 */
export async function createBackupArchive(
  filesToBackup: string[],
  currentVersion: string
): Promise<{ fullPath: string; fileName: string }> {
  const backupDir = getBackupDir();
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const safeVersion = currentVersion.replace(/[^a-zA-Z0-9.-]/g, '_');
  const fileName = `backup_${safeVersion}_${timestamp}.zip`;
  const fullPath = path.join(backupDir, fileName);

  const backupZip = new JSZip();
  const rootDir = process.cwd();

  // Selalu sertakan version.json di backup
  const allBackupTargets = Array.from(new Set([...filesToBackup, 'version.json']));

  for (const relPath of allBackupTargets) {
    const filePath = path.join(rootDir, relPath);
    if (fs.existsSync(filePath)) {
      try {
        const stat = fs.statSync(filePath);
        if (stat.isFile()) {
          const content = fs.readFileSync(filePath);
          backupZip.file(relPath, content);
        }
      } catch (err) {
        console.warn(`Gagal mencadangkan file ${relPath}:`, err);
      }
    }
  }

  const zipBuffer = await backupZip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  fs.writeFileSync(fullPath, zipBuffer);
  return { fullPath, fileName };
}

/**
 * 3. Eksekusi file migrasi database (.sql)
 */
export async function executeSqlMigration(sqlContent: string): Promise<string[]> {
  const executed: string[] = [];

  // Jika MySQL tidak dikonfigurasikan atau offline, lewati eksekusi SQL secara aman
  if (!isMySQLConfigured() || !isMySQLAvailable()) {
    console.info('[SelfUpdate] MySQL tidak aktif, melewati migrasi SQL fisik (menggunakan in-memory / fallback).');
    return ['MySQL offline - migrasi dilewati (mode fallback aktif)'];
  }

  // Bersihkan komentar SQL
  const cleaned = sqlContent
    .replace(/\/\*[\s\S]*?\*\//g, '') // hapus blok komentar /* */
    .replace(/--.*$/gm, '') // hapus komentar baris --
    .trim();

  // Pisahkan query berdasarkan delimiter titik-koma (;)
  const queries = cleaned
    .split(';')
    .map((q) => q.trim())
    .filter((q) => q.length > 0);

  for (const query of queries) {
    try {
      await execMySQL(query);
      executed.push(query.substring(0, 60) + (query.length > 60 ? '...' : ''));
    } catch (err: any) {
      // Abaikan jika error field duplicate atau table already exists
      const msg = err.message || '';
      if (
        msg.includes('Duplicate column name') ||
        msg.includes('already exists') ||
        msg.includes('Unknown table')
      ) {
        console.warn(`[SelfUpdate SQL Notice] ${msg}`);
      } else {
        console.error(`[SelfUpdate SQL Error] Query: ${query}`, err);
        throw err;
      }
    }
  }

  return executed;
}

/**
 * 4. Terapkan Pembaruan Mandiri dari Berkas ZIP (Dengan Auto-Rollback jika gagal)
 */
export async function applyUpdateFromZip(
  zipBuffer: Buffer,
  customNotes?: string,
  explicitVersion?: string
): Promise<UpdateExecutionResult> {
  const rootDir = process.cwd();
  const currentVersionData = getAppVersion();
  const previousVersion = currentVersionData.version;

  // 1. Periksa berkas ZIP
  const inspection = await inspectUpdateZip(zipBuffer, explicitVersion);
  if (!inspection.isValid) {
    throw new Error(inspection.error || 'Berkas ZIP tidak valid');
  }

  // 2. Buat backup otomatis dari file yang akan ditimpa
  const { fileName: backupFileName } = await createBackupArchive(
    inspection.files,
    previousVersion
  );

  const updatedFiles: string[] = [];
  const executedSql: string[] = [];

  try {
    const zip = await JSZip.loadAsync(zipBuffer);

    // 3. Ekstrak dan timpa file secara mandiri
    for (const relPath of inspection.files) {
      const entry = zip.file(relPath);
      if (!entry) continue;

      const targetFullPath = path.join(rootDir, relPath);
      const parentDir = path.dirname(targetFullPath);

      if (!fs.existsSync(parentDir)) {
        fs.mkdirSync(parentDir, { recursive: true });
      }

      const fileData = await entry.async('nodebuffer');
      fs.writeFileSync(targetFullPath, fileData);
      updatedFiles.push(relPath);
    }

    // 4. Jalankan migrasi SQL jika ada file .sql di dalam zip
    for (const sqlRelPath of inspection.sqlFiles) {
      const entry = zip.file(sqlRelPath);
      if (entry) {
        const sqlText = await entry.async('string');
        const sqlResult = await executeSqlMigration(sqlText);
        executedSql.push(...sqlResult);
      }
    }

    // 5. Perbarui informasi versi di version.json
    const notes = customNotes || inspection.notes || `Pembaruan sistem mandiri ${inspection.targetVersionName}`;
    const newVersionData = recordNewVersion(
      inspection.targetVersion,
      notes,
      backupFileName,
      updatedFiles.length,
      updatedFiles
    );

    return {
      success: true,
      message: `Pembaruan berhasil diterapkan secara mandiri! Versi aplikasi diperbarui ke ${newVersionData.version}.`,
      previousVersion,
      newVersion: newVersionData.version,
      backupFile: backupFileName,
      updatedFiles,
      executedSql,
    };
  } catch (updateError: any) {
    console.error('[SelfUpdate Error] Pembaruan gagal. Melakukan auto-rollback...', updateError);

    // AUTO-ROLLBACK jika terjadi kesalahan
    try {
      await rollbackToBackup(backupFileName, previousVersion);
    } catch (rollbackErr) {
      console.error('[SelfUpdate Critical] Gagal melakukan auto-rollback:', rollbackErr);
    }

    throw new Error(
      `Pembaruan gagal dan sistem secara otomatis dikembalikan ke versi cadangan sebelumnya (${previousVersion}). Rincian kesalahan: ${updateError.message}`
    );
  }
}

/**
 * 5. Kembalikan (Rollback) Aplikasi ke Versi Cadangan Sebelumnya
 */
export async function rollbackToBackup(
  backupFileName: string,
  targetVersionName?: string
): Promise<{ success: boolean; message: string; restoredFiles: string[] }> {
  const backupDir = getBackupDir();
  const backupFilePath = path.join(backupDir, backupFileName);

  if (!fs.existsSync(backupFilePath)) {
    throw new Error(`Berkas cadangan ${backupFileName} tidak ditemukan di folder backups.`);
  }

  const rootDir = process.cwd();
  const backupBuffer = fs.readFileSync(backupFilePath);
  const zip = await JSZip.loadAsync(backupBuffer);
  const restoredFiles: string[] = [];

  for (const [relPath, entry] of Object.entries(zip.files)) {
    if (entry.dir) continue;
    if (!isSafePath(rootDir, relPath)) continue;

    const targetFullPath = path.join(rootDir, relPath);
    const parentDir = path.dirname(targetFullPath);

    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }

    const fileData = await entry.async('nodebuffer');
    fs.writeFileSync(targetFullPath, fileData);
    restoredFiles.push(relPath);
  }

  // Baca versi yang direstorasi dari version.json di dalam backup
  let restoredVersion = targetVersionName;
  let friendlyName = targetVersionName || '';

  try {
    const restoredVersionFile = path.join(rootDir, 'version.json');
    if (fs.existsSync(restoredVersionFile)) {
      const vData = JSON.parse(fs.readFileSync(restoredVersionFile, 'utf-8'));
      if (vData?.version) {
        restoredVersion = vData.version;
        friendlyName = vData.versionName || vData.version;
      }
    }
  } catch {}

  recordRollbackVersion(
    restoredVersion || 'v_sebelumnya',
    friendlyName || restoredVersion || 'Versi Sebelumnya',
    backupFileName
  );

  return {
    success: true,
    message: `Aplikasi berhasil dikembalikan ke versi ${restoredVersion || 'sebelumnya'} dari cadangan ${backupFileName}.`,
    restoredFiles,
  };
}

/**
 * 6. Mendapatkan daftar berkas cadangan (backups) yang tersedia
 */
export function listAvailableBackups(): {
  fileName: string;
  sizeKb: number;
  createdAt: string;
  versionLabel: string;
}[] {
  const backupDir = getBackupDir();
  if (!fs.existsSync(backupDir)) return [];

  const files = fs.readdirSync(backupDir);
  const backups = files
    .filter((f) => f.startsWith('backup_') && f.endsWith('.zip'))
    .map((fileName) => {
      const fullPath = path.join(backupDir, fileName);
      const stat = fs.statSync(fullPath);

      // Ekstrak label versi dari format: backup_v05-09-2026_timestamp.zip
      let versionLabel = 'Versi Cadangan';
      const parts = fileName.split('_');
      if (parts.length >= 2) {
        versionLabel = parts[1].replace(/-/g, '.');
      }

      return {
        fileName,
        sizeKb: Math.round(stat.size / 1024),
        createdAt: stat.mtime.toISOString(),
        versionLabel,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return backups;
}
