export type GeometryType = 'Point' | 'LineString' | 'Polygon' | 'MultiPolygon';

export interface GeoJSONGeometry {
  type: GeometryType;
  coordinates: any;
}

export interface SubCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  color?: string;
}

export interface MapRecord {
  id: string;
  name: string;
  description?: string;
  address: string;
  desa?: string;
  kecamatan?: string;
  kabupaten?: string;
  categoryId: string;
  categoryName?: string;
  categoryColor?: string;
  subcategoryId?: string;
  subcategoryName?: string;
  type?: GeometryType;
  latitude?: number;
  longitude?: number;
  status?: 'Active' | 'Inactive';
  imageUrl?: string;
  areaHa?: number;
  jumlahKk?: number;
  kkCount?: number;
  proses?: string;
  pengelola?: string;
  komoditi?: string;
  pendamping?: string;
  skLegalitas?: string;
  tahun?: number;
  geometry: GeoJSONGeometry;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  color: string;
  strokeColor?: string;
  fillOpacity?: number;
  icon?: string;
  subcategories?: SubCategory[];
  createdAt: string;
}

export interface RolePermission {
  key: string;
  name: string;
  description: string;
  category: 'Peta & Wilayah' | 'Kategori' | 'Pengguna & Akun' | 'Sistem & Data';
}

export interface RoleDefinition {
  id: string;
  name: string;
  label: string;
  description: string;
  color: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  permissions: string[];
}

export interface User {
  id: string;
  fullName: string;
  username: string;
  email: string;
  password?: string;
  passwordHash?: string;
  roles: string[]; // e.g. ['developer'], ['admin'], ['gis_editor'], ['operator'], ['user']
  isDeveloper?: boolean; // Khusus akun developer dengan akses penuh
  avatar?: string;
  phone?: string;
  organization?: string;
  status?: 'active' | 'inactive';
  isActive?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SiteSetting {
  id: string;
  title: string;
  description: string;
  // Identitas & Tampilan (Logo, Favicon, Title)
  logoUrl?: string; // URL atau Base64 gambar logo untuk navbar frontend & backend
  faviconUrl?: string; // URL atau Base64 favicon icon untuk tab browser
  navbarTitle?: string; // Teks judul yang ditampilkan di navbar
  browserTabTitle?: string; // Teks judul yang ditampilkan pada tab browser
  mapCenterLat: number;
  mapCenterLng: number;
  mapZoom: number;
  maskOutsideSumut: boolean;
  showSumutLabels?: boolean;
  showBoundaryLayer?: boolean;
  activeBasemap: string;
  contactEmail?: string;
  sourceAttribution: string;
  sumutBoundaryGeoJSON?: any;
  // Catatan Aktivitas
  maxActivityLogs?: number; // Batas maksimum log yang tersimpan (default 100)
  // Pengindeksan & Verifikasi Mesin Pencari (Google, Bing)
  searchEngineIndexingEnabled?: boolean; // Default: true (izinkan bot Google & Bing)
  googleVerificationCode?: string; // Kode verifikasi Google Search Console (google-site-verification)
  bingVerificationCode?: string; // Kode verifikasi Bing Webmaster Tools (msvalidate.01)
  // Google Analytics
  googleAnalyticsEnabled?: boolean; // Default: false
  googleAnalyticsId?: string; // Google Analytics 4 Measurement ID (G-XXXXXXXXXX)
  // Konfigurasi Pilihan Widget Google Analytics di Dashboard
  analyticsWidgets?: AnalyticsWidgetSettings;
  // Pengaturan Mode Pemeliharaan / Under Construction
  underConstructionEnabled?: boolean; // Default: false
  underConstructionTitle?: string; // Judul tampilan (misal: "Situs Sedang Dalam Pemeliharaan")
  underConstructionMessage?: string; // Pesan penjelasan untuk pengunjung umum
  underConstructionEstimatedTime?: string; // Estimasi waktu selesai (opsional)
  underConstructionContact?: string; // Alamat kontak / email / nomor kontak yang dapat dihubungi
}

export interface AnalyticsWidgetSettings {
  showOverviewKpis?: boolean; // 4 Kartu Ringkasan KPI Utama (Pengunjung Unik, Kunjungan Peta, Rata-rata Waktu Akses, Pengunjung Aktif)
  showDailyTrend?: boolean; // Grafik Tren Kunjungan & Interaksi Harian
  showTopMaps?: boolean; // Peta & Lapisan Konflik Terpopuler
  showCategoryInteractions?: boolean; // Interaksi Saringan Kategori Isu
  showDownloadBreakdown?: boolean; // Aktivitas Unduhan Data Spasial (GeoJSON, KML, SHP, Cetak)
  showAcquisitionChannels?: boolean; // Kanal & Sumber Rujukan Pengunjung
  showSearchQueries?: boolean; // Kata Kunci Pencarian di Peta
  showGeoDistribution?: boolean; // Sebaran Geografis Pengunjung
  showDeviceBreakdown?: boolean; // Proporsi Perangkat Akses
}

export interface AuthSession {
  user: Omit<User, 'password'>;
  token: string;
}

export interface ActivityLog {
  id: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'SYSTEM';
  entity: 'maps' | 'categories' | 'users' | 'roles' | 'settings' | 'system';
  entityId?: string;
  description: string;
  userName: string;
  userEmail?: string;
  details?: string;
  createdAt: string;
}
