import fs from 'fs';
import path from 'path';

export interface VersionHistoryItem {
  version: string;
  date: string;
  timestamp: string;
  notes: string;
  backupFile?: string | null;
  filesCount?: number;
  status: 'success' | 'rollback' | 'failed';
  details?: string[];
}

export interface AppVersionData {
  version: string;
  versionName: string;
  releaseDate: string;
  lastUpdated: string;
  notes: string;
  history: VersionHistoryItem[];
}

const MONTH_NAMES_ID = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

/**
 * Memformat tanggal ke dalam string versi dengan aturan jam.dd.mm.yy
 * Format: jam.dd.mm.yy (misal: 18.45.05.09.26 atau 18.05.09.26)
 */
export function formatVersionFromDate(date: Date = new Date(), sequence: number = 0): string {
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = String(date.getFullYear()).slice(-2);

  if (sequence > 0) {
    return `${hours}.${minutes}.${day}.${month}.${year}.${String(sequence).padStart(2, '0')}`;
  }
  return `${hours}.${minutes}.${day}.${month}.${year}`;
}

/**
 * Format nama versi yang ramah pengguna dalam Bahasa Indonesia
 * Misal: "05 September 2026, Pukul 18:45 WIB"
 */
export function formatFriendlyDate(date: Date = new Date(), versionStr?: string): string {
  if (versionStr) {
    const parsed = parseVersionComponents(versionStr);
    if (parsed) {
      const monthName = MONTH_NAMES_ID[parsed.month - 1] || 'September';
      const yearFull = parsed.year < 100 ? 2000 + parsed.year : parsed.year;
      const minStr = parsed.minute !== undefined ? `:${String(parsed.minute).padStart(2, '0')}` : ':00';
      return `${String(parsed.day).padStart(2, '0')} ${monthName} ${yearFull}, Pukul ${String(parsed.hour).padStart(2, '0')}${minStr} WIB`;
    }
  }

  const day = String(date.getDate()).padStart(2, '0');
  const monthName = MONTH_NAMES_ID[date.getMonth()] || 'September';
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${day} ${monthName} ${year}, Pukul ${hours}:${minutes} WIB`;
}

/**
 * Parsing komponen versi dari format jam.dd.mm.yy atau variasinya
 */
export function parseVersionComponents(versionStr: string): {
  hour: number;
  minute?: number;
  day: number;
  month: number;
  year: number;
} | null {
  if (!versionStr) return null;

  // Bersihkan prefix 'v' atau 'gis_update_' atau extension '.zip'
  let clean = versionStr.trim();
  clean = clean.replace(/^gis_update_/i, '').replace(/\.zip$/i, '').replace(/^v/i, '');

  const parts = clean.split('.').map(p => parseInt(p, 10)).filter(n => !isNaN(n));

  // Format 5 bagian: jam.menit.dd.mm.yy (e.g. 18.45.05.09.26)
  if (parts.length >= 5) {
    const [hour, minute, day, month, year] = parts;
    return { hour, minute, day, month, year };
  }

  // Format 4 bagian: jam.dd.mm.yy (e.g. 18.05.09.26)
  if (parts.length === 4) {
    const [hour, day, month, year] = parts;
    return { hour, minute: 0, day, month, year };
  }

  // Format legacy 3 bagian: dd.mm.yyyy (e.g. 05.09.2026)
  if (parts.length === 3) {
    const [day, month, year] = parts;
    return { hour: 0, minute: 0, day, month, year: year > 2000 ? year - 2000 : year };
  }

  return null;
}

/**
 * Mengubah string versi menjadi timestamp numerik (epoch ms) untuk pembandingan
 */
export function parseVersionTimestamp(versionStr: string): number {
  const parsed = parseVersionComponents(versionStr);
  if (!parsed) return 0;

  const fullYear = parsed.year < 100 ? 2000 + parsed.year : parsed.year;
  const monthIdx = Math.max(0, Math.min(11, parsed.month - 1));
  const day = parsed.day || 1;
  const hour = parsed.hour || 0;
  const min = parsed.minute || 0;

  const d = new Date(fullYear, monthIdx, day, hour, min, 0);
  return d.getTime();
}

/**
 * Memeriksa apakah remoteVersion lebih baru daripada currentVersion
 */
export function isNewerVersion(remoteVersion: string, currentVersion: string): boolean {
  if (!remoteVersion) return false;
  if (!currentVersion) return true;

  const remoteTime = parseVersionTimestamp(remoteVersion);
  const currentTime = parseVersionTimestamp(currentVersion);

  if (remoteTime > 0 && currentTime > 0) {
    return remoteTime > currentTime;
  }

  return remoteVersion.trim() !== currentVersion.trim();
}

/**
 * Mengekstrak versi dari nama file, misalnya 'gis_update_18.45.05.09.26.zip' -> '18.45.05.09.26'
 */
export function extractVersionFromFileName(fileName: string): string {
  if (!fileName) return '';
  const match = fileName.match(/gis_update_([0-9.]+)(?:\.zip)?$/i);
  if (match && match[1]) {
    return match[1].replace(/\.$/, '');
  }
  return fileName.replace(/^gis_update_/i, '').replace(/\.zip$/i, '');
}

/**
 * Mendapatkan path file version.json di root project
 */
function getVersionFilePath(): string {
  return path.join(process.cwd(), 'version.json');
}

/**
 * Membaca data versi aplikasi saat ini
 */
export function getAppVersion(): AppVersionData {
  try {
    const filePath = getVersionFilePath();
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf-8');
      const data = JSON.parse(raw);
      if (data && data.version) {
        return data as AppVersionData;
      }
    }
  } catch (err) {
    console.error('Gagal membaca version.json:', err);
  }

  // Fallback jika file belum ada
  const now = new Date();
  const defaultVersion = formatVersionFromDate(now);
  const defaultName = formatFriendlyDate(now);

  const fallbackData: AppVersionData = {
    version: defaultVersion,
    versionName: defaultName,
    releaseDate: now.toISOString().split('T')[0],
    lastUpdated: now.toISOString(),
    notes: 'Versi mandiri WALHI Sumut',
    history: [
      {
        version: defaultVersion,
        date: defaultName,
        timestamp: now.toISOString(),
        notes: 'Inisialisasi sistem versi mandiri',
        status: 'success',
      },
    ],
  };

  try {
    fs.writeFileSync(getVersionFilePath(), JSON.stringify(fallbackData, null, 2), 'utf-8');
  } catch {}

  return fallbackData;
}

/**
 * Menyimpan pembaruan versi baru ke dalam version.json
 */
export function recordNewVersion(
  newVersionStr?: string,
  notes: string = 'Pembaruan mandiri sistem',
  backupFile?: string | null,
  filesCount?: number,
  details?: string[]
): AppVersionData {
  const current = getAppVersion();
  const now = new Date();

  // Jika nama versi tidak diberikan secara spesifik, generate berdasar tanggal hari ini
  let targetVersion = newVersionStr?.trim();
  if (!targetVersion) {
    // Cek apakah versi untuk hari ini sudah pernah ada, jika ya tambahkan sequence .01
    const baseToday = formatVersionFromDate(now);
    const countToday = current.history.filter((h) => h.version.startsWith(baseToday)).length;
    targetVersion = countToday > 0 ? formatVersionFromDate(now, countToday) : baseToday;
  }

  const friendlyName = formatFriendlyDate(now);

  const newHistoryItem: VersionHistoryItem = {
    version: targetVersion,
    date: friendlyName,
    timestamp: now.toISOString(),
    notes,
    backupFile: backupFile || null,
    filesCount: filesCount || 0,
    status: 'success',
    details,
  };

  const updatedData: AppVersionData = {
    version: targetVersion,
    versionName: friendlyName,
    releaseDate: now.toISOString().split('T')[0],
    lastUpdated: now.toISOString(),
    notes,
    history: [newHistoryItem, ...(current.history || []).slice(0, 30)], // simpan hingga 30 riwayat
  };

  try {
    fs.writeFileSync(getVersionFilePath(), JSON.stringify(updatedData, null, 2), 'utf-8');
  } catch (err) {
    console.error('Gagal menulis version.json:', err);
  }

  return updatedData;
}

/**
 * Mencatat rollback ke versi sebelumnya di version.json
 */
export function recordRollbackVersion(
  revertedVersion: string,
  revertedName: string,
  backupFileUsed: string
): AppVersionData {
  const current = getAppVersion();
  const now = new Date();

  const newHistoryItem: VersionHistoryItem = {
    version: revertedVersion,
    date: formatFriendlyDate(now),
    timestamp: now.toISOString(),
    notes: `Rollback: Mengembalikan aplikasi ke versi ${revertedVersion} menggunakan cadangan ${backupFileUsed}`,
    backupFile: backupFileUsed,
    status: 'rollback',
  };

  const updatedData: AppVersionData = {
    version: revertedVersion,
    versionName: revertedName || revertedVersion,
    releaseDate: now.toISOString().split('T')[0],
    lastUpdated: now.toISOString(),
    notes: `Kembali ke versi ${revertedVersion}`,
    history: [newHistoryItem, ...(current.history || []).slice(0, 30)],
  };

  try {
    fs.writeFileSync(getVersionFilePath(), JSON.stringify(updatedData, null, 2), 'utf-8');
  } catch (err) {
    console.error('Gagal memperbarui version.json saat rollback:', err);
  }

  return updatedData;
}
